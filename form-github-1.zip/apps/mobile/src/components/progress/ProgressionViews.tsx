import Ionicons from '@expo/vector-icons/Ionicons';
import { useEffect, useState } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { AppText, Card, Divider, IconButton, InlineMessage, ProgressBar, Row, type IconName } from '@/components/ui';
import { useReducedMotion } from '@/lib/a11y';
import type { Progress, XpLedgerEntry } from '@/lib/types';
import { colors, radius, space } from '@/theme/tokens';

/** Each rank's emblem: a colour and a symbol. Colour is reserved for the emblem itself. */
export const RANK_STYLE: Record<string, { color: string; icon: IconName }> = {
  Rookie: { color: '#9AA39F', icon: 'leaf' },
  Starter: { color: '#10B981', icon: 'flash' },
  Athlete: { color: '#38BDF8', icon: 'fitness' },
  Iron: { color: '#A8B3BF', icon: 'barbell' },
  Elite: { color: '#A39AEC', icon: 'diamond' },
  Master: { color: '#F5A524', icon: 'ribbon' },
  Champion: { color: '#FACC15', icon: 'trophy' },
};

const fmt = (n: number) => Math.round(n).toLocaleString();

/** "LEVEL 13 — 2,450 / 3,000 XP" (or the max-level line). */
export function levelLine(p: Pick<Progress, 'level' | 'xpIntoLevel' | 'xpForNextLevel'>): string {
  return p.xpForNextLevel === 0 ? `LEVEL ${p.level} — max level` : `LEVEL ${p.level} — ${fmt(p.xpIntoLevel)} / ${fmt(p.xpForNextLevel)} XP`;
}

export function streakCaption(p: Progress): string {
  const s = p.streak;
  if (s.current === 0) return 'Log a workout to start a streak';
  if (s.activeToday) return 'Trained today · rest days protect your streak';
  if (s.restDaysRemaining === 0) return 'Train today to keep your streak';
  return `${s.restDaysRemaining} rest day${s.restDaysRemaining === 1 ? '' : 's'} left before it resets`;
}

/** A rank emblem: a ring in the rank's colour around its symbol. */
export function RankEmblem({ rank, size = 72 }: { rank: string; size?: number }) {
  const s = RANK_STYLE[rank] ?? RANK_STYLE.Rookie!;
  return (
    <View
      accessible
      accessibilityLabel={`${rank} rank`}
      style={[styles.emblem, { width: size, height: size, borderRadius: size / 2, borderColor: s.color, backgroundColor: `${s.color}1F` }]}>
      <View style={[styles.emblemInner, { width: size - 16, height: size - 16, borderRadius: (size - 16) / 2, borderColor: `${s.color}66` }]}>
        <Ionicons name={s.icon} size={size * 0.38} color={s.color} />
      </View>
    </View>
  );
}

/** The level hero: emblem, rank, LEVEL n — into / span XP, and the bar to the next level. */
export function LevelHero({ progress: p }: { progress: Progress }) {
  const next = p.rankLadder.find((r) => r.minLevel > p.level);
  return (
    <Card style={{ gap: space.lg, paddingVertical: space.xl }}>
      <Row gap={space.lg}>
        <RankEmblem rank={p.rank} size={76} />
        <View style={{ flex: 1, gap: 2 }}>
          <AppText variant="overline" color={(RANK_STYLE[p.rank] ?? RANK_STYLE.Rookie!).color}>
            {p.rank}
          </AppText>
          <AppText variant="display" header style={{ fontSize: 40, lineHeight: 46 }}>
            Level {p.level}
          </AppText>
        </View>
      </Row>
      <View style={{ gap: space.sm }}>
        <AppText variant="label" accessibilityLabel={levelLine(p).replace('—', ',')} style={{ fontVariant: ['tabular-nums'] }}>
          {levelLine(p)}
        </AppText>
        <ProgressBar value={p.fractionToNext} height={10} label={`Progress to level ${p.level + 1}`} />
        <Row style={{ justifyContent: 'space-between' }}>
          <AppText variant="caption" color={colors.textMuted}>
            {next ? `${next.name} at level ${next.minLevel}` : 'Top rank reached'}
          </AppText>
          <AppText variant="caption" color={colors.textFaint}>
            {fmt(p.lifetimeXp)} XP all time
          </AppText>
        </Row>
      </View>
      {p.provisionalXp > 0 ? (
        <AppText variant="caption" color={colors.textFaint}>
          Includes {p.provisionalXp} XP from today’s food, confirmed when the day ends.
        </AppText>
      ) : null}
    </Card>
  );
}

/** A gentle celebration for a recent level-up (within a day). Skipped with reduced motion. */
export function LevelUpBanner({ progress: p, now = new Date(), onDismiss }: { progress: Progress; now?: Date; onDismiss?: () => void }) {
  const reduce = useReducedMotion();
  const [anim] = useState(() => new Animated.Value(reduce ? 1 : 0));
  const recent = p.recentLevelUp && now.getTime() - new Date(p.recentLevelUp.at).getTime() < 24 * 3600_000 && p.recentLevelUp.level === p.level;
  useEffect(() => {
    if (!recent) return;
    if (reduce) return anim.setValue(1);
    Animated.spring(anim, { toValue: 1, friction: 6, useNativeDriver: true }).start();
  }, [anim, recent, reduce]);
  if (!recent || !p.recentLevelUp) return null;
  return (
    <Animated.View style={{ opacity: anim, transform: [{ scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.94, 1] }) }] }}>
      <Card variant="raised" style={styles.levelUp}>
        <Row gap={space.md}>
          <RankEmblem rank={p.recentLevelUp.rank} size={52} />
          <View style={{ flex: 1 }} accessible accessibilityLiveRegion="polite">
            <AppText variant="overline" color={colors.accent}>
              Level up
            </AppText>
            <AppText variant="heading">
              Level {p.recentLevelUp.level} · {p.recentLevelUp.rank}
            </AppText>
            <AppText variant="caption" color={colors.textMuted}>
              Earned through real training. Keep it going.
            </AppText>
          </View>
          {onDismiss ? <IconButton icon="close" label="Dismiss" onPress={onDismiss} /> : null}
        </Row>
      </Card>
    </Animated.View>
  );
}

/** The full rank ladder: reached ranks filled, the current one highlighted. */
export function RankLadder({ progress: p }: { progress: Progress }) {
  return (
    <Card style={{ gap: space.xs }}>
      {p.rankLadder.map((r, i) => {
        const reached = p.level >= r.minLevel;
        const current = p.rank === r.name;
        const s = RANK_STYLE[r.name] ?? RANK_STYLE.Rookie!;
        return (
          <View key={r.name}>
            {i > 0 ? <Divider /> : null}
            <View style={[styles.row, { paddingVertical: space.sm }]} accessible accessibilityLabel={`${r.name}, from level ${r.minLevel}${current ? ', your rank' : reached ? ', reached' : ''}`}>
              <View style={[styles.dot, { borderColor: reached ? s.color : colors.border, backgroundColor: reached ? `${s.color}26` : 'transparent' }]}>
                <Ionicons name={s.icon} size={14} color={reached ? s.color : colors.textFaint} />
              </View>
              <AppText variant={current ? 'bodyStrong' : 'body'} color={reached ? colors.text : colors.textFaint} style={{ flex: 1 }}>
                {r.name}
                {current ? '  · you are here' : ''}
              </AppText>
              <AppText variant="caption" color={colors.textFaint}>
                Level {r.minLevel}
              </AppText>
            </View>
          </View>
        );
      })}
    </Card>
  );
}

/** How to keep progress: when to train next, what missed days cost, and that planned rest is safe. */
export function ConsistencyCard({ progress: p }: { progress: Progress }) {
  const c = p.consistency;
  // With no active XP there is nothing to lose, so there is no countdown to show.
  const days = p.totalXp > 0 ? c.trainWithinDays : null;
  const urgent = days !== null && days <= 2;
  return (
    <Card style={{ gap: space.sm }}>
      <Row gap={space.sm}>
        <Ionicons name={c.recovering ? 'medkit-outline' : urgent ? 'alert-circle' : 'shield-checkmark-outline'} size={20} color={c.recovering ? colors.textMuted : urgent ? colors.warning : colors.primary} />
        <AppText variant="bodyStrong" style={{ flex: 1 }}>
          {c.recovering
            ? 'Recovering — take the time you need'
            : days === null
              ? p.lastReset
                ? 'Your next workout starts the climb again'
                : 'Your first workout starts your progress'
              : days === 1
                ? `Train today to keep Level ${p.level}`
                : `Train within ${days} days to keep Level ${p.level}`}
        </AppText>
      </Row>
      <AppText variant="caption" color={colors.textMuted}>
        {`Your plan: ${c.trainingDaysPerWeek} ${c.trainingDaysPerWeek === 1 ? 'day' : 'days'} a week. Rest days in your plan never cost anything; a missed training day costs ${c.decayPerMissedDay} XP. After more than ${c.resetAfterDays} days without training, your level starts again from 1 — your workouts, records and history always stay.`}
      </AppText>
      {c.missedThisWeek > 0 ? (
        <AppText variant="caption" color={colors.warning}>
          {c.missedThisWeek} missed {c.missedThisWeek === 1 ? 'day' : 'days'} this week.
        </AppText>
      ) : null}
    </Card>
  );
}

/** Shown for two weeks after a reset: what happened, and that nothing was lost. */
export function ResetNotice({ progress: p, today }: { progress: Progress; today: string }) {
  const r = p.lastReset;
  if (!r) return null;
  const daysAgo = Math.round((new Date(`${today}T12:00:00`).getTime() - new Date(`${r.date}T12:00:00`).getTime()) / 86_400_000);
  if (daysAgo > 14) return null;
  return (
    <InlineMessage tone="info" icon="refresh">
      {`Fresh start: your level reset on ${new Date(`${r.date}T12:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} after ${r.gapDays} days without training (you were Level ${r.previousLevel} · ${r.previousRank}). Your workouts, records and full XP history are all kept.`}
    </InlineMessage>
  );
}

/** Where XP came from (and went): the ledger, newest first. */
export function XpHistory({ events }: { events: XpLedgerEntry[] }) {
  if (events.length === 0) {
    return (
      <Card>
        <AppText variant="caption" color={colors.textMuted}>
          Your XP history appears here — every workout, quest and nutrition day, and anything that changed it.
        </AppText>
      </Card>
    );
  }
  return (
    <Card style={{ paddingVertical: space.xs }}>
      {events.map((e, i) => {
        const positive = e.xp > 0;
        const neutral = e.xp === 0;
        return (
          <View key={e.id}>
            {i > 0 ? <Divider /> : null}
            <View style={[styles.row, { minHeight: 52, paddingVertical: space.sm }]} accessible accessibilityLabel={`${e.label}, ${e.xp >= 0 ? 'plus' : 'minus'} ${Math.abs(e.xp)} XP${e.localDate ? `, ${e.localDate}` : ''}`}>
              <View style={{ flex: 1 }}>
                <AppText variant="body">{e.label}</AppText>
                <AppText variant="caption" color={colors.textFaint}>
                  {e.localDate ? new Date(`${e.localDate}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }) : new Date(e.at).toLocaleDateString()}
                </AppText>
              </View>
              <AppText variant="bodyStrong" color={neutral ? colors.textFaint : positive ? colors.primary : colors.warning} style={{ fontVariant: ['tabular-nums'] }}>
                {neutral ? '—' : `${positive ? '+' : '−'}${Math.abs(e.xp)} XP`}
              </AppText>
            </View>
          </View>
        );
      })}
    </Card>
  );
}

const styles = StyleSheet.create({
  emblem: { borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  emblemInner: { borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  dot: { width: 30, height: 30, borderRadius: 15, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  levelUp: { borderWidth: 1, borderColor: colors.accentSoft, borderRadius: radius.xl },
});
