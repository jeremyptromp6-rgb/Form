import { LinearGradient } from 'expo-linear-gradient';
import type { ReactNode } from 'react';
import { ImageBackground, RefreshControl, ScrollView, StyleSheet, View, type ImageSourcePropType, type StyleProp, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, gradients, MAX_CONTENT_WIDTH, radius, space } from '@/theme/tokens';
import { AppText } from './text';

/**
 * A scrolling screen: a quiet eyebrow (date, context), a confident title, then content with room
 * to breathe. `hero` replaces the plain header with something richer (e.g. Home's greeting).
 */
export function Screen({
  title,
  subtitle,
  right,
  hero,
  children,
  refreshing,
  onRefresh,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
  hero?: ReactNode;
  children: ReactNode;
  refreshing?: boolean;
  onRefresh?: () => void;
}) {
  return (
    <SafeAreaView edges={['top']} style={styles.screen}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        refreshControl={onRefresh ? <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} tintColor={colors.primary} /> : undefined}>
        {hero ?? (
          <View style={styles.header}>
            <View style={{ flex: 1, gap: 2 }}>
              {subtitle ? (
                <AppText variant="label" color={colors.textFaint}>
                  {subtitle}
                </AppText>
              ) : null}
              <AppText variant="title" header>
                {title}
              </AppText>
            </View>
            {right}
          </View>
        )}
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

/**
 * A surface. `plain` drops the background for open layouts; `raised` lifts it a step. Use cards
 * for things that belong together — not for every piece of text.
 */
export function Card({ children, style, variant = 'default' }: { children: ReactNode; style?: StyleProp<ViewStyle>; variant?: 'default' | 'raised' | 'plain' }) {
  return <View style={[styles.card, variant === 'raised' && styles.raised, variant === 'plain' && styles.plain, style]}>{children}</View>;
}

/** A feature surface with a quiet lift — for the one thing on a screen that matters most. */
export function GradientCard({
  children,
  colorsOverride = gradients.hero,
  style,
}: {
  children: ReactNode;
  colorsOverride?: readonly [string, string, ...string[]];
  style?: StyleProp<ViewStyle>;
}) {
  return (
    <LinearGradient colors={colorsOverride} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.card, styles.gradientCard, style]}>
      {children}
    </LinearGradient>
  );
}

/**
 * Imagery with content on top. With a real photo (see `theme/imagery.ts`) the photo fills the
 * area under a scrim; without one, a calm gradient stands in — never a fake or generated photo.
 */
export function HeroMedia({
  image,
  children,
  minHeight = 220,
  style,
  accessibilityLabel,
}: {
  image?: ImageSourcePropType | null;
  children: ReactNode;
  minHeight?: number;
  style?: StyleProp<ViewStyle>;
  /** Describes the photo, when there is one. */
  accessibilityLabel?: string;
}) {
  const body = (
    <LinearGradient colors={gradients.scrim} locations={[0, 0.45, 1]} style={[styles.heroBody, { minHeight }]}>
      {children}
    </LinearGradient>
  );
  if (image) {
    return (
      <ImageBackground source={image} resizeMode="cover" style={[styles.hero, style]} imageStyle={{ borderRadius: radius.xl }} accessible={false} accessibilityLabel={accessibilityLabel}>
        {body}
      </ImageBackground>
    );
  }
  return (
    <LinearGradient colors={['#1D2B26', '#141B19', colors.card]} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={[styles.hero, style]}>
      {body}
    </LinearGradient>
  );
}

/** A section title in plain, sentence-case language ("Today's fuel"), with an optional action. */
export function SectionHeader({ title, action }: { title: string; action?: ReactNode }) {
  return (
    <View style={styles.sectionHeader}>
      <AppText variant="heading" header style={{ fontSize: 17 }}>
        {title}
      </AppText>
      {action}
    </View>
  );
}

export function Row({ children, style, gap = space.md }: { children: ReactNode; style?: StyleProp<ViewStyle>; gap?: number }) {
  return <View style={[{ flexDirection: 'row', alignItems: 'center', gap }, style]}>{children}</View>;
}

/** A quiet hairline between rows. */
export function Divider({ style }: { style?: StyleProp<ViewStyle> }) {
  return <View style={[{ height: StyleSheet.hairlineWidth, backgroundColor: colors.hairline }, style]} />;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  scroll: { paddingHorizontal: space.lg, paddingTop: space.md, paddingBottom: space.xxxl * 2, gap: space.lg, width: '100%', maxWidth: MAX_CONTENT_WIDTH, alignSelf: 'center' },
  header: { flexDirection: 'row', alignItems: 'flex-end', paddingTop: space.sm, paddingBottom: space.sm },
  card: { backgroundColor: colors.card, borderRadius: radius.lg, padding: space.lg, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.hairline },
  raised: { backgroundColor: colors.cardRaised },
  plain: { backgroundColor: 'transparent', borderWidth: 0, padding: 0 },
  gradientCard: { overflow: 'hidden', borderRadius: radius.xl },
  hero: { borderRadius: radius.xl, overflow: 'hidden' },
  heroBody: { justifyContent: 'flex-end', padding: space.xl, gap: space.md },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: space.md, marginBottom: -space.xs },
});
