import Ionicons from '@expo/vector-icons/Ionicons';
import { Pressable, StyleSheet, View } from 'react-native';
import { defaultMealType } from '@form/domain';
import { AppText, Badge, Button, Card, Divider, IconButton, InlineMessage, ListRow, ProgressBar, Row, Stat, StateView } from '@/components/ui';
import { dayHeadline, entryBadge, formatLiters, MEAL_LABEL, MEALS, portionLabel, proteinNudge } from '@/lib/eat';
import type { FoodLog, MealType, NutritionDay } from '@/lib/types';
import { colors, radius, space } from '@/theme/tokens';

export interface EatDayViewProps {
  day: NutritionDay;
  title: string;
  onPrev: (() => void) | null;
  onNext: (() => void) | null;
  onAdd: (meal: MealType) => void;
  onOpenLog: (log: FoodLog) => void;
  /** Quick-add water; only offered for today. */
  onAddWater?: (ml: number) => void;
  addingWater?: boolean;
  onScan: () => void;
  scanAvailable: boolean;
  /** Weigh several ingredients and log them as one meal. */
  onWeighMeal: () => void;
  /** Meal planning, recipes and the grocery list — shown when those features are live. */
  planning?: { onOpenPlan: () => void; onOpenRecipes: () => void; onOpenGrocery: () => void } | null;
  showScanInfo: boolean;
  onSetUpProfile: () => void;
}

const fmt = (n: number) => Math.round(n).toLocaleString();

/** The Eat dashboard: day totals vs targets, water, and the day's meals. Pure view. */
export function EatDayView(p: EatDayViewProps) {
  const { day } = p;
  const kcal = day.progress?.kcal;
  const protein = day.progress?.proteinG;
  // Only today gets a nudge — past days are history, not a to-do list.
  const nudge = p.onAddWater ? proteinNudge(day) : null;

  return (
    <View style={{ gap: space.lg }}>
      <Row style={{ justifyContent: 'space-between' }}>
        {p.onPrev ? <IconButton icon="chevron-back" label="Previous day" onPress={p.onPrev} color={colors.text} /> : <View style={{ width: 44 }} />}
        <AppText variant="heading" header accessibilityLabel={`Showing ${p.title}`}>
          {p.title}
        </AppText>
        {p.onNext ? <IconButton icon="chevron-forward" label="Next day" onPress={p.onNext} color={colors.text} /> : <View style={{ width: 44 }} />}
      </Row>

      <Card style={{ gap: space.md }}>
        <AppText variant="heading" header>
          {dayHeadline(day)}
        </AppText>
        <Row style={{ justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap' }}>
          <Row gap={space.xs} style={{ alignItems: 'baseline' }}>
            <AppText variant="display">{fmt(day.totals.kcal)}</AppText>
            <AppText variant="bodyStrong" color={colors.textMuted}>
              {kcal ? `/ ${fmt(kcal.target)} kcal` : 'kcal'}
            </AppText>
          </Row>
          {kcal ? (
            <AppText variant="label" color={kcal.over > 0 ? colors.warning : colors.textMuted}>
              {kcal.over > 0 ? `${fmt(kcal.over)} over` : `${fmt(kcal.remaining)} left`}
            </AppText>
          ) : null}
        </Row>
        {kcal ? <ProgressBar value={kcal.fraction} height={8} label="Calories eaten of target" /> : null}
        {day.progress ? (
          <AppText variant="caption" color={colors.textMuted}>
            Carbs {Math.round(day.totals.carbsG)} / {Math.round(day.progress.carbsG.target)} g · Fat {Math.round(day.totals.fatG)} / {Math.round(day.progress.fatG.target)} g
          </AppText>
        ) : null}
        {day.totals.estimatedKcalShare > 0 ? (
          <InlineMessage tone="warning" icon="alert-circle-outline">
            {`About ${Math.round(day.totals.estimatedKcalShare * 100)}% of these calories are estimates, not measured amounts.`}
          </InlineMessage>
        ) : null}
        {day.totals.measuredKcalShare > 0 ? (
          <AppText variant="caption" color={colors.textFaint}>
            {`${Math.round(day.totals.measuredKcalShare * 100)}% measured on a scale.`}
          </AppText>
        ) : null}
        {!day.targets ? (
          <Pressable accessibilityRole="link" onPress={p.onSetUpProfile}>
            <InlineMessage tone="info">Add your body details in Profile to get personal calorie and macro targets →</InlineMessage>
          </Pressable>
        ) : null}
      </Card>

      <Row gap={space.sm} style={{ alignItems: 'stretch' }}>
        <View style={{ flex: 1 }}>
          <Stat
            label="Protein"
            value={String(Math.round(day.totals.proteinG))}
            unit={protein ? `/ ${Math.round(protein.target)} g` : 'g'}
            progress={protein?.fraction}
            accessibilityLabel={`Protein: ${Math.round(day.totals.proteinG)}${protein ? ` of ${Math.round(protein.target)}` : ''} grams`}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Stat
            label="Water"
            value={formatLiters(day.water.totalMl)}
            unit={`/ ${formatLiters(day.water.targetMl)}`}
            tint={colors.water}
            progress={day.water.progress.fraction}
            accessibilityLabel={`Water: ${formatLiters(day.water.totalMl)} of ${formatLiters(day.water.targetMl)}`}
          />
        </View>
      </Row>
      {p.onAddWater ? (
        <Row gap={space.sm}>
          <Button label="+250 ml" variant="secondary" icon="water-outline" onPress={() => p.onAddWater!(250)} loading={p.addingWater} style={{ flex: 1 }} />
          <Button label="+500 ml" variant="secondary" onPress={() => p.onAddWater!(500)} disabled={p.addingWater} style={{ flex: 1 }} />
        </Row>
      ) : null}

      {nudge ? (
        <Card variant="raised" style={{ gap: space.sm }}>
          <Row gap={space.sm} style={{ alignItems: 'flex-start' }}>
            <Ionicons name="nutrition-outline" size={20} color={colors.accent} />
            <AppText variant="bodyStrong" style={{ flex: 1 }}>
              {nudge}
            </AppText>
          </Row>
          <AppText variant="caption" color={colors.textMuted}>
            A protein-rich meal or snack that fits your diet would close the gap.
          </AppText>
          <Button label="Add food" iconRight="arrow-forward" onPress={() => p.onAdd(defaultMealType(new Date().getHours()))} style={{ alignSelf: 'flex-start' }} />
        </Card>
      ) : null}

      {MEALS.map((meal) => (
        <MealSection key={meal} meal={meal} day={day} onAdd={() => p.onAdd(meal)} onOpenLog={p.onOpenLog} />
      ))}

      {p.planning ? (
        <Card style={{ paddingVertical: space.xs }}>
          <ListRow title="Meal plan" subtitle="Meals that fit your targets and diet" icon="calendar-outline" iconTint={colors.primary} onPress={p.planning.onOpenPlan} />
          <Divider />
          <ListRow title="Recipes" subtitle="Simple recipes that suit you" icon="book-outline" onPress={p.planning.onOpenRecipes} />
          <Divider />
          <ListRow title="Grocery list" subtitle="Everything your plan needs, by aisle" icon="cart-outline" onPress={p.planning.onOpenGrocery} />
        </Card>
      ) : null}

      <Row gap={space.sm}>
        <Button label="Weigh a meal" icon="scale-outline" variant="secondary" onPress={p.onWeighMeal} style={{ flex: 1 }} />
        <Button label="Scan a meal" icon="camera-outline" variant="secondary" onPress={p.onScan} style={{ flex: 1 }} />
      </Row>
      {p.showScanInfo ? (
        <Card>
          {p.scanAvailable ? (
            <StateView kind="empty" compact title="Scanning gives an estimate" message="A photo can't weigh food. Scanned amounts are always marked as estimates." />
          ) : (
            <StateView kind="unavailable" compact title="Food scanning isn't available yet" message="Search the food database, add a food from its label, or weigh it for the most accurate numbers." />
          )}
        </Card>
      ) : null}
    </View>
  );
}

function MealSection({ meal, day, onAdd, onOpenLog }: { meal: MealType; day: NutritionDay; onAdd: () => void; onOpenLog: (log: FoodLog) => void }) {
  const logs = day.logs.filter((l) => l.mealType === meal);
  const totals = day.byMeal[meal];
  return (
    <Card style={{ gap: space.sm, paddingVertical: space.md }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <View style={{ flex: 1 }}>
          <AppText variant="bodyStrong" header>
            {MEAL_LABEL[meal]}
          </AppText>
          <AppText variant="caption" color={colors.textMuted}>
            {totals.entries ? `${fmt(totals.kcal)} kcal · P ${Math.round(totals.proteinG)} · C ${Math.round(totals.carbsG)} · F ${Math.round(totals.fatG)}` : 'Nothing logged'}
          </AppText>
        </View>
        <Pressable accessibilityRole="button" accessibilityLabel={`Add to ${MEAL_LABEL[meal]}`} onPress={onAdd} style={({ pressed }) => [styles.add, { opacity: pressed ? 0.7 : 1 }]}>
          <Ionicons name="add" size={18} color={colors.primary} />
          <AppText variant="caption" color={colors.primary}>
            Add
          </AppText>
        </Pressable>
      </Row>
      {logs.map((l, i) => {
        const badge = entryBadge(l);
        const portion = portionLabel(l);
        // Entries logged together (a scan or a weighed meal) get their meal name once, above the group.
        const groupStart = l.mealId && l.mealName && logs[i - 1]?.mealId !== l.mealId;
        return (
          <View key={l.id}>
            {groupStart ? (
              <AppText variant="label" color={colors.textFaint} style={{ paddingTop: space.xs }}>
                {l.mealName}
              </AppText>
            ) : null}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`${l.name}, ${Math.round(l.kcal)} calories${l.isEstimate ? ', estimate' : ''}. Edit`}
              onPress={() => onOpenLog(l)}
              style={({ pressed }) => [styles.entry, { opacity: pressed ? 0.7 : 1 }]}>
              <View style={{ flex: 1, gap: 2 }}>
                <Row gap={space.sm}>
                  <AppText variant="body" numberOfLines={1} style={{ flexShrink: 1 }}>
                    {l.name}
                  </AppText>
                  <Badge label={badge.label} tone={badge.tone} />
                </Row>
                <AppText variant="caption" color={colors.textMuted}>
                  {portion ? `${portion} · ` : ''}P {Math.round(l.proteinG)} · C {Math.round(l.carbsG)} · F {Math.round(l.fatG)}
                </AppText>
              </View>
              <AppText variant="bodyStrong">
                {l.isEstimate ? '≈' : ''}
                {fmt(l.kcal)}
              </AppText>
            </Pressable>
          </View>
        );
      })}
    </Card>
  );
}

const styles = StyleSheet.create({
  add: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    minHeight: 44,
    paddingHorizontal: space.md,
    borderRadius: radius.pill,
    backgroundColor: colors.primarySoft,
  },
  entry: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    minHeight: 48,
    paddingVertical: space.xs,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
});
