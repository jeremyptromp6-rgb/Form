import Ionicons from '@expo/vector-icons/Ionicons';
import { Pressable, StyleSheet, View } from 'react-native';
import { AppText, Badge, Button, Card, Divider, HeroMedia, InlineMessage, ProgressBar, Row, Screen, SectionHeader, Stat, StateView, type IconName } from '@/components/ui';
import { levelLine, RankEmblem } from '@/components/progress/ProgressionViews';
import { CoachCard } from '@/components/coach/CoachViews';
import { BodyQuestSummaryCard } from '@/components/recognition/RecognitionViews';
import { accuracyLine, formatLitres, fuelLine, GREETING, shortDate, updatedAgo } from '@/lib/homeFormat';
import type { CoachResponse, HomeSection, HomeViewModel, QuestProgress } from '@/lib/types';
import { imagery } from '@/theme/imagery';
import { colors, radius, space } from '@/theme/tokens';

export type HomeRoute = 'train' | 'eat' | 'progress' | 'profile';

export interface HomeViewProps {
  vm: HomeViewModel;
  onNavigate: (route: HomeRoute) => void;
  onAddWater: (ml: number) => void;
  onUndoWater: (entryId: string) => void;
  waterBusy?: boolean;
  waterError?: string | null;
  refreshing?: boolean;
  onRefresh?: () => void;
  /** The last refresh failed; `vm` is the last good copy. */
  refreshFailed?: boolean;
  /** Rendered at the end of the scroll view (e.g. the free-tier ad slot). */
  footer?: React.ReactNode;
  now?: Date;
  /** Today's coaching tip (fetched separately, so a slow coach never holds Home up). */
  coach?: { response: CoachResponse | null; loading: boolean; failed: boolean };
  onOpenCoach?: () => void;
  onOpenRoute?: (route: string) => void;
}

const SECTION_LABEL: Record<HomeSection, string> = {
  progression: 'your progress',
  recognition: 'your milestones',
  today: "today's plan",
  nutrition: 'nutrition',
  water: 'water',
  quests: 'goals',
  activity: 'recent activity',
};

/**
 * Home answers one question first: what should I do today? A greeting, the day's plan with one
 * clear action, three numbers that matter, then everything else, quieter. A pure view over the
 * server's Home view model — every number comes from `vm`, every action routes somewhere real.
 */
export function HomeView({ vm, onNavigate, onAddWater, onUndoWater, waterBusy, waterError, refreshing, onRefresh, refreshFailed, footer, now, coach, onOpenCoach, onOpenRoute }: HomeViewProps) {
  const failed = (s: HomeSection) => vm.errors.includes(s);
  const date = new Date(`${vm.date}T12:00:00`).toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <Screen
      title={`${GREETING[vm.greeting.period]}, ${vm.greeting.name}`}
      refreshing={refreshing}
      onRefresh={onRefresh}
      hero={
        <Row style={styles.greeting}>
          <View style={{ flex: 1, gap: 4 }}>
            <AppText variant="label" color={colors.textFaint}>
              {date}
            </AppText>
            <AppText variant="title" header>
              {`${GREETING[vm.greeting.period]}, ${vm.greeting.name}`}
            </AppText>
          </View>
          <Pressable accessibilityRole="button" accessibilityLabel="Open profile" onPress={() => onNavigate('profile')} style={styles.avatar}>
            <Ionicons name="person" size={20} color={colors.text} />
          </Pressable>
        </Row>
      }>
      {refreshFailed ? (
        <InlineMessage tone="warning" icon="cloud-offline-outline">
          {`Couldn't refresh — showing data from ${updatedAgo(vm.generatedAt, now)}. Pull down to try again.`}
        </InlineMessage>
      ) : null}

      {/* The checklist stays until every first step is done (the server sends null then); returning users get a welcome instead. */}
      {vm.firstSteps && vm.state !== 'returning' ? <FirstSteps steps={vm.firstSteps} onNavigate={onNavigate} onAddWater={onAddWater} /> : null}
      {vm.state === 'returning' ? (
        <InlineMessage tone="info" icon="hand-right-outline">
          {`Welcome back — it's been ${vm.daysSinceLastActivity} days. Ease in with a lighter session; consistency beats intensity.`}
        </InlineMessage>
      ) : null}

      {vm.today ? <TodayHero today={vm.today} onNavigate={onNavigate} /> : failed('today') ? <SectionError name="today" /> : null}

      <Row gap={space.sm} style={{ alignItems: 'stretch' }}>
        <Pressable accessibilityRole="button" accessibilityLabel="Open Eat" onPress={() => onNavigate('eat')} style={{ flex: 1 }}>
          <Stat
            label="Protein"
            value={vm.nutrition ? String(Math.round(vm.nutrition.proteinG)) : '—'}
            unit={vm.nutrition?.targets ? `/ ${vm.nutrition.targets.proteinG} g` : 'g'}
            progress={vm.nutrition?.targets ? vm.nutrition.proteinG / vm.nutrition.targets.proteinG : undefined}
          />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Stat
            label="Water"
            value={vm.water ? formatLitres(vm.water.totalMl) : '—'}
            unit={vm.water ? `/ ${formatLitres(vm.water.targetMl)}` : undefined}
            tint={colors.water}
            progress={vm.water ? vm.water.totalMl / vm.water.targetMl : undefined}
          />
        </View>
        <View style={{ flex: 1 }}>
          <Stat label="Streak" value={vm.progression ? String(vm.progression.streak.current) : '—'} unit={vm.progression?.streak.current === 1 ? 'day' : 'days'} icon="flame" tint={colors.accent} />
        </View>
      </Row>

      {vm.water ? <WaterActions w={vm.water} onAdd={onAddWater} onUndo={onUndoWater} busy={waterBusy} error={waterError} /> : <SectionError name="water" />}

      <SectionHeader title="Today's fuel" action={<Link label="Log food" onPress={() => onNavigate('eat')} />} />
      {vm.nutrition ? <Fuel n={vm.nutrition} onNavigate={onNavigate} /> : <SectionError name="nutrition" />}

      <SectionHeader title="Today's goals" />
      {vm.quests ? <Quests daily={vm.quests.daily} weekly={vm.quests.weekly} /> : <SectionError name="quests" />}

      <SectionHeader title="Your level" action={<Link label="View all" onPress={() => onNavigate('progress')} />} />
      {vm.progression ? <Level p={vm.progression} /> : <SectionError name="progression" />}

      {vm.errors.includes('recognition') ? (
        <SectionError name="recognition" />
      ) : vm.bodyQuest.available && vm.achievements.available ? (
        <>
          <SectionHeader title="Milestones" action={<Link label="View all" onPress={() => onNavigate('progress')} />} />
          <Milestones vm={vm} onOpen={() => onNavigate('progress')} />
        </>
      ) : (
        <Card variant="plain" style={{ gap: space.xs }}>
          <AppText variant="bodyStrong">Coming to FORM</AppText>
          <AppText variant="caption" color={colors.textMuted}>
            {[!vm.bodyQuest.available && 'Body Quest', !vm.achievements.available && 'Achievements'].filter(Boolean).join(' and ')} aren&apos;t available yet.
            Everything you log now will count toward them.
          </AppText>
        </Card>
      )}

      {vm.coach.mode !== 'unavailable' && coach ? (
        <>
          <SectionHeader title="Coach" action={onOpenCoach ? <Link label="Ask the coach" onPress={onOpenCoach} /> : undefined} />
          {coach.response ? (
            <CoachCard response={coach.response} title="Today's tip" onAction={onOpenRoute} />
          ) : coach.loading ? (
            <Card>
              <StateView kind="loading" compact />
            </Card>
          ) : coach.failed ? (
            <Card>
              <AppText variant="caption" color={colors.textMuted}>
                The coach couldn&apos;t load right now. Pull down to try again.
              </AppText>
            </Card>
          ) : null}
        </>
      ) : null}

      <AppText variant="caption" color={colors.textFaint} style={{ textAlign: 'center' }}>
        Updated {updatedAgo(vm.generatedAt, now)}
      </AppText>
      {footer}
    </Screen>
  );
}

function Link({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" onPress={onPress} hitSlop={12} style={{ minHeight: 32, justifyContent: 'center' }}>
      <AppText variant="label" color={colors.primary}>
        {label}
      </AppText>
    </Pressable>
  );
}

/** Body Quest stage, the next achievement within reach, and weeks on plan — all from real activity. */
function Milestones({ vm, onOpen }: { vm: HomeViewModel; onOpen: () => void }) {
  const bq = vm.bodyQuest;
  const a = vm.achievements;
  if (!bq.available || !a.available) return null;
  return (
    <View style={{ gap: space.sm }}>
      <BodyQuestSummaryCard stage={bq.stage} highestStage={bq.highestStage} overall={bq.overall} statsWithData={bq.statsWithData} nextStage={bq.nextStage} onPress={onOpen} />
      <Card style={{ gap: space.sm }}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Row gap={space.sm}>
            <Ionicons name="medal" size={18} color={colors.accent} />
            <AppText variant="bodyStrong">
              {a.unlocked} of {a.total} achievements
            </AppText>
          </Row>
          {vm.streaks ? (
            <Badge label={`${vm.streaks.weekly.current} ${vm.streaks.weekly.current === 1 ? 'week' : 'weeks'} on plan`} tone="primary" icon="calendar" />
          ) : null}
        </Row>
        {a.next ? (
          <View style={{ gap: 4 }}>
            <AppText variant="caption" color={colors.textMuted}>
              Next up: {a.next.title} · {a.next.progress} of {a.next.target}
            </AppText>
            <ProgressBar value={a.next.progress / a.next.target} height={6} color={colors.accent} label={`${a.next.title} progress`} />
          </View>
        ) : (
          <AppText variant="caption" color={colors.textMuted}>
            Every achievement unlocked. That&apos;s real, earned work.
          </AppText>
        )}
      </Card>
    </View>
  );
}

function SectionError({ name }: { name: HomeSection }) {
  return (
    <Card>
      <StateView kind="error" compact title={`Couldn't load ${SECTION_LABEL[name]}`} message="The rest of Home is up to date. Pull down to try again." />
    </Card>
  );
}

function FirstSteps({ steps, onNavigate, onAddWater }: { steps: NonNullable<HomeViewModel['firstSteps']>; onNavigate: HomeViewProps['onNavigate']; onAddWater: HomeViewProps['onAddWater'] }) {
  const meta = {
    workout: { label: 'Log your first workout', icon: 'barbell' as IconName, action: () => onNavigate('train') },
    meal: { label: 'Log a meal', icon: 'restaurant' as IconName, action: () => onNavigate('eat') },
    water: { label: 'Drink a glass of water (250 ml)', icon: 'water' as IconName, action: () => onAddWater(250) },
  };
  return (
    <Card style={{ gap: space.md }}>
      <View style={{ gap: 2 }}>
        <AppText variant="heading" header>
          Start here
        </AppText>
        <AppText variant="caption" color={colors.textMuted}>
          Three small steps to get FORM working for you.
        </AppText>
      </View>
      {steps.map((s) => (
        <Pressable
          key={s.key}
          accessibilityRole="button"
          accessibilityLabel={meta[s.key].label}
          accessibilityState={{ checked: s.done }} aria-checked={s.done}
          disabled={s.done}
          onPress={meta[s.key].action}
          style={styles.step}>
          <Ionicons name={s.done ? 'checkmark-circle' : meta[s.key].icon} size={20} color={s.done ? colors.primary : colors.text} />
          <AppText variant="bodyStrong" color={s.done ? colors.textMuted : colors.text} style={{ flex: 1, textDecorationLine: s.done ? 'line-through' : 'none' }}>
            {meta[s.key].label}
          </AppText>
          {s.done ? null : <Ionicons name="chevron-forward" size={18} color={colors.textMuted} />}
        </Pressable>
      ))}
    </Card>
  );
}

/** The day's plan, big and clear, with one action. */
function TodayHero({ today, onNavigate }: { today: NonNullable<HomeViewModel['today']>; onNavigate: HomeViewProps['onNavigate'] }) {
  const s = today.suggestion;
  const last = today.lastWorkout;
  const train = s.kind === 'train';
  return (
    <HeroMedia image={imagery.home} minHeight={train ? 300 : 240}>
      <AppText variant="overline" color={s.kind === 'recover' ? colors.warning : colors.primary}>
        Today
      </AppText>
      <View style={{ gap: 6 }}>
        <AppText variant="display" header>
          {s.title}
        </AppText>
        <AppText variant="body" color={colors.textMuted}>
          {s.reason}
        </AppText>
      </View>
      {today.plannedDaysPerWeek ? <WeekDots done={today.workoutsThisWeek} planned={today.plannedDaysPerWeek} /> : null}
      {s.kind === 'train' || s.kind === 'rest_suggested' ? (
        <Button label={train ? 'Start workout' : 'Train anyway'} iconRight={train ? 'arrow-forward' : undefined} variant={train ? 'primary' : 'secondary'} onPress={() => onNavigate('train')} />
      ) : null}
      {last ? (
        <View style={{ gap: 2 }} accessible accessibilityLabel={`Last session ${shortDate(last.localDate)}`}>
          <AppText variant="label" color={colors.textFaint}>
            Last session · {shortDate(last.localDate)} · {last.durationMinutes} min · +{last.xp} XP
          </AppText>
          {last.exercises.map((e) => (
            <AppText key={e.exerciseId} variant="caption" color={colors.textMuted}>
              {e.name}: {e.sets} {e.sets === 1 ? 'set' : 'sets'}, {e.totalReps} reps{e.bestLoadKg > 0 ? ` · top ${e.bestLoadKg} kg` : ''}
              {e.verifiedReps > 0 ? ` · ${e.verifiedReps} verified` : ''}
            </AppText>
          ))}
        </View>
      ) : null}
    </HeroMedia>
  );
}

/** One dot per planned session this week, filled as they're done. */
function WeekDots({ done, planned }: { done: number; planned: number }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }} accessible accessibilityLabel={`${done} of ${planned} sessions this week`}>
      {Array.from({ length: Math.max(planned, done) }, (_, i) => (
        <View key={i} style={[styles.dot, i < done && { backgroundColor: colors.primary }]} />
      ))}
    </View>
  );
}

function Fuel({ n, onNavigate }: { n: NonNullable<HomeViewModel['nutrition']>; onNavigate: HomeViewProps['onNavigate'] }) {
  const t = n.targets;
  return (
    <Card style={{ gap: space.md }}>
      <AppText variant="bodyStrong">{fuelLine(n)}</AppText>
      <Row style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
        <Row gap={space.xs} style={{ alignItems: 'baseline' }}>
          <AppText variant="number">{n.kcal.toLocaleString()}</AppText>
          <AppText variant="caption" color={colors.textMuted}>
            {t ? `/ ${t.kcal.toLocaleString()} kcal` : 'kcal'}
          </AppText>
        </Row>
        <AppText variant="caption" color={colors.textMuted}>
          {n.mealsLogged} logged
        </AppText>
      </Row>
      {t ? <ProgressBar value={n.kcal / t.kcal} height={6} label="Calories of target" /> : null}
      {t ? (
        <AppText variant="caption" color={colors.textMuted}>
          Carbs {Math.round(n.carbsG)} / {t.carbsG} g · Fat {Math.round(n.fatG)} / {t.fatG} g
        </AppText>
      ) : null}
      {n.kcal > 0 ? (
        <AppText variant="caption" color={n.estimatedKcalShare > 0 ? colors.warning : colors.textFaint}>
          {accuracyLine(n.measuredKcalShare, n.estimatedKcalShare)}
        </AppText>
      ) : null}
      {!t ? (
        <Pressable accessibilityRole="button" onPress={() => onNavigate('profile')}>
          <InlineMessage tone="info">Finish your body profile to get calorie and macro targets →</InlineMessage>
        </Pressable>
      ) : null}
      {n.mealsLogged === 0 ? <Button label="Log your first meal today" icon="add" variant="secondary" onPress={() => onNavigate('eat')} /> : null}
    </Card>
  );
}

function WaterActions({
  w,
  onAdd,
  onUndo,
  busy,
  error,
}: {
  w: NonNullable<HomeViewModel['water']>;
  onAdd: (ml: number) => void;
  onUndo: (id: string) => void;
  busy?: boolean;
  error?: string | null;
}) {
  const done = w.totalMl >= w.targetMl;
  return (
    <View style={{ gap: space.sm }}>
      <Row gap={space.sm}>
        <Button label="+250 ml" icon="water-outline" variant="secondary" onPress={() => onAdd(250)} disabled={busy} style={{ flex: 1 }} />
        <Button label="+500 ml" variant="secondary" onPress={() => onAdd(500)} disabled={busy} style={{ flex: 1 }} />
      </Row>
      <Row style={{ justifyContent: 'space-between' }}>
        <AppText variant="caption" color={colors.textFaint} style={{ flex: 1 }}>
          {done ? 'Water goal met today. ' : ''}
          {w.targetBasis === 'body_weight' ? 'A general guide based on your weight.' : 'A general guide. Add your weight in Profile for a personal one.'} Needs vary with heat and activity.
        </AppText>
        {w.lastEntryId ? (
          <Pressable accessibilityRole="button" accessibilityLabel="Undo last water entry" onPress={() => onUndo(w.lastEntryId!)} disabled={busy} hitSlop={10} style={{ minHeight: 32, justifyContent: 'center' }}>
            <AppText variant="label" color={colors.textMuted}>
              Undo last
            </AppText>
          </Pressable>
        ) : null}
      </Row>
      {error ? <InlineMessage tone="danger">{error}</InlineMessage> : null}
    </View>
  );
}

function QuestRow({ q }: { q: QuestProgress }) {
  return (
    <View style={{ gap: 6, paddingVertical: space.xs }} accessible accessibilityLabel={`${q.title}: ${q.progress} of ${q.target}${q.completed ? ', completed' : ''}, ${q.xpReward} XP`}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Row gap={space.sm} style={{ flex: 1 }}>
          <Ionicons name={q.completed ? 'checkmark-circle' : 'ellipse-outline'} size={20} color={q.completed ? colors.primary : colors.textFaint} />
          <AppText variant="body" color={q.completed ? colors.textMuted : colors.text} style={{ flexShrink: 1 }}>
            {q.title}
          </AppText>
        </Row>
        <AppText variant="label" color={q.completed ? colors.primary : colors.textFaint}>
          +{q.xpReward} XP
        </AppText>
      </Row>
      {!q.completed && q.target > 1 ? <ProgressBar value={q.progress / q.target} height={4} label={`${q.title} progress`} /> : null}
    </View>
  );
}

function Quests({ daily, weekly }: { daily: QuestProgress[]; weekly: QuestProgress[] }) {
  return (
    <Card style={{ gap: space.xs }}>
      {daily.map((q) => (
        <QuestRow key={q.id} q={q} />
      ))}
      {weekly.length > 0 ? (
        <>
          <Divider style={{ marginVertical: space.xs }} />
          <AppText variant="label" color={colors.textFaint}>
            This week
          </AppText>
          {weekly.map((q) => (
            <QuestRow key={q.id} q={q} />
          ))}
        </>
      ) : null}
    </Card>
  );
}

function Level({ p }: { p: NonNullable<HomeViewModel['progression']> }) {
  return (
    <Card style={{ gap: space.sm }}>
      <Row gap={space.md}>
        <RankEmblem rank={p.rank} size={44} />
        <View style={{ flex: 1 }}>
          <AppText variant="heading">
            Level {p.level} · {p.rank}
          </AppText>
          <AppText variant="label" color={colors.textMuted} style={{ fontVariant: ['tabular-nums'] }}>
            {levelLine(p)}
          </AppText>
        </View>
        <Badge label={`Best ${p.streak.longest}`} tone="accent" icon="flame" />
      </Row>
      <ProgressBar value={p.fractionToNext} height={6} label={`Progress to level ${p.level + 1}`} />
      <AppText variant="caption" color={colors.textMuted}>
        {p.xpForNextLevel === 0
          ? 'Max level reached'
          : `${(p.xpForNextLevel - p.xpIntoLevel).toLocaleString()} XP to level ${p.level + 1}${p.nextRank ? ` · ${p.nextRank.name} at level ${p.nextRank.minLevel}` : ''}`}
      </AppText>
      {p.provisionalXp > 0 ? (
        <AppText variant="caption" color={colors.textFaint}>
          Includes {p.provisionalXp} XP from today&apos;s food, confirmed when the day ends.
        </AppText>
      ) : null}
      {p.totalXp > 0 && p.trainWithinDays !== null && p.trainWithinDays <= 2 ? (
        <InlineMessage tone="warning" icon="alert-circle-outline">
          {p.trainWithinDays === 1 ? `Train today to keep Level ${p.level}.` : `Train within 2 days to keep Level ${p.level}.`}
        </InlineMessage>
      ) : null}
    </Card>
  );
}

const styles = StyleSheet.create({
  greeting: { paddingTop: space.sm, paddingBottom: space.xs, alignItems: 'flex-end' },
  dot: { width: 28, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.14)' },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.cardRaised, alignItems: 'center', justifyContent: 'center' },
  step: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: space.md,
    minHeight: 48,
    paddingHorizontal: space.md,
    borderRadius: radius.md,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
});
