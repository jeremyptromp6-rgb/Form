import Ionicons from '@expo/vector-icons/Ionicons';
import { Tabs } from 'expo-router';
import { StyleSheet, useWindowDimensions } from 'react-native';
import { CelebrationHost } from '@/components/recognition/Celebrations';
import type { IconName } from '@/components/ui';
import { breakpoints, colors, fonts } from '@/theme/tokens';

const TABS: { name: string; title: string; icon: IconName; iconActive: IconName }[] = [
  { name: 'index', title: 'Home', icon: 'home-outline', iconActive: 'home' },
  { name: 'train', title: 'Train', icon: 'barbell-outline', iconActive: 'barbell' },
  { name: 'eat', title: 'Eat', icon: 'restaurant-outline', iconActive: 'restaurant' },
  { name: 'progress', title: 'Progress', icon: 'stats-chart-outline', iconActive: 'stats-chart' },
  { name: 'profile', title: 'Profile', icon: 'person-circle-outline', iconActive: 'person-circle' },
];

/** Bottom tabs on phones; a side rail on wide screens (tablets, desktop web). */
export default function TabLayout() {
  const { width } = useWindowDimensions();
  const wide = width >= breakpoints.wide;
  return (
    <>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarPosition: wide ? 'left' : 'bottom',
          tabBarVariant: wide ? 'material' : 'uikit',
          tabBarLabelPosition: wide ? 'beside-icon' : 'below-icon',
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textFaint,
          tabBarStyle: wide
            ? { backgroundColor: colors.bg, borderRightColor: colors.hairline, borderRightWidth: StyleSheet.hairlineWidth, minWidth: 220, paddingTop: 16 }
            : { backgroundColor: colors.bg, borderTopColor: colors.hairline, borderTopWidth: StyleSheet.hairlineWidth },
          tabBarLabelStyle: { fontSize: wide ? 15 : 11, fontFamily: fonts.medium },
          sceneStyle: { backgroundColor: colors.bg },
        }}>
        {TABS.map((t) => (
          <Tabs.Screen
            key={t.name}
            name={t.name}
            options={{
              title: t.title,
              tabBarAccessibilityLabel: t.title,
              tabBarIcon: ({ color, size, focused }) => <Ionicons name={focused ? t.iconActive : t.icon} size={size} color={color} />,
            }}
          />
        ))}
      </Tabs>
      {/* Achievements, streak milestones and Body Quest stages, celebrated once, wherever the user is. */}
      <CelebrationHost />
    </>
  );
}
