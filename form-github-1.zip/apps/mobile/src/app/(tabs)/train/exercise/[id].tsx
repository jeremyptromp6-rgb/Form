import Ionicons from '@expo/vector-icons/Ionicons';
import { router, Stack, useLocalSearchParams, type Href } from 'expo-router';
import { View } from 'react-native';
import { AppText, Badge, Button, Card, ErrorState, Row, Screen, SectionHeader, StateView } from '@/components/ui';
import { livePoseSupport } from '@/lib/pose/support';
import { FormIntelligenceView } from '@/components/pro/ProFeatureViews';
import { ProUpsellFor } from '@/components/pro/ProUpsellFor';
import { proFeatureOf, useFormIntelligence } from '@/lib/pro';
import { useExerciseDetail, useMe } from '@/lib/queries';
import { colors, space } from '@/theme/tokens';

const EQUIPMENT_LABEL = (key: string) => key.replace(/_/g, ' ');
const PR_LABEL: Record<string, string> = { max_load: 'Heaviest', estimated_1rm: 'Est. 1RM', max_reps: 'Most reps' };

/** Exercise detail: how to do it, what it needs, camera requirements, and your history with it. */
export default function ExerciseDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const q = useExerciseDetail(id);
  const poseSupport = livePoseSupport();

  if (q.isError && !q.data) {
    return (
      <Screen title="Exercise">
        {q.error.kind === 'not_found' ? <StateView kind="empty" title="Exercise not found" /> : <ErrorState error={q.error} onRetry={q.refetch} />}
      </Screen>
    );
  }
  if (!q.data) return <Screen title="Exercise"><StateView kind="loading" /></Screen>;
  const { exercise: e, history, records } = q.data;

  return (
    <Screen title={e.name} subtitle={e.pattern.replace(/_/g, ' ')}>
      <Stack.Screen options={{ title: e.name }} />
      <Row gap={space.sm} style={{ flexWrap: 'wrap' }}>
        <Badge label={e.difficulty.charAt(0).toUpperCase() + e.difficulty.slice(1)} tone="neutral" />
        <Badge label={`${e.targetReps.min}–${e.targetReps.max} reps${e.perSide ? ' per side' : ''}`} tone="neutral" />
        {e.cameraVerifiable ? <Badge label="Camera coaching" tone="primary" icon="videocam-outline" /> : null}
      </Row>

      <Card style={{ gap: space.sm }}>
        <AppText variant="label" color={colors.textMuted}>
          Muscles
        </AppText>
        <AppText variant="body">{e.primaryMuscles.join(', ')}</AppText>
        {e.secondaryMuscles.length ? (
          <AppText variant="caption" color={colors.textMuted}>
            Also: {e.secondaryMuscles.join(', ')}
          </AppText>
        ) : null}
        <AppText variant="label" color={colors.textMuted} style={{ marginTop: space.sm }}>
          Equipment
        </AppText>
        <AppText variant="body">{e.equipment.map((alt) => alt.map(EQUIPMENT_LABEL).join(' + ')).join(' or ')}</AppText>
      </Card>

      <SectionHeader title="How to" />
      <Card style={{ gap: space.md }}>
        {e.instructions.map((step, i) => (
          <Row key={i} gap={space.md} style={{ alignItems: 'flex-start' }}>
            <AppText variant="bodyStrong" color={colors.primary} style={{ width: 20 }}>
              {i + 1}
            </AppText>
            <AppText variant="body" style={{ flex: 1 }}>
              {step}
            </AppText>
          </Row>
        ))}
      </Card>

      <Card style={{ gap: space.sm, borderColor: 'rgba(255,181,71,0.35)' }}>
        <Row gap={space.sm}>
          <Ionicons name="shield-checkmark-outline" size={18} color={colors.warning} />
          <AppText variant="bodyStrong">Safety</AppText>
        </Row>
        {e.safety.map((s) => (
          <AppText key={s} variant="caption" color={colors.textMuted}>
            • {s}
          </AppText>
        ))}
      </Card>

      {e.camera ? (
        <Card style={{ gap: space.xs }}>
          <Row gap={space.sm}>
            <Ionicons name="videocam-outline" size={18} color={colors.primary} />
            <AppText variant="bodyStrong">Camera setup</AppText>
          </Row>
          <AppText variant="caption" color={colors.textMuted}>
            {e.camera.setup} FORM tracks your {e.camera.joint} angle on this device; nothing is recorded.
          </AppText>
          {e.cameraVerifiable && poseSupport.available ? (
            <Button
              label="Practise with camera coaching"
              icon="videocam-outline"
              variant="secondary"
              onPress={() => router.push(`/camera?exerciseId=${e.id}` as Href)}
              accessibilityHint="Practice mode — checks your camera setup without logging anything"
              style={{ marginTop: space.sm }}
            />
          ) : null}
        </Card>
      ) : null}

      <SectionHeader title="Your history" />
      {records.length ? (
        <Row gap={space.sm} style={{ flexWrap: 'wrap' }}>
          {records.map((r) => (
            <Badge key={r.kind} label={`${PR_LABEL[r.kind] ?? r.kind}: ${r.value}${r.kind === 'max_reps' ? ' reps' : ' kg'}`} tone="primary" icon="trophy" />
          ))}
        </Row>
      ) : null}
      <Card style={{ gap: space.md }}>
        {history.length === 0 ? (
          <AppText variant="caption" color={colors.textMuted}>
            You haven&apos;t done this one yet.
          </AppText>
        ) : (
          history.map((h) => (
            <View key={h.workoutId} style={{ gap: 2 }}>
              <AppText variant="bodyStrong">{new Date(`${h.localDate}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}</AppText>
              <AppText variant="caption" color={colors.textMuted}>
                {h.sets.map((s) => `${s.reps}${s.loadKg > 0 ? ` × ${s.loadKg} kg` : ''}${s.verifiedReps ? ` (${s.verifiedReps}✓)` : ''}`).join(' · ')}
              </AppText>
            </View>
          ))
        )}
      </Card>

      {e.cameraVerifiable ? <FormHistory exerciseId={e.id} /> : null}
    </Screen>
  );
}

/** FORM Pro: form and range-of-motion history. The server decides access; a 402 shows the upsell instead. */
function FormHistory({ exerciseId }: { exerciseId: string }) {
  const q = useFormIntelligence(exerciseId, 90, true);
  const me = useMe();
  const locked = proFeatureOf(q.error);
  return (
    <>
      <SectionHeader title="Form history" />
      {locked ? <ProUpsellFor feature={locked} /> : null}
      {q.isPending ? <StateView kind="loading" compact /> : null}
      {q.isError && !locked ? <ErrorState error={q.error} onRetry={q.refetch} compact /> : null}
      {q.data ? <FormIntelligenceView data={q.data.intelligence} units={me.data?.settings.units ?? 'metric'} /> : null}
    </>
  );
}
