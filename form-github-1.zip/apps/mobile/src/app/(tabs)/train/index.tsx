import Ionicons from '@expo/vector-icons/Ionicons';
import { router, type Href } from 'expo-router';
import { useState } from 'react';
import { Pressable, View } from 'react-native';
import { AppText, Badge, Button, Card, Divider, ErrorState, HeroMedia, InlineMessage, ListRow, Row, Screen, SectionHeader, StateView } from '@/components/ui';
import { uuid } from '@/lib/dates';
import { useFeature } from '@/lib/features';
import { livePoseSupport } from '@/lib/pose/support';
import { useActiveSession, useExercises, useRefetchOnFocus, useStartSession, useTodayWorkout, useWorkouts } from '@/lib/queries';
import type { PlannedExercise, Progression } from '@/lib/types';
import { sessionTotals } from '@/lib/workoutSession';
import { imagery } from '@/theme/imagery';
import { colors, radius, space } from '@/theme/tokens';

const PROGRESSION_BADGE: Partial<Record<Progression, { label: string; tone: 'primary' | 'warning' | 'neutral' }>> = {
  increase_load: { label: 'Add weight', tone: 'primary' },
  increase_reps: { label: 'Add reps', tone: 'primary' },
  deload: { label: 'Lighter today', tone: 'warning' },
  hold_for_rom: { label: 'Full range first', tone: 'warning' },
  hold_for_form: { label: 'Form first', tone: 'warning' },
};

export default function Train() {
  const today = useTodayWorkout();
  const active = useActiveSession();
  const library = useExercises();
  const history = useWorkouts();
  const camera = useFeature('camera_verification');
  const poseSupport = livePoseSupport();
  // Verification needs both: this device can track, and the server's verification engine is live.
  const verifying = poseSupport.available && camera.available;
  const start = useStartSession();
  const [startError, setStartError] = useState<string | null>(null);
  const refetch = () => Promise.all([today.refetch(), active.refetch(), history.refetch()]);
  useRefetchOnFocus(refetch);

  const begin = () => {
    setStartError(null);
    start.mutate(
      { clientSessionId: uuid(), source: 'plan' },
      {
        onSuccess: () => router.push('/workout' as Href),
        onError: (e) => {
          // Already have one open (e.g. started on another device): resume it instead.
          if (e.code === 'session_open') {
            active.refetch().then(() => router.push('/workout' as Href));
          } else setStartError(e.kind === 'network' ? "Couldn't start — check your connection." : e.message);
        },
      },
    );
  };

  const plan = today.data?.plan;
  const openSession = active.data;

  return (
    <Screen title="Train" subtitle="Today's workout" refreshing={today.isRefetching} onRefresh={refetch}>
      {openSession ? (
        <Pressable accessibilityRole="button" accessibilityLabel="Resume workout in progress" onPress={() => router.push('/workout' as Href)}>
          <Card variant="raised" style={{ gap: space.sm, borderColor: colors.primary, borderWidth: 1 }}>
            <Row style={{ justifyContent: 'space-between' }}>
              <Badge
                label={openSession.leftOpen ? 'Left open' : openSession.status === 'paused' ? 'Paused' : 'In progress'}
                tone={openSession.leftOpen || openSession.status === 'paused' ? 'warning' : 'primary'}
                icon="time-outline"
              />
              <Ionicons name="chevron-forward" size={20} color={colors.text} />
            </Row>
            <AppText variant="heading">{openSession.leftOpen ? 'Finish or discard your last workout' : 'Resume your workout'}</AppText>
            <AppText variant="caption" color={colors.textMuted}>
              {openSession.leftOpen
                ? `${setsLogged(sessionTotals(openSession).sets)} · time away doesn't count`
                : `${setsLogged(sessionTotals(openSession).sets)} · everything is saved`}
            </AppText>
          </Card>
        </Pressable>
      ) : null}

      {today.isPending ? <StateView kind="loading" /> : null}
      {today.isError && !today.data ? <ErrorState error={today.error} onRetry={today.refetch} /> : null}

      {plan ? (
        <View style={{ gap: space.md }}>
          <HeroMedia image={imagery.train} minHeight={200}>
            <AppText variant="overline" color={colors.primary}>
              Today · about {plan.estimatedMinutes} min
            </AppText>
            <AppText variant="title" header style={{ fontSize: 32, lineHeight: 38 }}>
              {plan.title}
            </AppText>
            <AppText variant="caption" color={colors.textMuted}>
              {plan.exercises.length} {plan.exercises.length === 1 ? 'exercise' : 'exercises'} ·{' '}
              {plan.generator.id === 'adaptive' ? 'adapted to your reps, form, range of motion and consistency' : 'built from your goal, equipment and recent sessions'}
            </AppText>
            {plan.generator.id === 'adaptive' ? <Badge label="Adaptive · Pro" tone="primary" icon="sparkles" /> : null}
          </HeroMedia>
          {plan.notes.map((n) => (
            <InlineMessage key={n} tone="warning">
              {n}
            </InlineMessage>
          ))}
          {plan.exercises.length > 0 ? (
            <Card style={{ paddingVertical: space.xs }}>
              {plan.exercises.map((e, i) => (
                <View key={e.exerciseId}>
                  {i > 0 ? <Divider /> : null}
                  <PlanRow e={e} />
                </View>
              ))}
            </Card>
          ) : null}
          {plan.exercises.length === 0 ? (
            <InlineMessage tone="info">No exercises match your equipment yet. Update your training setup in Profile.</InlineMessage>
          ) : null}
          {startError ? <InlineMessage tone="danger">{startError}</InlineMessage> : null}
          {today.data?.completedToday ? (
            <InlineMessage tone="success" icon="checkmark-circle">
              Done for today. Refuel and recover — you can still train again if you planned to.
            </InlineMessage>
          ) : null}
          {!openSession && plan.exercises.length > 0 ? (
            <Button
              label={today.data?.completedToday ? 'Train again' : 'Start workout'}
              iconRight={today.data?.completedToday ? undefined : 'arrow-forward'}
              variant={today.data?.completedToday ? 'secondary' : 'primary'}
              onPress={begin}
              loading={start.isPending}
            />
          ) : null}
        </View>
      ) : null}

      <Card style={{ gap: space.sm }}>
        <Row gap={space.sm}>
          <Ionicons name="videocam-outline" size={18} color={verifying ? colors.primary : colors.textMuted} />
          <AppText variant="bodyStrong" style={{ flex: 1 }}>
            Coaching with your camera
          </AppText>
          <Badge label={verifying ? 'Ready' : 'Not available'} tone={verifying ? 'primary' : 'neutral'} />
        </Row>
        <AppText variant="caption" color={colors.textMuted}>
          {verifying
            ? 'For squats, push-ups, lunges and curls, FORM counts every full-range rep and tells you how your form looks. It all happens on this device — nothing is recorded.'
            : poseSupport.available
              ? "Camera coaching isn't available right now. You can still log every set yourself."
              : poseSupport.message}
        </AppText>
        <AppText variant="caption" color={colors.textFaint}>
          Reps the camera counts earn full XP. Reps you enter yourself earn a little less.
        </AppText>
      </Card>

      <SectionHeader title="Exercise library" />
      <Card style={{ paddingVertical: space.xs }}>
        {library.isError && !library.data ? <ErrorState error={library.error} onRetry={library.refetch} compact /> : null}
        {library.data?.exercises.map((e, i) => (
          <View key={e.id}>
            {i > 0 ? <Divider /> : null}
            <ListRow
              title={e.name}
              subtitle={e.primaryMuscles.join(', ')}
              accessibilityLabel={`${e.name}, ${e.primaryMuscles.join(', ')}`}
              onPress={() => router.push(`/train/exercise/${e.id}` as Href)}
              right={e.cameraVerifiable ? <Ionicons name="videocam-outline" size={16} color={colors.textFaint} accessibilityLabel="Camera coaching available" /> : null}
            />
          </View>
        ))}
      </Card>

      <SectionHeader title="History" />
      <Card style={{ paddingVertical: space.xs }}>
        {!history.data ? (
          history.isError ? <ErrorState error={history.error} onRetry={history.refetch} compact /> : <StateView kind="loading" compact />
        ) : history.data.workouts.length === 0 ? (
          <StateView kind="empty" compact title="No workouts yet" message="Your finished workouts appear here." />
        ) : (
          history.data.workouts.map((w, i) => (
            <View key={w.id}>
              {i > 0 ? <Divider /> : null}
              <ListRow
                title={new Date(`${w.localDate}T12:00:00`).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                subtitle={`${w.durationMinutes} min`}
                onPress={() => router.push(`/train/history/${w.id}` as Href)}
                right={
                  <AppText variant="bodyStrong" color={w.xp > 0 ? colors.primary : colors.textFaint}>
                    +{w.xp} XP
                  </AppText>
                }
              />
            </View>
          ))
        )}
      </Card>
    </Screen>
  );
}

function PlanRow({ e }: { e: PlannedExercise }) {
  const badge = PROGRESSION_BADGE[e.progression];
  const reps = e.targetReps.min === e.targetReps.max ? `${e.targetReps.min}` : `${e.targetReps.min}–${e.targetReps.max}`;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${e.name}: ${e.sets} sets of ${reps} reps${e.targetLoadKg ? ` at ${e.targetLoadKg} kilograms` : ''}`}
      onPress={() => router.push(`/train/exercise/${e.exerciseId}` as Href)}
      style={({ pressed }) => ({ gap: 2, paddingVertical: space.md, minHeight: 56, borderRadius: radius.sm, opacity: pressed ? 0.7 : 1 })}>
      <Row style={{ justifyContent: 'space-between' }}>
        <AppText variant="bodyStrong" style={{ flex: 1 }}>
          {e.name}
        </AppText>
        {badge ? <Badge label={badge.label} tone={badge.tone} /> : null}
      </Row>
      <AppText variant="caption" color={colors.textMuted}>
        {e.sets} × {reps} reps{e.targetLoadKg ? ` @ ${e.targetLoadKg} kg` : ''} · rest {e.restSeconds}s
      </AppText>
      {e.note ? (
        <AppText variant="caption" color={colors.textFaint}>
          {e.note}
        </AppText>
      ) : null}
    </Pressable>
  );
}

const setsLogged = (n: number) => `${n} ${n === 1 ? 'set' : 'sets'} logged`;
