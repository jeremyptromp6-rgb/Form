import { contrastRatio } from './contrast';
import { colors } from './tokens';

const SURFACES = { bg: colors.bg, surface: colors.surface, card: colors.card, cardRaised: colors.cardRaised };

describe('design tokens meet WCAG AA contrast', () => {
  it.each(['text', 'textMuted', 'textFaint'] as const)('%s is at least 4.5:1 on every surface', (token) => {
    for (const [name, bg] of Object.entries(SURFACES)) {
      expect({ on: name, ratio: contrastRatio(colors[token], bg) >= 4.5 }).toEqual({ on: name, ratio: true });
    }
  });

  it.each(['primary', 'accent', 'water', 'purple', 'warning', 'danger'] as const)('%s accent is at least 3:1 (large text / UI) on cards', (token) => {
    expect(contrastRatio(colors[token], colors.card)).toBeGreaterThanOrEqual(3);
  });

  it('text on the primary gradient is readable', () => {
    expect(contrastRatio(colors.onPrimary, colors.primary)).toBeGreaterThanOrEqual(4.5);
    expect(contrastRatio(colors.onPrimary, colors.primaryDeep)).toBeGreaterThanOrEqual(4.5);
  });

  it('computes known reference ratios', () => {
    expect(contrastRatio('#000000', '#FFFFFF')).toBeCloseTo(21, 5);
    expect(contrastRatio('#777777', '#FFFFFF')).toBeCloseTo(4.48, 2);
  });
});
