import { Platform, type TextStyle } from 'react-native';

/**
 * FORM design tokens — human-first and premium. Dark-first, restrained: deep charcoal surfaces,
 * off-white type, one emerald for action and progress, amber for rewards and streaks. Colour
 * carries meaning (primary action, progress, warning) rather than decoration — no neon, no glow.
 */

export const colors = {
  bg: '#0B0F0E',
  surface: '#101514',
  card: '#151B1A',
  cardRaised: '#1C2322',
  border: '#222A29',
  borderStrong: '#2E3736',
  /** Hairline for quiet separators inside cards. */
  hairline: 'rgba(255,255,255,0.06)',
  text: '#F3F4F1',
  textMuted: '#A7AFAB',
  // Lightest text colour allowed for body-size text: ≥ 4.5:1 on card and raised surfaces (WCAG AA).
  textFaint: '#8A938F',
  primary: '#10B981',
  primaryDeep: '#0E9F6E',
  primarySoft: 'rgba(16, 185, 129, 0.14)',
  onPrimary: '#062015',
  /** Rewards, streaks, records. */
  accent: '#F5A524',
  accentSoft: 'rgba(245, 165, 36, 0.14)',
  /** Used sparingly (a secondary series, "label" amounts). */
  purple: '#A39AEC',
  purpleSoft: 'rgba(163, 154, 236, 0.14)',
  water: '#5AA9E6',
  warning: '#F5A524',
  warningSoft: 'rgba(245, 165, 36, 0.14)',
  danger: '#F2626E',
  dangerSoft: 'rgba(242, 98, 110, 0.14)',
} as const;

export const gradients = {
  /** Progress fills only — buttons are solid. */
  primary: ['#14C48B', '#0E9F6E'] as const,
  /** A quiet lift for feature surfaces. */
  hero: ['#1A2321', '#131917'] as const,
  /** Scrim over imagery so type stays readable. */
  scrim: ['rgba(11,15,14,0)', 'rgba(11,15,14,0.55)', 'rgba(11,15,14,0.96)'] as const,
  pro: ['#2A2745', '#161A2B'] as const,
};

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48 } as const;
export const radius = { sm: 10, md: 14, lg: 20, xl: 28, pill: 999 } as const;

/** Accessibility baselines. */
export const a11y = {
  /** Minimum touch target (iOS HIG 44pt, Material 48dp). */
  minTouch: 44,
  /** Cap on OS font scaling for large numeric displays so they don't overflow; body text scales freely. */
  maxNumberScale: 1.4,
} as const;

/** Layout breakpoints (dp). */
export const breakpoints = { wide: 900 } as const;
export const MAX_CONTENT_WIDTH = 640;

/** Inter, loaded in the root layout (system font until it's ready). */
export const fonts = {
  regular: 'Inter_400Regular',
  medium: 'Inter_500Medium',
  semibold: 'Inter_600SemiBold',
  bold: 'Inter_700Bold',
} as const;

// Android picks the weight from the font file; a fontWeight on top would synthesise a fake bold.
const face = (family: string, weight: TextStyle['fontWeight']): TextStyle => (Platform.OS === 'android' ? { fontFamily: family } : { fontFamily: family, fontWeight: weight });

export const type = {
  display: { ...face(fonts.bold, '700'), fontSize: 38, lineHeight: 44, letterSpacing: -1 },
  title: { ...face(fonts.bold, '700'), fontSize: 28, lineHeight: 34, letterSpacing: -0.6 },
  heading: { ...face(fonts.semibold, '600'), fontSize: 19, lineHeight: 25, letterSpacing: -0.2 },
  body: { ...face(fonts.regular, '400'), fontSize: 16, lineHeight: 23 },
  bodyStrong: { ...face(fonts.semibold, '600'), fontSize: 16, lineHeight: 23 },
  caption: { ...face(fonts.regular, '400'), fontSize: 14, lineHeight: 20 },
  /** Quiet sentence-case label ("Protein", "Last session"). */
  label: { ...face(fonts.medium, '500'), fontSize: 13, lineHeight: 18 },
  /** Rare uppercase eyebrow ("NEW PERSONAL RECORD"). */
  overline: { ...face(fonts.semibold, '600'), fontSize: 12, lineHeight: 16, letterSpacing: 1.4, textTransform: 'uppercase' },
  number: { ...face(fonts.bold, '700'), fontSize: 30, lineHeight: 36, letterSpacing: -0.6, fontVariant: ['tabular-nums'] },
} as const satisfies Record<string, TextStyle>;
