# FORM — PROMPT F: REP VERIFICATION + FORM ANALYSIS

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–E.

## Objective
Build FORM's exercise intelligence layer using real landmarks from E.

Architecture:

Camera
→ Pose Detection
→ Landmarks
→ Exercise Analyzer
→ Movement State Machine
→ Rep Verification
→ Form Analysis
→ ROM
→ Live Feedback
→ Verified Rep

## Rep states
Implement exercise-specific state machines.

### Squat
Standing
→ Descending
→ Required Depth
→ Ascending
→ Full Extension
→ Verified Rep +1

### Push-Up
Top
→ Descending
→ Required Depth
→ Ascending
→ Full Extension
→ Verified Rep +1

### Bicep Curl
Extended
→ Curling
→ Required contraction
→ Returning
→ Full extension
→ Verified Rep +1

### Lunge
Standing
→ Descending
→ Required depth
→ Ascending
→ Standing
→ Verified Rep +1

Do not count partial/incomplete movements.

## Distinguish
- attempted rep
- recorded rep
- verified rep

Only verified reps should feed authoritative progression.

## Confidence gating
If:
- confidence is too low
- landmarks are missing
- body is out of frame
- multiple people create ambiguity
- movement cannot be reliably analyzed

do not count the rep.

Prefer:
> Rep not verified

over a false positive.

## ROM
Calculate an exercise-appropriate ROM/amplitude score from available landmarks.

Display:

RANGE OF MOTION
████████░░ 82%

Do not claim unsupported biomechanical precision.

## Form
Calculate 0–100 form score where supported.

### Squat
Consider:
- depth
- knee alignment
- hip/knee angles
- torso position
- stability

### Push-up
Consider:
- body alignment
- elbow position
- depth
- extension
- ROM

### Curl
Consider:
- elbow stability
- extension
- contraction
- ROM

### Lunge
Consider:
- knee position
- depth
- balance
- ROM

## Feedback
Examples:
- CORRECT FORM
- FIX YOUR FORM
- Go slightly deeper
- Keep your back neutral
- Keep your knee aligned
- Control the movement
- Complete the full range
- Keep your elbows stable
- Move farther away so your full body is visible

Prioritize one actionable correction.

Throttle feedback to avoid noise.

## Quality
Track:
- verified reps
- average form
- average ROM
- perfect reps where deterministic

Example:
10 VERIFIED REPS
94 AVG FORM
91% AVG ROM
7 PERFECT REPS

## Robustness
Use temporal validation/hysteresis to avoid jitter and duplicate reps.

Persist authoritative rep metadata sufficient for audit/debugging without storing raw video unnecessarily.

## Integration
Emit clean domain events for later K/L progression.

Do not implement XP/PR/quest business logic here.

## Tests
Use synthetic landmark fixtures for all supported movements and edge cases.

Test:
- full reps
- partial reps
- bad form
- low confidence
- missing landmarks
- occlusion
- multiple people
- duplicate frames
- interruption
- exercise transitions

Add real-device tests where practical.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
