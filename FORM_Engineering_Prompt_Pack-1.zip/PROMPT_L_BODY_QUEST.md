# FORM — PROMPT L: BODY QUEST + ACHIEVEMENTS + PRs + STREAKS

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–K.

## Objective
Build long-term progression visualization and recognition systems.

## Body Quest
Stages:
Starter → Foundation → Builder → Athlete → Elite

Stats:
- Strength
- Muscle
- Endurance
- Mobility
- Form
- Consistency

Create BodyQuestEngine.

Do not make Body Quest solely about body weight or appearance.

Use authoritative data from:
- workouts
- strength/performance
- verified reps
- form
- ROM
- consistency
- nutrition where appropriate

Handle insufficient data honestly.

Store historical snapshots.

## Achievements
Create configurable AchievementEngine.

Required:
- First Rep
- First Workout
- Form Master
- Consistent
- PR Breaker
- Nutrition On Track

States:
- locked
- in progress
- unlocked

Unlock records must be immutable/idempotent.

Achievement XP must flow through K's progression event system.

## PRs
Create PersonalRecord.

Support where data exists:
- heaviest successful weight
- most verified reps
- best form score
- best ROM
- longest consistency streak
- best workout performance

Use metric-aware comparison direction.

PRs must come from authoritative data.

Emit PR XP through K.

## Streaks
Support:
- workout
- nutrition
- quest
- weekly consistency

Use user timezone.

Workout streaks must respect scheduled rest.

Track current and longest streak.

## Integration
Expose useful summaries to:
- Home
- Profile
- Progress
- AI Coach

## UX
Use polished celebrations for:
- achievement
- PR
- streak
- Body Quest milestone

Do not encourage unsafe behavior.

## Tests
Test:
- Body Quest calculations
- snapshots
- achievement unlock
- duplicate unlock
- PR creation
- PR comparison
- streaks
- planned rest
- timezone
- user isolation
- event integrity

Do not implement M+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
