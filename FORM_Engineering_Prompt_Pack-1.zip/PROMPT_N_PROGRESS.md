# FORM — PROMPT N: PROGRESS & ANALYTICS

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–M.

## Objective
Build authoritative progress analytics.

## Ranges
Support:
- 7 days
- 30 days
- 90 days

Use user's authoritative local timezone.

## ProgressAnalyticsService
Create one analytics service using real data from:
- workouts
- form
- ROM
- verified reps
- nutrition
- progression
- PRs
- Body Quest
- streaks
- achievements

## Analytics
Support:
- weight trend where available
- strength progress
- exercise filtering
- form trends
- ROM trends
- verified reps
- workout consistency
- nutrition consistency
- XP progression
- rank
- quest history
- PR history
- Body Quest history

## Trend engine
Use:
- IMPROVING
- STABLE
- DECLINING
- INSUFFICIENT_DATA

Direction must be metric-aware.

Do not fabricate trends, percentiles or body-composition results.

## Summaries
Support daily/weekly/monthly summaries where data exists.

## Charts
Create reusable chart models.

Handle:
- no data
- insufficient data
- partial data
- unit conversion
- timezone boundaries

## Performance
Use efficient queries, indexes, caching and event-driven invalidation where appropriate.

## Goal-aware
Interpret analytics relative to the user's selected goal without making unsupported health claims.

## AI integration
Expose clean analytics context to AI Coach.

## Tests
Test:
- date ranges
- timezone
- strength
- form
- ROM
- insufficient data
- nutrition
- estimated vs measured
- PRs
- streaks
- Body Quest
- XP
- isolation
- unit conversions
- performance

Do not implement O+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
