# FORM — PROMPT K: XP, LEVELS, RANKS & QUESTS

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–J.

## Objective
Build the authoritative progression pipeline.

Architecture:

Validated Domain Event
→ XP Engine
→ XP Event
→ XP Total
→ Level
→ Rank
→ Quest Progress
→ Home/Profile/Progress/AI Coach

## ProgressionEngine
Create one source of truth.

XP must be:
- deterministic
- auditable
- server-authoritative where applicable
- duplicate-resistant
- transactionally consistent

## XP sources
Support meaningful XP from:
- completed workouts
- verified reps
- good form
- ROM
- PRs
- quests
- nutrition consistency
- sustainable behavior

Do not reward unsafe behavior.

Verified rep XP should have sensible caps/diminishing returns.

## XPEvent
Store enough information to audit:
- user
- source
- amount
- domain event
- timestamp
- idempotency key/reference
- metadata where appropriate

Never trust client-submitted XP amounts.

## Quests
Build configurable:
- daily quests
- weekly quests
- quest definitions
- evaluators
- user quest progress
- completion events

Examples:
- Form Master
- Consistency
- Protein Target
- Personal Best

Progress must come from real domain data.

## Level
Use configurable thresholds/curve.

Display:
LEVEL 13 — 2450 / 3000 XP

## Ranks
Exactly:
Rookie → Starter → Athlete → Iron → Elite → Master → Champion

## XP decay
Implement the requested small XP decay for a missed workout day.

Rules:
- deterministic
- once per day maximum
- auditable
- planned rest days do not count as missed
- do not punish unsafe/recovery behavior

## Hard reset
If more than 5 consecutive days pass without a qualifying completed workout:
- reset ACTIVE progression to baseline, e.g. Level 1 / Rookie / 0 XP
- preserve historical workouts
- preserve PRs
- preserve achievements
- preserve nutrition history
- preserve XP event history
- emit dedicated PROGRESSION_RESET event

Do not rewrite historical data.

## Anti-cheat
Client cannot:
- grant XP
- complete quests
- trigger PRs
- modify level/rank
- alter historical events

Use compensating events for corrections instead of rewriting history.

## UI
Create polished RPG-style progression.

## Tests
Test:
- workout XP
- rep XP
- form/ROM XP
- quest completion
- level-up
- rank
- decay
- planned rest
- hard reset
- duplicate requests
- manipulation
- user isolation
- timezone
- concurrency

Do not implement L+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
