# FORM — PROMPT C: HOME COMMAND CENTER

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–B.

## Objective
Build Home as FORM's command center answering:

> What should I do today?

## Home must use real data
No fake numbers.

Display:
- greeting/profile
- current level
- rank
- XP
- today's workout
- previous performance where available
- calories
- protein
- carbs
- fat
- water
- daily/weekly quests
- workout streak
- Body Quest summary
- recent achievements
- progression summary
- AI Coach surface only when a real provider or valid fallback exists
- daily summary

## Aggregation
Build a Home aggregation/view-model layer rather than making the UI assemble dozens of independent queries.

Handle:
- authoritative user timezone
- current local date
- loading
- error
- empty/new-user state
- returning-user state
- stale data
- refresh

## Navigation
Every CTA must route to real:
- Train
- Eat
- Progress
- Profile

## New-user experience
A new user must have a useful first action instead of an empty dashboard.

## Tests
Test:
- new user
- returning user
- date boundaries
- timezone
- aggregation
- navigation
- persistence
- errors
- no duplicate events

Do not build full Train/Eat/camera systems yet.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
