# FORM — PROMPT D: TRAIN & WORKOUT ENGINE

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–C.

## Objective
Build the authoritative workout system.

## Personalization inputs
Use:
- goal
- experience
- equipment
- training frequency
- previous workouts
- strength/performance
- consistency
- form data when available

Create a workout/program generation abstraction so future adaptive training can plug in cleanly.

## Exercise library
Build exercise metadata including:
- name
- muscle groups
- equipment
- movement pattern
- instructions
- target rep range
- safety/visibility requirements where relevant
- camera support capability

Start with at least:
- Bodyweight Squat
- Push-Up
- Bicep Curl
- Lunge

Support gym equipment architecture for future expansion.

## Workout execution
Implement:
- Today's Workout
- exercise detail
- previous performance
- sets/reps/weight
- set entry
- rest timer
- pause/resume
- interruption persistence
- completion
- workout summary
- workout history

Track:
- target reps
- recorded reps
- verified reps separately
- weight
- form score where available
- ROM where available

## Completion
Workout completion must be idempotent.

A retry must not duplicate:
- completion
- future XP
- PRs
- streaks
- quests

Later stages will connect authoritative events.

## Camera contracts
Create clean interfaces such as:
- PoseProvider
- ExerciseAnalyzer
- RepVerifier
- FormAnalyzer
- ROMAnalyzer
- MovementStateMachine

Do not fake camera analysis.

## UX
Mobile-first and excellent during active training:
- large controls
- clear current set
- rest timer
- pause/end
- low distraction

## Security
Users may only access their own workouts.

## Tests
Test:
- generation
- set entry
- previous performance
- pause/resume
- interruption
- completion
- duplicate completion
- history
- authorization
- build

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
