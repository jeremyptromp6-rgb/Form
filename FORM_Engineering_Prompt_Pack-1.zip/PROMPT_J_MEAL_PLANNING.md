# FORM — PROMPT J: MEAL PLANNING + RECIPES + GROCERY LIST

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–I.

## Objective
Build personalized meal planning, recipes and grocery management.

## Inputs
Use:
- goal
- nutrition targets
- dietary preferences
- allergies
- dislikes
- cooking time
- food budget
- existing nutrition architecture

Allergies are hard exclusions.
Dislikes are preferences.

## MealPlan
Create:
- MealPlan
- PlannedMeal
- MealPlanGenerator

Support:
- daily plans
- weekly plans
- editing
- repeats
- planned/eaten distinction

Do not mark a meal eaten merely because it was planned.

## Generation
Prefer real recipe data/provider integration.

If no provider exists:
- use deterministic rule-based generation from real structured recipe data
- never fabricate production recipes/nutrition/prices

Target reasonable nutrition distribution using G.

## Recipes
Support:
- ingredients
- quantities/grams
- instructions
- prep time
- servings
- calories
- protein
- carbs
- fat
- save recipe
- add ingredients to grocery list

Calculate nutrition through I's NutritionCalculator where appropriate.

## Replacement
Replace a meal with another that remains reasonably close in:
- nutrition
- dietary compatibility
- allergies
- cooking time
- budget

## Grocery
Generate grocery list from planned recipes.

Group by:
- protein
- carbohydrates
- produce
- other

Normalize units and aggregate ingredients where safe.

Support:
- check/uncheck
- custom items
- plan-change updates

## Safety
Do not encourage starvation or extreme dieting.

## Tests
Test:
- generation
- allergy exclusion
- dislikes
- dietary preferences
- nutrition targets
- recipe calculations
- replacement
- grocery aggregation
- custom items
- planned vs eaten
- security
- integration

Do not implement K+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
