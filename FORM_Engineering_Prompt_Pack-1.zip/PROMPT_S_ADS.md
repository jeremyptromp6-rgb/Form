# FORM — PROMPT S: ADS / FREE MONETIZATION

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–R.

## Objective
Implement FORM's Free-tier advertising system.

The FORM advertising philosophy is intentionally simple:

> **Let the user finish their workout first.**

Ads should not interfere with training.

## Core ad experience

For a Free user:

START WORKOUT
→ COMPLETE WORKOUT
→ SAVE WORKOUT SUCCESSFULLY
→ APPLY XP / PR / STREAK / QUEST EVENTS
→ SHOW WORKOUT SUMMARY
→ ONE AD
→ HOME

For Pro:

START WORKOUT
→ COMPLETE WORKOUT
→ SAVE WORKOUT
→ XP / PR / STREAK / QUEST
→ WORKOUT SUMMARY
→ NO AD
→ HOME

## Critical rule
The ad must NEVER be part of workout completion.

Workout completion must be committed before the ad is requested.

Correct:

Workout
→ authoritative completion
→ progression
→ summary
→ ad

Never:

Workout
→ ad
→ maybe save workout

## Ad provider
Create:
- AdProvider
- AdService
- AdEligibilityService

Do not couple UI screens directly to a specific advertising SDK.

If using a provider such as Google AdMob, integrate through the abstraction.

## Production vs test
During development:
- use the provider's official test ads
- never use production ad IDs for testing

Production configuration must come from environment/store configuration.

If the provider is not configured:
- the app must continue normally
- do not fake an ad
- report NOT CONFIGURED

## Ad placement
The initial FORM strategy is:

### One post-workout ad per day for Free users

Do not add banners everywhere.

Do not place ads:
- during live workout
- during camera exercise
- during rep verification
- during rest timer
- during set entry
- before workout completion
- over the workout summary
- during safety/error states

The ad should appear after the meaningful workout result has been shown or at the natural transition immediately after it.

## Frequency cap
Maximum:
**one post-workout ad per Free user per local day**

If the user completes multiple workouts in one day:
- do not show multiple post-workout ads
- respect the daily cap

Use authoritative local date/time.

Do not reset the cap at UTC midnight if that would contradict the user's configured timezone.

## Eligibility
An ad may only be eligible when:
- user is Free
- workout was actually completed
- completion is authoritative
- workout is not abandoned
- workout is not invalid
- daily ad cap has not been reached
- ad provider is available

## Pro
Pro users must not receive ads.

Use:
EntitlementService
→ isPro
→ AdService

Do not simply hide an ad in the UI while still making unnecessary ad requests.

## Ad failure
If:
- ad fails to load
- network fails
- provider fails
- ad is unavailable
- SDK errors

the user must continue normally.

Never block:
- workout completion
- XP
- PR
- streak
- quest progress
- Home navigation

An ad failure is not a workout failure.

## State machine
Implement appropriate states such as:
- NOT_ELIGIBLE
- ELIGIBLE
- LOADING
- READY
- SHOWING
- COMPLETED
- DISMISSED
- FAILED

Adapt names to the existing architecture.

## Persistence
Track enough state to enforce the daily cap safely.

Potential concept:
- lastPostWorkoutAdDate
or an auditable ad impression/event model.

Do not allow client manipulation to bypass a server-side policy if the architecture requires server enforcement.

## Account isolation
User A's ad cap must not affect User B.

Test account switching.

## App restart
Test:
- complete workout
- show ad
- kill app
- reopen
- complete another workout
- verify the cap remains correct

## Timezone
Test:
- local midnight
- timezone changes if supported
- device timezone mismatch
- DST transitions where relevant

## Workout completion integration
Do not duplicate workout completion.

The flow should be:

Authoritative WorkoutCompleted event
→ progression consumers
→ workout summary
→ AdEligibilityService
→ AdService

If the workout completion event is replayed:
- do not create another workout
- do not grant duplicate XP
- do not trigger multiple ads

## Premium integration
Verify:
- Free → ad eligible
- Pro → never eligible
- Pro expiration → ads can return according to policy
- Pro purchase during app session → ads stop

## Optional rewarded-ad architecture
Create a clean abstraction for future rewarded ads, but do not add unnecessary rewarded ads now.

Possible future uses:
- optional extra food scan
- optional extra AI Coach usage

Do not implement these unless explicitly required.

## Privacy
Do not send unnecessary fitness/nutrition/camera data to the ad provider.

Review:
- consent
- privacy requirements
- regional requirements
- age/consent requirements where applicable
- ad SDK data collection

Do not make unsupported legal claims.

## Analytics
If analytics exists, support appropriate events:
- POST_WORKOUT_AD_ELIGIBLE
- POST_WORKOUT_AD_REQUESTED
- POST_WORKOUT_AD_LOADED
- POST_WORKOUT_AD_SHOWN
- POST_WORKOUT_AD_DISMISSED
- POST_WORKOUT_AD_FAILED
- POST_WORKOUT_AD_CAPPED

Do not send sensitive health information unnecessarily.

## UI
The ad should feel like a natural transition, not an interruption to exercise.

The workout summary should still be meaningful.

Example:

WORKOUT COMPLETE

42 VERIFIED REPS
94 AVG FORM
91% AVG ROM
+320 XP
NEW PERSONAL RECORD

Then, where eligible:

AD

Then return to Home.

Do not hide important workout results behind an ad.

## Accessibility
Make sure the ad transition does not trap:
- focus
- navigation
- back button
- screen reader users

## Security
Test:
- client attempting to reset ad cap
- Pro user attempting to trigger ad state
- user isolation
- duplicate completion
- duplicate ad event
- provider callbacks

Do not let the client grant itself Pro or manipulate authoritative subscription state.

## Performance
Do not preload ads so aggressively that they:
- waste battery
- consume excessive network
- slow workout startup
- interfere with camera performance

If preloading is used, do it outside active exercise where reasonable.

## Tests

### Free user
- complete workout
- ad appears once
- return Home
- complete another workout same day
- no second ad

### Pro user
- complete workout
- no ad

### Failed provider
- complete workout
- provider fails
- workout still complete
- XP/PR/streak still correct
- Home still opens

### Duplicate completion
- same completion event retried
- no duplicate XP
- no duplicate ad

### App restart
- daily cap survives restart

### Timezone
- cap uses correct user-local day

### Account isolation
- User A cap does not affect User B

### Subscription
- Free → Pro → no ad
- Pro → expired → Free ad policy resumes

## Final verification
Verify the complete journey:

FREE USER
→ WORKOUT
→ COMPLETE
→ RESULTS SAVED
→ XP/PR/STREAK UPDATED
→ ONE POST-WORKOUT AD
→ HOME

Then:

PRO USER
→ WORKOUT
→ COMPLETE
→ RESULTS SAVED
→ XP/PR/STREAK UPDATED
→ NO AD
→ HOME

## Final report
Report:
- ad provider
- test/production configuration
- placement
- frequency cap
- eligibility logic
- Pro exclusion
- privacy/consent handling
- analytics
- tests
- failures
- limitations
- external configuration required

Never claim real production ads are verified unless they have actually been tested with the production configuration.

Finish with:

**IMPLEMENT → INTEGRATE → TEST → FIX → VERIFY → REPORT**
