# FORM — PROMPT E: LIVE CAMERA + POSE DETECTION

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–D.

## Objective
Build the real-time camera/pose foundation for FORM.

The camera must be a real foundation for verified reps and form analysis, not a visual simulation.

## Architecture
Implement:

Camera
→ Pose Detection
→ Body Landmarks
→ Exercise Analyzer contract
→ Rep/Form/ROM consumers

Create provider abstraction such as:
- PoseProvider

The provider should expose timestamped landmarks and confidence information.

## Supported exercises
Initial camera-ready exercises:
1. Bodyweight Squat
2. Push-Up
3. Bicep Curl
4. Lunge

## Live UI
During supported exercises show:
- camera feed
- real moving skeleton/landmark overlay
- exercise name
- current set
- target reps
- verified-rep placeholder/count contract
- form score placeholder/contract
- ROM placeholder/contract
- feedback region
- pause/end

The skeleton must follow real detected landmarks.

## Landmark requirements
Where supported by the provider, expose:
- head
- shoulders
- elbows
- wrists/hands
- hips
- knees
- ankles/feet

Include confidence and timestamp.

## Edge cases
Handle:
- permission denied
- camera unavailable
- no person
- person leaves frame
- multiple people
- low lighting
- too close
- too far
- partial body
- occlusion
- provider failure
- insufficient landmarks

Example feedback:
> Move farther away so your full body is visible.

Do not count reps in this stage unless the existing architecture already requires a safe no-op consumer. Rep verification belongs to F.

## Privacy
Prefer on-device processing where possible.
Do not store raw video unless genuinely required.

## Performance
Optimize:
- frame rate
- battery
- memory
- latency
- UI rendering

Do not block the workout UI on unnecessary network operations.

## Tests
Test provider contracts, permission states, missing landmarks, multiple people, frame interruption and lifecycle.

Where possible, add real-device validation.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
