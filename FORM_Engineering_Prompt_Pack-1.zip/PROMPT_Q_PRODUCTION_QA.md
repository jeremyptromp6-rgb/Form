# FORM — PROMPT Q: PRODUCTION QA, SECURITY, PERFORMANCE & RELEASE

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–P.

## Objective
Perform a production-readiness audit and fix release blockers.

Do not add major new product features.

## Severity
Classify findings:
- P0 — release blocker
- P1 — serious
- P2 — important
- P3 — polish

Fix all P0/P1 release blockers.

## Security audit
Check:
- authentication
- authorization
- IDOR
- mass assignment
- client trust
- progression manipulation
- rate limiting
- input validation
- injection
- XSS where applicable
- insecure storage
- secrets
- API authorization
- user isolation

## AI security
Check:
- prompt injection
- data leakage
- hallucination
- unsafe recommendations
- provider failure
- rate limits
- cost abuse
- context minimization

## Camera
Check:
- permission
- privacy
- false reps
- false verification
- multiple people
- poor lighting
- occlusion
- battery
- memory
- frame rate
- failure recovery

## Food scanner
Check:
- accuracy boundaries
- confidence
- uncertainty
- image handling
- provider failure
- duplicate submissions

## Nutrition
Check:
- units
- conversions
- rounding
- calorie consistency
- measured vs estimated
- allergies
- timezone

## Privacy
Inventory:
- database
- local storage
- cache
- logs
- analytics
- AI
- camera
- exports
- deletion

## Performance
Audit:
- startup
- navigation
- database
- API
- camera
- AI
- memory
- battery
- network

## Accessibility
Check:
- contrast
- typography
- touch targets
- screen readers
- keyboard
- safe areas
- error messaging

## Gamification
Verify:
- XP
- decay
- >5-day hard reset
- quests
- achievements
- PRs
- streaks
- Body Quest
- analytics

## Release
Audit:
- build configuration
- dependencies
- migrations
- environment variables
- crash reporting
- logging
- notifications
- permissions
- feature flags
- backups/recovery
- external dependencies

## Regression
Run the complete end-to-end suite.

Fix issues and rerun tests.

## Final status
Return exactly one:

**READY FOR RELEASE**

or

**NOT READY FOR RELEASE**

Then provide:
- test summary
- security findings
- performance findings
- data integrity
- provider status
- release blockers
- fixes
- tests added
- build artifacts
- external dependencies
- limitations

Finish with:
AUDIT → TEST → FIND → FIX → RETEST → VERIFY → RELEASE REPORT.
