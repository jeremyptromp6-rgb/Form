# FORM — PROMPT P: FULL PRODUCT INTEGRATION

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–O.

## Objective
Connect the entire product into one coherent application.

Inspect the entire repository before changing it.

## Audit every domain
Verify:
- auth
- onboarding
- Home
- workouts
- camera
- pose
- verified reps
- form
- ROM
- PRs
- achievements
- streaks
- XP
- nutrition
- scanner
- weighing
- meal planning
- recipes
- grocery
- AI Coach
- Progress
- Profile
- Settings
- Privacy

## End-to-end journeys
Test complete:
1. new user
2. returning user
3. onboarding
4. today's workout
5. workout execution
6. camera
7. verified rep
8. form/ROM
9. workout completion
10. progression
11. nutrition logging
12. scanner
13. weighing
14. meal planning
15. grocery
16. AI Coach
17. progress
18. profile
19. settings
20. export/deletion

## Critical rules
Verify:
- measured food overrides scanner estimate correctly
- allergies are hard constraints
- goal changes affect future behavior
- unit changes preserve canonical data
- date/time is consistent
- paused/abandoned workouts are handled
- camera failure is recoverable
- scanner failure is recoverable
- AI failure is recoverable
- events are idempotent
- concurrency does not duplicate progression
- users cannot access each other's data

## Reconciliation
Create a safe reconciliation/audit mechanism where needed to detect inconsistent derived state without rewriting historical truth.

## Production data
Remove accidental mocks/fake production values.

Every fallback must be explicitly identified.

## Observability
Verify:
- structured errors
- useful logs
- safe telemetry
- provider status
- important domain event visibility

Never log secrets or sensitive data unnecessarily.

## Performance
Audit:
- database queries
- mobile rendering
- camera performance
- AI latency/cost
- image processing
- network calls

## Accessibility
Audit all major flows.

## Social
Do NOT implement social/global battles/friends in this stage.
Keep architecture future-compatible only.

## E2E
Build a comprehensive automated E2E suite where practical.

Finish with:
IMPLEMENT → INTEGRATE → TEST → FIX → VERIFY → REPORT.
