# FORM — PROMPT H: FOOD SCANNER

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–G.

## Objective
Build the real food-camera workflow:

Point Camera
→ Capture
→ Food Recognition
→ Confidence
→ Estimate Serving
→ Estimate Nutrition
→ Review
→ Confirm
→ Log

## Provider
Create:
FoodRecognitionProvider

Input:
- food image

Output:
- recognized foods
- confidence
- alternatives
- estimated serving
- nutrition reference/source
- uncertainty where supported

If a real provider is not configured:
- create the integration
- provide development/test fallback only
- clearly mark it as development
- never present a fake detector as production AI

## Camera UX
Handle:
- permission
- capture
- retake
- poor image quality
- no food
- unknown food
- multiple foods
- network/provider failure
- timeout

## Review
The user must be able to:
- edit food
- choose alternatives
- change serving
- remove detected item
- review estimated nutrition
- confirm

Display:
**ESTIMATED**

Confidence and nutrition accuracy are separate concepts.

## Multiple foods
Support multiple detected foods and a composite meal where appropriate.

Hidden ingredients/uncertainty must not be presented as exact.

## Nutrition integration
Use G's FoodLog/NutritionCalculator architecture.

Use source:
SCANNED_ESTIMATE

Allow scanner estimate to later be replaced by measured food from I.

## Privacy
Minimize image retention.
Do not upload/store images unnecessarily.

## Idempotency
Duplicate confirmation must not create duplicate logs.

## Tests
Test:
- permissions
- capture
- recognition success
- no food
- low confidence
- multiple foods
- alternatives
- edit
- confirm
- provider failure
- duplicate submission
- privacy
- authorization

Do not implement food weighing here.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
