# FORM — PROMPT M: AI COACH

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–L.

## Objective
Build a real AI coaching layer on top of authoritative FORM data.

## Provider
Create:
AICoachProvider

Provider types:
- REAL_AI_PROVIDER
- DETERMINISTIC_FALLBACK
- UNAVAILABLE

Do not pretend a fallback is real AI.

## CoachContext
Build CoachContextBuilder using only relevant authorized data:
- goal
- experience
- training frequency
- equipment
- recent workouts
- performance
- verified reps
- form
- ROM
- nutrition
- protein/calories
- XP
- rank
- Body Quest
- PRs
- achievements
- streaks
- quests
- local date/time/context

Never send:
- passwords
- auth tokens
- unnecessary PII
- raw camera footage

## CoachResponse
Use structured output such as:
- message
- category
- priority
- evidence
- actions
- confidence
- generatedAt
- provider

Validate AI output before displaying it.

## Coaching
Support:
- daily insight
- Home recommendation
- Coach Chat
- workout coaching
- form coaching
- nutrition coaching
- consistency coaching
- PR coaching
- Body Quest coaching
- progression guidance

Recommendations must be specific and evidence-based.

## Safety
No:
- starvation
- extreme restriction
- unsafe dehydration
- dangerous progression
- medical diagnosis
- mental-state inference
- allergy violations

## Goal-specific
Coaching should adapt to the user's actual goal.

## Actions
AI actions must route to real screens/actions.

## Hallucination controls
Validate:
- numeric claims
- workout claims
- nutrition claims
- PR claims
- streak claims

The domain system remains the source of truth.

## Reliability
Handle:
- provider failure
- malformed output
- timeout
- rate limit
- cost control
- caching

## Privacy
Respect data minimization and retention.

## Tests
Test:
- context building
- provider selection
- hallucination prevention
- numeric validation
- allergy safety
- nutrition safety
- form context
- progression recommendations
- rest-day handling
- user isolation
- rate limiting
- provider failure
- empty user

Do not implement N+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
