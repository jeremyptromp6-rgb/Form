# FORM — PROMPT R: FORM PRO / PREMIUM / SUBSCRIPTIONS & ENTITLEMENTS

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–Q.

## Objective
Build FORM Pro as a real premium coaching layer.

FORM Pro should feel like:
> **Your AI coach, always adapting.**

Do not make Pro merely cosmetic or an ad-removal product.

## Free
Keep Free genuinely useful:
- onboarding
- basic workouts
- workout tracking
- basic verified reps/form where supported
- basic ROM
- nutrition logging
- measured food
- limited food scanning
- basic meal planning
- basic progress
- XP
- levels/ranks
- quests
- Body Quest
- achievements
- PRs
- streaks

## Pro
Unlock deeper:
- Advanced AI Coach
- Adaptive Training
- Advanced Form Intelligence
- expanded/unlimited food scanning according to configured policy
- Advanced Meal Planning
- Advanced Progress Analytics
- Weekly AI Progress Reports
- Advanced Body Quest insights
- deeper recommendations/personalization

## Entitlement architecture
Create a centralized:
- EntitlementService
- subscription state
- premium feature registry

Do not scatter premium checks through UI.

Potential feature IDs:
- AI_COACH_ADVANCED
- ADAPTIVE_TRAINING
- ADVANCED_FORM_ANALYSIS
- ADVANCED_ROM_ANALYSIS
- FOOD_SCANNER_PREMIUM
- MEAL_PLANNER_ADVANCED
- ADVANCED_PROGRESS
- WEEKLY_AI_REPORT
- ADVANCED_BODY_QUEST
- PERSONALIZED_RECOMMENDATIONS

## Billing
Use a provider abstraction.

Support:
- products
- purchase
- restore
- current entitlements
- manage subscription

Target configurations:
- $9.99/month
- $59.99/year

Do not hardcode prices into business logic.

If billing is not configured:
- build the abstraction
- use development/test state only
- never fake production purchases

## Subscription states
Support appropriate provider-backed states such as:
- FREE
- PRO_TRIAL
- PRO_ACTIVE
- PRO_CANCELLED
- PRO_GRACE_PERIOD
- PRO_BILLING_ISSUE
- PRO_EXPIRED

A cancellation request should not remove access before entitlement actually expires.

## Server authority
Where backend exists, enforce Pro access server-side.

The client must not be able to unlock Pro by modifying local state or requests.

## Pro AI Coach
Use actual data from:
- workouts
- verified reps
- form
- ROM
- PRs
- nutrition
- consistency
- XP
- Body Quest
- goals

No invented metrics.

## Adaptive Training
Use real previous performance/form/ROM/consistency.

If performance and form are strong:
- progress appropriately

If performance improves but form declines:
- avoid blindly increasing load

If consistency declines:
- adapt realistically

Core principle:
**Progress when earned.**

## Advanced Form
Where supported, expose:
- form history
- ROM history
- stability trends
- exercise-specific technique trends
- form/ROM relationship with progression

Do not claim unsupported biomechanics.

## Food scanner
Implement configurable Free limits and Pro access.

If a limit is reached:
- show a useful paywall
- keep manual logging available
- do not block measured food

## Meal planning
Pro can use:
- calorie target
- protein target
- goal
- allergies
- dislikes
- dietary preferences
- cooking time
- budget
- remaining daily targets
- saved preferences

## Advanced Progress
Support deeper:
- 30/90-day analysis
- strength trends
- form trends
- ROM trends
- verified rep trends
- nutrition consistency
- workout consistency
- XP
- PR analysis
- Body Quest insights

No fake charts.

## Weekly AI report
Build a Pro weekly report using authoritative data.

Include where available:
- workouts
- verified reps
- average form
- ROM
- PRs
- protein consistency
- XP
- Body Quest
- coach insight

## Paywall
Create reusable premium UI:
- feature/value explanation
- monthly
- annual
- trial if actually configured
- purchase
- restore
- manage subscription
- legal links where required
- errors/loading
- close

Design:
premium, dark, athletic, clean, green/teal, restrained accents.

Do not use manipulative dark patterns.

## Subscription lifecycle
Handle:
- purchase
- restore
- renewal
- cancellation
- expiration
- refund
- billing issue
- grace period
- app restart
- account switching
- supported cross-device restoration

## Webhooks
If provider supports server events:
- verify signatures
- use idempotency
- prevent replay
- update entitlement safely

## Historical data
When Pro expires:
- do not delete history
- preserve workouts
- preserve nutrition
- preserve PRs
- preserve Body Quest history
- preserve reports where policy permits

Only future Pro functionality becomes restricted.

## Security
Test:
- fake entitlement
- modified local storage
- modified API requests
- user isolation
- webhook authenticity
- replay
- duplicate events

## Development billing
If test/sandbox support exists, implement it.

Never ship test credentials or test ad/billing identifiers as production configuration.

## Tests
Test:
- Free
- Pro
- trial
- purchase
- restore
- cancellation
- expiration
- refund
- billing failure
- entitlement refresh
- app restart
- account switch
- server enforcement
- feature gating
- paywall
- weekly report
- AI limits
- scanner limits

## Final report
Report:
- premium features
- free features
- provider
- product IDs
- monthly/annual configuration
- trial
- entitlement architecture
- server validation
- webhook status
- security tests
- billing tests
- production configuration
- limitations
- blockers

Use:
VERIFIED / NOT VERIFIED / NOT CONFIGURED

Never claim billing is production-ready without actual provider verification.

Finish with:
IMPLEMENT → INTEGRATE → TEST → FIX → VERIFY → REPORT.
