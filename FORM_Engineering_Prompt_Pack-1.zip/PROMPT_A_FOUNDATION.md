# FORM — PROMPT A: FOUNDATION & ARCHITECTURE

Read MASTER_ENGINEERING_DIRECTIVE.md first.

You are now implementing **Stage A — Foundation & Architecture**.

## Objective
Create a clean production-grade foundation for FORM without prematurely implementing the advanced camera, food AI or AI Coach systems.

## First inspect
Audit:
- framework
- frontend
- backend
- database
- authentication
- routing
- state management
- API layer
- tests
- build/deploy
- environment configuration
- mocks/TODOs/placeholders

## Build
Establish architecture around:
- Home
- Train
- Eat
- Progress
- Profile

Create clean domain boundaries for:
- auth
- profile
- onboarding
- workouts
- exercises
- camera/pose
- analysis
- nutrition
- food
- meals
- recipes
- grocery
- progression
- XP
- quests
- achievements
- PRs
- streaks
- Body Quest
- AI Coach
- analytics
- settings
- subscriptions/entitlements as a future-compatible boundary
- ads as a future-compatible boundary

## Core data models
Create/improve models for:
- User
- UserProfile
- Workout
- Exercise
- WorkoutSet
- VerifiedRep
- FoodLog
- NutritionTarget
- XPEvent
- Quest
- Achievement
- PersonalRecord
- Streak
- BodyQuest

Use the project's actual ORM/database conventions.

## Requirements
Implement:
- validation
- authorization
- user isolation
- environment configuration
- error handling
- state management
- design-system primitives
- application shell/navigation
- responsive behavior
- accessibility foundation
- test foundation
- build validation

Audit the codebase for fake production data, insecure TODOs, dead routes and duplicate domain logic.

## Do not
Do not implement:
- full live camera
- full food recognition
- full AI Coach
- subscription billing
- production ads

Create clean interfaces where later stages need them.

## Acceptance
The repository must build successfully and have a coherent foundation for B onward.

## Final
Run tests, fix failures, verify the build and report:
IMPLEMENTED / ARCHITECTURE / DATA MODEL / TESTS / BUILD / REMAINING.
