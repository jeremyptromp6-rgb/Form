# FORM — PROMPT I: FOOD WEIGHING + NUTRITION CALCULATIONS

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–H.

## Objective
Build measured-food nutrition with deterministic calculations.

Flow:

Select Food
→ Choose Serving/Unit
→ Enter Weight
→ Calculate Nutrition
→ Review
→ Confirm
→ Log
→ Update Totals

## Measurement
Support where appropriate:
- g
- kg
- oz
- lb
- ml
- L
- cups
- tbsp
- tsp
- item
- serving
- piece

Use gram-first normalization where possible.

## NutritionCalculator
Create one authoritative deterministic calculation engine.

Do not create multiple competing nutrition calculation implementations.

Maintain internal precision and round only for presentation.

## Data provenance
FoodLog should preserve:
- food source
- measurement
- normalized amount
- nutrition basis
- calculated result
- measured/estimated state

Measured food must be clearly:
**MEASURED**

## Scanner replacement
Support:
Scanner estimate
→ User chooses food
→ User weighs food
→ measured entry supersedes the estimate

Do not leave both entries active unless the user explicitly wants both.

## UI
Build polished numeric weight entry with:
- decimal support
- unit selection
- validation
- clear result
- edit
- confirm

## Multiple foods
Support multiple measured ingredients and meal totals.

## Scale provider
Create:
ScaleProvider

States:
- Not connected
- Connecting
- Connected
- Reading weight
- Weight stable
- Error

Do not claim Bluetooth/smart-scale support unless actually implemented.

Manual entry is always available where appropriate.

## Tests
Test:
- conversions
- calculations
- rounding
- serving units
- edit/delete
- scanner replacement
- multiple ingredients
- idempotency
- timezone
- security
- measured vs estimated precedence

Integrate with Eat and Home.

Do not implement J+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
