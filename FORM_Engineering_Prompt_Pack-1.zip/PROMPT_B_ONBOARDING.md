# FORM — PROMPT B: ONBOARDING & USER PROFILE

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompt A.

## Objective
Build premium mobile-first onboarding and the user personalization foundation.

## Collect
Goal — exactly one primary:
- Build Muscle
- Get Stronger
- Lose Fat
- Get Lean / Toned
- Improve Fitness
- Improve Overall Health

Also collect:
- age
- height
- weight
- fitness experience
- training frequency
- available equipment
- Home/Gym/Both
- dietary preferences
- allergies
- disliked foods
- cooking time
- food budget

Treat allergies and dislikes as different concepts.

## Build
Create:
- onboarding flow
- validation
- persistence
- summary/confirmation
- return-user behavior
- personalization profile
- editable Profile foundation
- profile photo if supported, private by default
- weight history foundation
- settings/preferences foundation

Profile should expose:
- profile picture
- goal
- level
- XP
- rank
- Body Quest summary
- achievements
- PRs
- streaks
- workout history
- nutrition preferences
- settings

## Personalization
Create a decoupled personalization layer that future workout, nutrition and AI systems can consume.

Goal changes later must affect future recommendations without rewriting historical data.

## Security
Protect profile ownership and prevent mass assignment.

## UX
Mobile-first, accessible, polished animations, clear validation and save states.

## Tests
Test:
- goal selection
- measurements
- units
- preferences
- allergy/dislike distinction
- persistence
- onboarding completion
- returning users
- profile edits
- authorization

Do not implement full camera, full workout engine, food AI or AI Coach.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
