# FORM — PROMPT O: PROFILE, SETTINGS & PRIVACY

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–N.

## Objective
Build Profile as FORM's private control center.

## Profile
Display real:
- photo
- goal
- level
- XP
- rank
- Body Quest
- achievements
- PR count
- streak
- workout summary
- nutrition summary

## Edit profile
Support:
- name
- photo
- goal
- age
- height
- weight
- experience
- training frequency
- equipment

Goal changes affect future personalization, never historical records.

## Weight
Support weight history and entries.

## Preferences
Support:
- dietary preferences
- allergies
- dislikes
- cooking time
- budget
- equipment

Allergies and dislikes remain separate.

## Units
Create centralized metric/imperial conversion and canonical storage.

## Settings
Support:
- notifications preferences
- timezone/date settings
- AI Coach privacy/settings
- camera permissions/privacy
- food scanner privacy
- account/security
- data/privacy center

Notification preferences must be distinct from OS permissions.

## Privacy center
Implement:
- data export
- account/data deletion
- privacy controls

Exports must be structured and secure.

Deletion must:
- require appropriate re-authentication
- explicitly confirm
- handle failures honestly
- respect provider/data dependencies

Never falsely report deletion success.

## Session
Implement logout/session cleanup and multi-device support only if the architecture supports it.

## Media
Keep private media secure and clean temporary/cache data appropriately.

## Security
Audit:
- mass assignment
- IDOR
- user isolation
- progression protection
- subscription protection
- media access

## Legal
Provide configured terms/privacy links where required.
Do not invent legal claims.

## Tests
Test:
- profile edits
- goal changes
- weight history
- allergies
- units
- timezone
- notification settings
- logout
- export
- deletion
- isolation
- mass assignment
- media
- account switching
- failure states

Do not implement P+.

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
