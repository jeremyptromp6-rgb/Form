# FORM Engineering Prompt Pack

Execution order:

MASTER_ENGINEERING_DIRECTIVE
A → B → C → D → E → F → G → H → I → J → K → L → M → N → O → P → Q → R → S

Use the MASTER directive as the permanent engineering constitution.
Then give Fable/Claude one stage prompt at a time.

Important:
- Do not skip stages.
- Do not claim external providers are configured when they are not.
- Use test billing/ad identifiers during development.
- Run IMPLEMENT → TEST → FIX → VERIFY → REPORT after every stage.
