# FORM — PROMPT G: NUTRITION / EAT SYSTEM

Read MASTER_ENGINEERING_DIRECTIVE.md and Prompts A–F.

## Objective
Build the authoritative nutrition foundation.

## Eat dashboard
Display:
- calories
- protein
- carbs
- fat
- water
- remaining targets
- meals
- nutrition progress

Example:
1840 / 2400 kcal
132 / 180g protein
175 / 260g carbs
54 / 75g fat
1.8 / 3.0L water

Use real data.

## Nutrition targets
Build deterministic target logic using:
- goal
- profile
- training frequency
- relevant measurements
- dietary context

Keep calculations centralized.

## FoodLog
Support:
- food
- quantity
- unit
- calories
- protein
- carbs
- fat
- meal type
- date/time
- source
- estimated/measured state

Sources should distinguish:
- verified database
- user-created
- scanned estimate
- recipe
- manual

## Manual food
Implement:
- search
- details
- serving
- quantity
- log
- edit
- delete
- recent/saved foods where appropriate

## Water
Implement daily water tracking and aggregation.

## Meal types
Support:
- breakfast
- lunch
- dinner
- snack

## Important distinction
Scanner estimates must remain ESTIMATED.
Measured weights must remain MEASURED.

Do not pretend camera estimates are exact.

## Future interfaces
Create contracts for:
- food recognition
- weighing
- meal planning

Do not build their full implementations yet.

## Safety
Allergies are hard exclusions for future recommendation systems.

Do not reward starvation or unsafe calorie restriction.

## Idempotency
Logging/retrying must not create duplicates.

## Integration
Home should receive real nutrition totals.

Create a clean context contract for M/AI Coach.

## Tests
Test:
- targets
- serving calculations
- logging
- editing
- deletion
- date boundaries
- timezone
- idempotency
- user isolation
- water
- estimated/measured distinction

Finish with:
IMPLEMENT → TEST → FIX → VERIFY → REPORT.
