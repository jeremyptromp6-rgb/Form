# FORM — MASTER ENGINEERING DIRECTIVE

## Project
Build **FORM**, a premium AI-powered fitness and nutrition application.

**Tagline:** Train. Eat. Level Up.

FORM combines:
- personalized workouts
- camera-assisted exercise verification
- form and ROM analysis
- nutrition tracking
- food scanning
- measured food weighing
- meal planning
- recipes and grocery lists
- XP, levels and ranks
- quests
- Body Quest
- achievements
- PRs
- streaks
- AI Coach
- progress analytics
- privacy/security
- FORM Pro
- Free-tier advertising

## Engineering role
Act as the lead architect, product engineer, mobile/backend engineer, AI integration engineer, QA engineer, security engineer, performance engineer and release engineer.

Your job is not to give advice. Your job is to build FORM.

## Permanent rule
**IMPLEMENT → TEST → FIX → VERIFY → REPORT**

Inspect the repository before changing it. Reuse existing architecture. Do not rebuild working systems unnecessarily.

## Execution order
MASTER → A → B → C → D → E → F → G → H → I → J → K → L → M → N → O → P → Q → R → S

Each stage must inspect and integrate everything built previously.

## Core product
Navigation:
Home | Train | Eat | Progress | Profile

Visual direction:
- premium
- dark-first
- athletic
- modern
- clean
- high contrast
- rounded cards
- subtle gradients
- green/teal accents
- restrained secondary purple
- strong typography
- polished animations
- mobile-first

## Product principle
FORM must never pretend intelligence exists when it does not.

Examples:
- food camera = estimate, not exact weight
- pose unavailable = do not count a rep
- external AI unavailable = honest unavailable/fallback state
- billing unconfigured = never fake a purchase
- ad provider unavailable = do not pretend an ad was served

## Source-of-truth principle
Use authoritative domain services:
- workout completion → Workout Engine
- verified reps → Rep Verification Engine
- form → Form Analysis Engine
- ROM → ROM Analysis
- nutrition → NutritionCalculator
- XP → ProgressionEngine
- achievements → AchievementEngine
- PRs → PersonalRecord system
- streaks → StreakEngine
- Body Quest → BodyQuestEngine
- AI context → CoachContextBuilder
- premium access → EntitlementService
- ads → AdService

Do not duplicate business logic in UI components.

## Security
Never trust the client for:
- XP
- premium entitlement
- PRs
- verified reps
- progression
- user ownership
- privileged operations

Protect authentication, authorization, user isolation, fitness/nutrition data, camera information, AI data, subscription information and provider secrets.

## Privacy
Keep workouts, nutrition, body data, progress photos, camera information, AI conversations, PRs, achievements, streaks and XP private by default.

Avoid retaining raw camera video unless genuinely required.

## Safety
Never reward:
- starvation
- dangerous dehydration
- unsafe progression
- cheating
- excessive exercise
- exercising through serious injury

Core principle: **Progress when earned.**

## Testing
Every stage must include appropriate unit, integration, authorization, regression and edge-case tests. Add device/E2E/provider tests where relevant.

Every major feature must intentionally handle:
- loading
- success
- empty
- error
- unavailable
- retry
- permission denied
- network/provider failure

## External providers
Use provider abstractions for AI, pose detection, food recognition, billing, ads, analytics and notifications.

If a provider is not configured:
- build the integration boundary
- use development/test fallback only where explicitly appropriate
- never present a fake production integration as real
- report the missing configuration

## Final report
Every stage must report:
1. IMPLEMENTED
2. ARCHITECTURE
3. DATA
4. TESTS
5. VERIFIED
6. EXTERNAL DEPENDENCIES
7. LIMITATIONS
8. NEXT STAGE

## Final command
For every stage:

**IMPLEMENT → TEST → FIX → VERIFY → REPORT**
