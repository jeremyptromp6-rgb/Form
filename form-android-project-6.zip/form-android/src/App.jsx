import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, Radar,
} from "recharts";
import {
  Home as HomeIcon, Dumbbell, UtensilsCrossed, TrendingUp, User, Flame,
  Camera, X, Check, AlertTriangle, ChevronLeft, Plus, Minus,
  Droplets, Trophy, Target, Scale, Sparkles, Play, Info,
  Zap, Award, Lock, ArrowRight, Loader2, ScanLine, Pause, Square, Timer,
  ShieldCheck, WifiOff, Settings as SettingsIcon, RefreshCw, ExternalLink,
} from "lucide-react";
import { storage } from "./storage";
import { useOnlineStatus } from "./network";
import { fetchCoachMessage } from "./coach-api";
import {
  FOOD_DATABASE, CATEGORIES, NUTRITION_SOURCE_LABEL,
  findFood, searchFoods, scaleNutrition, sumNutrition, roundNutrition, nutritionForIngredients,
} from "./foodDatabase";
import { recognizeFood, RECOGNITION_LABELS } from "./foodRecognition";
import { BluetoothScaleProvider, SCALE_STATES } from "./scaleProvider";
import { computeNutritionScore, getNutritionTip, scoreMealCloseness } from "./nutritionCoach";
import {
  dateKey, startOfTodayTs, startOfWeekTs, xpEarnedSince,
  levelForTotalXp, rankForLevel, nextRank, computeStreak, computeBodyStats,
  BODY_QUEST_STAGES, bodyQuestProgress, bodyQuestMilestone,
  generateWeeklyQuests, generateDailyQuests, ACHIEVEMENTS, achievementStats, suggestNextReps,
} from "./progression";
// @capacitor/app ships a web implementation too, so this static import is
// safe both in the native Android build and in `npm run dev` in a browser.
import { App as CapApp } from "@capacitor/app";
// capacitor-native-settings also ships a web fallback (no-ops with a
// console warning on plain web); on Android it opens the OS "App info"
// screen for this app so the user can flip the camera permission.
import { NativeSettings, AndroidSettings } from "capacitor-native-settings";

/* ------------------------------------------------------------------------
   ERROR BOUNDARY
   Catches render-time errors anywhere in the app and shows a recoverable
   screen instead of a blank/crashed WebView.
   ------------------------------------------------------------------------ */
class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error, info) { console.error("FORM crashed:", error, info); }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: "100vh", background: "#0B0F10", color: "#EAF2F1", display: "flex",
          flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14,
          padding: 30, textAlign: "center", fontFamily: "Inter, sans-serif",
        }}>
          <AlertTriangle size={32} color="#FBBF24" />
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", margin: 0 }}>Something went wrong</h2>
          <p style={{ color: "#8CA1A0", fontSize: 13.5, maxWidth: 280, margin: 0 }}>
            FORM hit an unexpected error. Your data is safe — reloading usually fixes this.
          </p>
          <button onClick={() => window.location.reload()} style={{
            marginTop: 6, background: "#2DD4BF", border: "none", color: "#04211D",
            padding: "12px 22px", borderRadius: 12, fontWeight: 700,
          }}>Reload FORM</button>
        </div>
      );
    }
    return this.props.children;
  }
}

function OfflineBanner() {
  const online = useOnlineStatus();
  if (online) return null;
  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 80, maxWidth: 480, margin: "0 auto",
      background: "#3B2E12", borderBottom: "1px solid #6B4E1A", color: "#FBBF24",
      fontSize: 12, fontWeight: 600, padding: "8px 14px", display: "flex", alignItems: "center",
      justifyContent: "center", gap: 6, fontFamily: "Inter, sans-serif",
      paddingTop: "calc(8px + env(safe-area-inset-top, 0px))",
    }}>
      <WifiOff size={13} /> You're offline — AI Coach and food scan sync are unavailable
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* DESIGN TOKENS                                                          */
/* ---------------------------------------------------------------------- */
const C = {
  bg: "#0B0F10",
  bg2: "#10161A",
  card: "#141B1F",
  cardBorder: "#1F2A2E",
  teal: "#2DD4BF",
  tealDim: "#134E4A",
  purple: "#A78BFA",
  purpleDim: "#3B2E5C",
  green: "#4ADE80",
  amber: "#FBBF24",
  red: "#F87171",
  text: "#EAF2F1",
  sub: "#8CA1A0",
  faint: "#4E6362",
};

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap');`;

/* ========================================================================
   POSE PROVIDER
   Real on-device pose estimation via TensorFlow.js + MoveNet, loaded lazily
   from CDN. Runs entirely client-side in the browser — no camera frames are
   ever sent to a server or to an LLM. This is the only layer that touches
   raw video; everything downstream works purely off (x,y,score) keypoints.
   ======================================================================== */
const TFJS_URL = "https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.20.0/dist/tf.min.js";
const POSE_DETECTION_URL = "https://cdn.jsdelivr.net/npm/@tensorflow-models/pose-detection@2.1.3/dist/pose-detection.min.js";

function loadScriptOnce(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[data-src="${src}"]`)) { resolve(); return; }
    const s = document.createElement("script");
    s.src = src; s.async = true; s.dataset.src = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("load-failed"));
    document.body.appendChild(s);
  });
}

let poseDepsPromise = null;
function ensurePoseDependencies() {
  if (!poseDepsPromise) {
    poseDepsPromise = (async () => {
      await loadScriptOnce(TFJS_URL);
      await loadScriptOnce(POSE_DETECTION_URL);
      if (!window.tf || !window.poseDetection) throw new Error("pose-deps-unavailable");
      try { await window.tf.setBackend("webgl"); } catch (e) { await window.tf.setBackend("cpu"); }
      await window.tf.ready();
    })().catch(err => { poseDepsPromise = null; throw err; });
  }
  return poseDepsPromise;
}

let sharedDetectorPromise = null;
function getDetector() {
  if (!sharedDetectorPromise) {
    sharedDetectorPromise = ensurePoseDependencies().then(() =>
      window.poseDetection.createDetector(window.poseDetection.SupportedModels.MoveNet, {
        modelType: window.poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
      })
    ).catch(err => { sharedDetectorPromise = null; throw err; });
  }
  return sharedDetectorPromise;
}

/**
 * usePoseProvider — owns the camera stream + the MoveNet detector + the
 * per-frame inference loop. Reports poses via a callback ref (not React
 * state) so the 30–60fps detection loop never forces a full re-render;
 * only the caller decides when a frame actually needs to reach the UI.
 */
function usePoseProvider(videoRef, active, onFrame, retryKey) {
  const [status, setStatus] = useState("idle");
  // idle | cam-requesting | cam-denied | cam-unavailable | loading-model | model-error | ready
  const rafRef = useRef(null);
  const streamRef = useRef(null);
  const onFrameRef = useRef(onFrame);
  useEffect(() => { onFrameRef.current = onFrame; }, [onFrame]);

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    let detector = null;
    let consecutiveFailures = 0;
    // If inference fails on every single frame for about a second, that's
    // not a "skip one bad frame" situation — the detector itself is broken
    // (e.g. a WebGL context that created but can't actually run), and the
    // previous behavior of silently retrying forever left the camera
    // looking "on" with a permanently dead, invisible skeleton and no way
    // for the person to know. This escalates to the real error screen
    // instead, with a Retry path.
    const MAX_CONSECUTIVE_FAILURES = 25;

    async function start() {
      setStatus("cam-requesting");
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          // No forced width/height "ideal" here on purpose — forcing a
          // resolution the camera hardware has to rescale to is a known
          // cause of corrupted/frozen preview frames on some Android
          // WebViews. Letting the camera pick its own native mode is
          // more reliable; MoveNet works fine at whatever size comes back.
          video: { facingMode: "user" }, audio: false,
        });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          const v = videoRef.current;
          // Setting these as JS properties (not just JSX attributes) right
          // before play() is required on some Android WebView versions —
          // otherwise autoplay can be silently blocked, leaving the video
          // element stuck on a single undecoded/garbled frame.
          v.muted = true;
          v.playsInline = true;
          v.srcObject = stream;
          try {
            await v.play();
          } catch (playErr) {
            // Autoplay can be rejected once right after the permission
            // prompt closes — one retry a beat later resolves it.
            await new Promise(r => setTimeout(r, 300));
            await v.play().catch(() => {});
          }
        }
      } catch (err) {
        if (!cancelled) setStatus(err && err.name === "NotFoundError" ? "cam-unavailable" : "cam-denied");
        return;
      }
      setStatus("loading-model");
      try {
        detector = await getDetector();
        if (cancelled) return;
        // Visible in Android's remote-debugging console (chrome://inspect)
        // so a real failure to get WebGL — a common cause of "camera shows
        // but nothing is ever detected" on some devices — is diagnosable
        // instead of invisible.
        console.log("[FORM pose] detector ready, tf backend:", window.tf?.getBackend?.());
        setStatus("ready");
        loop();
      } catch (err) {
        console.error("[FORM pose] model load failed:", err);
        if (!cancelled) setStatus("model-error");
      }
    }

    async function loop() {
      if (cancelled) return;
      const video = videoRef.current;
      if (video && detector && video.readyState >= 2) {
        try {
          const poses = await detector.estimatePoses(video, { flipHorizontal: false });
          const p = poses && poses[0]
            ? { keypoints: poses[0].keypoints, videoWidth: video.videoWidth, videoHeight: video.videoHeight, t: performance.now() }
            : { keypoints: [], videoWidth: video.videoWidth, videoHeight: video.videoHeight, t: performance.now() };
          consecutiveFailures = 0;
          if (!cancelled) onFrameRef.current && onFrameRef.current(p);
        } catch (e) {
          consecutiveFailures += 1;
          if (consecutiveFailures === 1) console.warn("[FORM pose] inference error:", e);
          if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
            console.error(`[FORM pose] ${MAX_CONSECUTIVE_FAILURES} consecutive inference failures — detector is not usable on this device/context.`);
            if (!cancelled) setStatus("model-error");
            return; // stop the loop; Retry (via retryKey) starts a fresh detector
          }
        }
      }
      rafRef.current = requestAnimationFrame(loop);
    }

    start();
    return () => {
      cancelled = true;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    };
  }, [active, retryKey]); // eslint-disable-line

  return { status };
}

/* ---------------- geometry helpers ---------------- */
function kp(pose, name, minScore = 0.3) {
  if (!pose || !pose.keypoints) return null;
  const k = pose.keypoints.find(p => p.name === name);
  if (!k || k.score == null || k.score < minScore) return null;
  return k;
}
function angleDeg(A, B, C) {
  if (!A || !B || !C) return null;
  const BA = { x: A.x - B.x, y: A.y - B.y };
  const BC = { x: C.x - B.x, y: C.y - B.y };
  const mBA = Math.hypot(BA.x, BA.y), mBC = Math.hypot(BC.x, BC.y);
  if (mBA < 1e-3 || mBC < 1e-3) return null;
  const cos = Math.max(-1, Math.min(1, (BA.x * BC.x + BA.y * BC.y) / (mBA * mBC)));
  return Math.acos(cos) * (180 / Math.PI);
}
function verticalLeanDeg(top, bottom) {
  if (!top || !bottom) return null;
  const v = { x: top.x - bottom.x, y: top.y - bottom.y };
  const mag = Math.hypot(v.x, v.y);
  if (mag < 1e-3) return null;
  const cos = Math.max(-1, Math.min(1, (-v.y) / mag));
  return Math.acos(cos) * (180 / Math.PI);
}
function midpoint(a, b) {
  if (a && b) return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, score: Math.min(a.score, b.score) };
  return a || b || null;
}

/* ========================================================================
   EXERCISE ANALYZER
   One entry per supported exercise: required landmarks, the primary joint
   angle that defines the rep cycle, secondary form metrics, thresholds,
   short live-feedback copy, and a form-scoring function. New exercises are
   added by extending this object — nothing else needs to change.
   ======================================================================== */
const EXERCISES = {
  squat: {
    name: "Bodyweight Squat",
    viewHint: "Face the camera, full body in frame",
    required: ["left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle", "left_shoulder", "right_shoulder"],
    topAngle: 160, bottomAngle: 110, minRepMs: 700,
    getMetrics(pose) {
      const angles = [];
      const lA = angleDeg(kp(pose, "left_hip"), kp(pose, "left_knee"), kp(pose, "left_ankle"));
      const rA = angleDeg(kp(pose, "right_hip"), kp(pose, "right_knee"), kp(pose, "right_ankle"));
      if (lA != null) angles.push(lA);
      if (rA != null) angles.push(rA);
      if (!angles.length) return null;
      const primary = angles.reduce((a, b) => a + b, 0) / angles.length;
      const sh = midpoint(kp(pose, "left_shoulder"), kp(pose, "right_shoulder"));
      const hip = midpoint(kp(pose, "left_hip"), kp(pose, "right_hip"));
      const torsoLean = verticalLeanDeg(sh, hip);
      const lKnee = kp(pose, "left_knee"), rKnee = kp(pose, "right_knee");
      const lAnkle = kp(pose, "left_ankle"), rAnkle = kp(pose, "right_ankle");
      let valgus = 0;
      if (lKnee && lAnkle && rKnee && rAnkle) {
        const stance = Math.abs(lAnkle.x - rAnkle.x) || 1;
        const kneeGap = Math.abs(lKnee.x - rKnee.x);
        valgus = Math.max(0, (stance - kneeGap) / stance);
      }
      return { primary, torsoLean, valgus };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return m.valgus > 0.35 ? "Knees aligned" : (m.torsoLean != null && m.torsoLean > 35 ? "Chest up" : "Go deeper");
      if (phase === "BOTTOM") return "Good depth — drive up";
      if (phase === "ASCENDING") return "Full extension";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 15 - (110 - rep.minAngle));
      if (rep.avgTorsoLean != null && rep.avgTorsoLean > 25) s -= Math.min(20, (rep.avgTorsoLean - 25) * 0.8);
      if (rep.maxValgus != null && rep.maxValgus > 0.3) s -= Math.min(20, (rep.maxValgus - 0.3) * 60);
      if (rep.durationMs < 1000) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
  pushup: {
    name: "Push-Up",
    viewHint: "Turn side-on to the camera, full body in frame",
    required: ["left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip"],
    topAngle: 155, bottomAngle: 95, minRepMs: 600,
    getMetrics(pose) {
      const sides = [
        { sh: kp(pose, "left_shoulder"), el: kp(pose, "left_elbow"), wr: kp(pose, "left_wrist"), hip: kp(pose, "left_hip"), an: kp(pose, "left_ankle") },
        { sh: kp(pose, "right_shoulder"), el: kp(pose, "right_elbow"), wr: kp(pose, "right_wrist"), hip: kp(pose, "right_hip"), an: kp(pose, "right_ankle") },
      ];
      const angles = []; let bodyAngle = null;
      sides.forEach(s => {
        const a = angleDeg(s.sh, s.el, s.wr);
        if (a != null) angles.push(a);
        if (bodyAngle == null) { const ba = angleDeg(s.sh, s.hip, s.an); if (ba != null) bodyAngle = ba; }
      });
      if (!angles.length) return null;
      const primary = angles.reduce((a, b) => a + b, 0) / angles.length;
      const alignment = bodyAngle == null ? 0 : Math.abs(180 - bodyAngle);
      return { primary, alignment };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return m.alignment > 20 ? "Hips level" : "Go lower";
      if (phase === "BOTTOM") return "Push up — full extension";
      if (phase === "ASCENDING") return "Elbows in";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 15 - (95 - rep.minAngle));
      if (rep.avgAlignment != null && rep.avgAlignment > 15) s -= Math.min(25, (rep.avgAlignment - 15) * 1.1);
      if (rep.durationMs < 800) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
  bicepcurl: {
    name: "Bicep Curl",
    viewHint: "Face the camera, arms visible at your sides",
    required: ["left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist"],
    topAngle: 150, bottomAngle: 60, minRepMs: 600,
    getMetrics(pose) {
      const angles = []; const drifts = [];
      const lSh = kp(pose, "left_shoulder"), lEl = kp(pose, "left_elbow"), lWr = kp(pose, "left_wrist");
      const rSh = kp(pose, "right_shoulder"), rEl = kp(pose, "right_elbow"), rWr = kp(pose, "right_wrist");
      const lHip = kp(pose, "left_hip"), rHip = kp(pose, "right_hip");
      const scale = (lSh && lHip) ? Math.hypot(lSh.x - lHip.x, lSh.y - lHip.y) : ((rSh && rHip) ? Math.hypot(rSh.x - rHip.x, rSh.y - rHip.y) : 100);
      const lA = angleDeg(lSh, lEl, lWr); if (lA != null) { angles.push(lA); if (lSh && lEl) drifts.push(Math.abs(lEl.x - lSh.x) / scale); }
      const rA = angleDeg(rSh, rEl, rWr); if (rA != null) { angles.push(rA); if (rSh && rEl) drifts.push(Math.abs(rEl.x - rSh.x) / scale); }
      if (!angles.length) return null;
      const primary = angles.reduce((a, b) => a + b, 0) / angles.length;
      const drift = drifts.length ? Math.max(...drifts) : 0;
      return { primary, drift };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return "Control the movement";
      if (phase === "BOTTOM") return m.drift > 0.55 ? "Keep elbows stable" : "Full contraction";
      if (phase === "ASCENDING") return "Full extension";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 12 - (60 - rep.minAngle));
      if (rep.maxDrift != null && rep.maxDrift > 0.5) s -= Math.min(25, (rep.maxDrift - 0.5) * 50);
      if (rep.durationMs < 800) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
  lunge: {
    name: "Reverse Lunge",
    viewHint: "Turn side-on to the camera, full body in frame",
    required: ["left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle", "left_shoulder", "right_shoulder"],
    topAngle: 160, bottomAngle: 100, minRepMs: 700,
    getMetrics(pose) {
      const lA = angleDeg(kp(pose, "left_hip"), kp(pose, "left_knee"), kp(pose, "left_ankle"));
      const rA = angleDeg(kp(pose, "right_hip"), kp(pose, "right_knee"), kp(pose, "right_ankle"));
      const avail = [lA, rA].filter(v => v != null);
      if (!avail.length) return null;
      const primary = Math.min(...avail);
      const sh = midpoint(kp(pose, "left_shoulder"), kp(pose, "right_shoulder"));
      const hip = midpoint(kp(pose, "left_hip"), kp(pose, "right_hip"));
      const torsoLean = verticalLeanDeg(sh, hip);
      return { primary, torsoLean, hipX: hip ? hip.x : null };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return m.torsoLean != null && m.torsoLean > 30 ? "Torso upright" : "Go deeper";
      if (phase === "BOTTOM") return "Good depth — drive up";
      if (phase === "ASCENDING") return "Control your balance";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 15 - (100 - rep.minAngle));
      if (rep.avgTorsoLean != null && rep.avgTorsoLean > 25) s -= Math.min(20, (rep.avgTorsoLean - 25) * 0.8);
      if (rep.sway > 0.18) s -= Math.min(15, (rep.sway - 0.18) * 80);
      if (rep.durationMs < 1000) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
};

const SKELETON_EDGES = [
  ["left_shoulder", "right_shoulder"], ["left_shoulder", "left_elbow"], ["left_elbow", "left_wrist"],
  ["right_shoulder", "right_elbow"], ["right_elbow", "right_wrist"],
  ["left_shoulder", "left_hip"], ["right_shoulder", "right_hip"], ["left_hip", "right_hip"],
  ["left_hip", "left_knee"], ["left_knee", "left_ankle"], ["right_hip", "right_knee"], ["right_knee", "right_ankle"],
];

/* ========================================================================
   VISIBILITY / SAFETY GATE
   Refuses to feed the rep verifier anything unless the required landmarks
   are confidently visible, the subject is a reasonable distance from the
   camera, and average tracking confidence is high enough to trust.
   ======================================================================== */
function checkVisibility(pose, exerciseKey) {
  const cfg = EXERCISES[exerciseKey];
  if (!pose || !pose.keypoints || !pose.keypoints.length) {
    return { ok: false, reason: "no-person", message: "No person detected — step into frame." };
  }
  const avgScore = pose.keypoints.reduce((a, k) => a + (k.score || 0), 0) / pose.keypoints.length;
  if (avgScore < 0.15) return { ok: false, reason: "no-person", message: "No person detected — step into frame." };
  const missing = cfg.required.filter(name => !kp(pose, name, 0.3));
  if (missing.length) return { ok: false, reason: "out-of-frame", message: "Move back so your full body is visible." };
  const visible = pose.keypoints.filter(k => k.score >= 0.3);
  const ys = visible.map(k => k.y);
  const bboxH = Math.max(...ys) - Math.min(...ys);
  const ratio = pose.videoHeight ? bboxH / pose.videoHeight : 0.5;
  if (ratio > 0.97) return { ok: false, reason: "too-close", message: "Step back — you're too close to the camera." };
  if (ratio < 0.2) return { ok: false, reason: "too-far", message: "Move closer to the camera." };
  if (avgScore < 0.35) return { ok: false, reason: "low-confidence", message: "We can't clearly see your movement — check lighting or angle." };
  return { ok: true };
}

/* ========================================================================
   REP VERIFIER
   Exercise-specific movement state machine:
   TOP -> DESCENDING -> BOTTOM(required depth) -> ASCENDING -> TOP (+1 rep)
   A rep is counted ONLY when required depth was reached, the full cycle
   returned to the top position, the whole cycle took at least minRepMs,
   and visibility held throughout. Anything else resets to TOP uncounted.
   No timer-based or manual increment exists anywhere in this module.
   ======================================================================== */
function createRepVerifier(exerciseKey) {
  const cfg = EXERCISES[exerciseKey];
  let phase = "TOP";
  let smoothed = null;
  let repStart = 0;
  let reachedDepth = false;
  let samples = [];

  function reset() { phase = "TOP"; smoothed = null; reachedDepth = false; samples = []; }

  function update(metrics, now, visible) {
    if (!metrics || !visible) {
      if (phase !== "TOP") {
        reset();
        return { event: "aborted", phase, feedback: "We lost sight of you — reposition to continue.", tone: "warn" };
      }
      return { event: "none", phase, feedback: cfg.viewHint, tone: "neutral" };
    }

    const raw = metrics.primary;
    smoothed = smoothed == null ? raw : smoothed * 0.65 + raw * 0.35;
    const TOP = cfg.topAngle, BOTTOM = cfg.bottomAngle;
    let event = "none";

    if (phase === "TOP") {
      if (smoothed <= TOP - 8) { phase = "DESCENDING"; repStart = now; reachedDepth = false; samples = [metrics]; }
    } else {
      samples.push(metrics);
      if (phase === "DESCENDING") {
        if (smoothed <= BOTTOM) { phase = "BOTTOM"; reachedDepth = true; }
        else if (smoothed >= TOP) { phase = "TOP"; samples = []; }
      } else if (phase === "BOTTOM") {
        if (smoothed >= BOTTOM + 10) phase = "ASCENDING";
      } else if (phase === "ASCENDING") {
        if (smoothed >= TOP) {
          const durationMs = now - repStart;
          const minAngle = Math.min(...samples.map(s => s.primary));
          if (reachedDepth && durationMs >= cfg.minRepMs) {
            const rep = summarizeRep(exerciseKey, samples, minAngle, durationMs);
            reset();
            return { event: "verified", phase, rep, feedback: cfg.feedback("TOP", metrics), tone: "good" };
          }
          reset();
          return { event: "rejected", phase, feedback: "REP NOT COUNTED — Complete the movement", tone: "warn" };
        } else if (smoothed <= BOTTOM) {
          phase = "BOTTOM";
        }
      }
    }
    return { event, phase, feedback: cfg.feedback(phase, metrics), tone: "neutral" };
  }

  return { update, reset };
}

/* ========================================================================
   FORM ANALYZER
   Converts a completed rep's sampled metrics into a 0–100 form score.
   Heuristic and intentionally conservative — this is movement guidance,
   not a clinical or medical-grade biomechanical assessment.
   ======================================================================== */
function summarizeRep(exerciseKey, samples, minAngle, durationMs) {
  const rep = { minAngle, durationMs };
  const avg = (key) => {
    const vals = samples.map(s => s[key]).filter(v => v != null);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  };
  const max = (key) => {
    const vals = samples.map(s => s[key]).filter(v => v != null);
    return vals.length ? Math.max(...vals) : null;
  };
  rep.avgTorsoLean = avg("torsoLean");
  rep.avgAlignment = avg("alignment");
  rep.maxValgus = max("valgus");
  rep.maxDrift = max("drift");
  const hipXVals = samples.map(s => s.hipX).filter(v => v != null);
  rep.sway = hipXVals.length > 1 ? (Math.max(...hipXVals) - Math.min(...hipXVals)) / 260 : 0;
  rep.formScore = EXERCISES[exerciseKey].score(rep);
  return rep;
}

/* ---------------------------------------------------------------------- */
/* WORKOUT PLAN + NUTRITION TARGETS                                        */
/* Real, computed logic — not mock data. Workout reps adapt per exercise   */
/* via progression.js; nutrition macros are always derived from            */
/* foodDatabase.js, never hardcoded on a screen.                           */
/* ---------------------------------------------------------------------- */
const BASELINE_REPS = { squat: 12, pushup: 10, bicepcurl: 12, lunge: 10 };
function buildWorkoutPlan(profile) {
  const setsCount = profile.level === "Beginner" ? 3 : profile.level === "Intermediate" ? 4 : 5;
  const defs = [
    { key: "squat", reps: BASELINE_REPS.squat },
    { key: "pushup", reps: BASELINE_REPS.pushup },
    { key: "bicepcurl", reps: BASELINE_REPS.bicepcurl },
    { key: "lunge", reps: BASELINE_REPS.lunge },
  ];
  return defs.map(d => ({ id: d.key, key: d.key, name: EXERCISES[d.key].name, sets: setsCount, reps: d.reps }));
}

const LOAD_PER_REP = { squat: 0.9, pushup: 0.64, lunge: 0.5, bicepcurl: 0 };
function estimateLoad(key, reps, bodyweight) {
  if (key === "bicepcurl") return reps * 12;
  return Math.round(reps * bodyweight * LOAD_PER_REP[key]);
}

function buildNutritionTargets(profile) {
  const w = profile.weight || 75;
  let calories, protein;
  if (profile.goal === "Lose Fat") { calories = Math.round(w * 24); protein = Math.round(w * 2.0); }
  else if (profile.goal === "Build Muscle" || profile.goal === "Get Stronger") { calories = Math.round(w * 32); protein = Math.round(w * 2.0); }
  else { calories = Math.round(w * 28); protein = Math.round(w * 1.7); }
  const fat = Math.round((calories * 0.27) / 9);
  const carbs = Math.round((calories - protein * 4 - fat * 9) / 4);
  // ~33ml per kg bodyweight is a common general-population heuristic, not
  // a medical prescription — presented as a starting target, editable.
  const water = Math.round(w * 0.033 * 10) / 10;
  return { calories, protein, carbs, fat, water };
}

// MEAL LIBRARY — every meal is a list of {foodId, grams} ingredients from
// FOOD_DATABASE. Macros are always computed from those ingredients via
// nutritionForIngredients(), never stored as static numbers on the meal
// itself, so grams edits, ingredient swaps, and grocery-list generation
// all stay correct automatically.
const MEAL_LIBRARY = [
  { name: "Greek Yogurt Bowl", tag: "Breakfast", time: "10 min",
    ingredients: [{ foodId: "greek_yogurt", grams: 200 }, { foodId: "banana", grams: 100 }, { foodId: "oats", grams: 30 }] },
  { name: "Veggie Egg Scramble", tag: "Breakfast", time: "12 min",
    ingredients: [{ foodId: "eggs", grams: 150 }, { foodId: "spinach", grams: 40 }, { foodId: "sourdough", grams: 40 }] },
  { name: "Grilled Chicken & Rice", tag: "Lunch", time: "20 min",
    ingredients: [{ foodId: "chicken_breast", grams: 180 }, { foodId: "white_rice", grams: 200 }, { foodId: "broccoli", grams: 100 }] },
  { name: "Turkey Avocado Wrap", tag: "Lunch", time: "10 min",
    ingredients: [{ foodId: "turkey_breast", grams: 120 }, { foodId: "sourdough", grams: 60 }, { foodId: "avocado", grams: 50 }] },
  { name: "Salmon & Sweet Potato", tag: "Dinner", time: "25 min",
    ingredients: [{ foodId: "salmon", grams: 160 }, { foodId: "sweet_potato", grams: 180 }, { foodId: "asparagus", grams: 100 }] },
  { name: "Tofu Stir-Fry", tag: "Dinner", time: "20 min",
    ingredients: [{ foodId: "tofu", grams: 200 }, { foodId: "white_rice", grams: 150 }, { foodId: "broccoli", grams: 120 }] },
  { name: "Protein Smoothie", tag: "Snack", time: "5 min",
    ingredients: [{ foodId: "protein_powder", grams: 32 }, { foodId: "banana", grams: 118 }, { foodId: "greek_yogurt", grams: 100 }] },
  { name: "Yogurt & Oats", tag: "Snack", time: "5 min",
    ingredients: [{ foodId: "greek_yogurt", grams: 150 }, { foodId: "oats", grams: 30 }, { foodId: "banana", grams: 60 }] },
];

function mealWithMacros(template, idSuffix) {
  const macros = nutritionForIngredients(template.ingredients);
  return { ...template, id: `${template.name.replace(/\s+/g, "_").toLowerCase()}_${idSuffix}`, ...macros, logged: false };
}

function buildMealPlan(profile) {
  const avoid = (profile.dislikes || "").toLowerCase().split(",").map(s => s.trim()).filter(Boolean);
  const containsAvoided = (template) => template.ingredients.some(ing => {
    const food = findFood(ing.foodId);
    return food && avoid.some(a => food.name.toLowerCase().includes(a));
  });
  const pool = MEAL_LIBRARY.filter(m => !containsAvoided(m));
  const slots = ["Breakfast", "Lunch", "Dinner", "Snack"];
  return slots.map((slot, i) => {
    const candidates = pool.filter(m => m.tag === slot);
    const template = candidates[i % Math.max(candidates.length, 1)] || pool[i % pool.length];
    return mealWithMacros(template, i);
  });
}

// Nutrition-aware "Replace Meal": ranks same-slot alternatives by how
// close their macros are to the meal being replaced, instead of swapping
// in something random — per the "stay reasonably close to target" rule.
function findReplacementMeal(currentMeal) {
  const candidates = MEAL_LIBRARY.filter(m => m.tag === currentMeal.tag && m.name !== currentMeal.name);
  const pool = candidates.length ? candidates : MEAL_LIBRARY.filter(m => m.tag === currentMeal.tag);
  const scored = pool.map(template => {
    const macros = nutritionForIngredients(template.ingredients);
    return { template, macros, score: scoreMealCloseness(macros, currentMeal.cals, currentMeal.protein) };
  }).sort((a, b) => a.score - b.score);
  const pick = scored[0] || { template: currentMeal, macros: currentMeal };
  return { ...pick.template, id: currentMeal.id, tag: currentMeal.tag, ...pick.macros, logged: false };
}

/* ---------------------------------------------------------------------- */
/* SHARED UI PRIMITIVES                                                    */
/* ---------------------------------------------------------------------- */
function Card({ children, style, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: `linear-gradient(180deg, ${C.card} 0%, #101619 100%)`,
      border: `1px solid ${C.cardBorder}`, borderRadius: 18, padding: 16, ...style,
    }}>
      {children}
    </div>
  );
}
function ProgressBar({ value, max, color = C.teal, height = 8, bg = "#1A2327" }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ width: "100%", height, borderRadius: height, background: bg, overflow: "hidden" }}>
      <div style={{ width: `${pct}%`, height: "100%", borderRadius: height, background: color, transition: "width .5s ease" }} />
    </div>
  );
}
function Pill({ children, color = C.teal, bg = null }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 600,
      padding: "4px 9px", borderRadius: 999, color, background: bg || `${color}22`,
      fontFamily: "Inter, sans-serif", letterSpacing: 0.2,
    }}>{children}</span>
  );
}
function ScreenHeader({ title, subtitle, right }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
      <div>
        <h1 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 26, fontWeight: 700, margin: 0, color: C.text }}>{title}</h1>
        {subtitle && <p style={{ color: C.sub, fontSize: 13.5, margin: "4px 0 0", fontFamily: "Inter, sans-serif" }}>{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* ONBOARDING                                                              */
/* ---------------------------------------------------------------------- */
function Onboarding({ onComplete }) {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    goal: null, age: "", height: "", weight: "", level: null,
    daysPerWeek: null, equipment: null, dislikes: "", allergies: "",
    cookingTime: null, budget: null,
  });
  const steps = ["goal", "level", "stats", "schedule", "equipment", "food", "review"];
  const total = steps.length;
  const set = (k, v) => setData(d => ({ ...d, [k]: v }));
  const STAT_BOUNDS = {
    age: { min: 13, max: 100, label: "Age must be between 13 and 100" },
    height: { min: 100, max: 250, label: "Height must be between 100 and 250 cm" },
    weight: { min: 30, max: 300, label: "Weight must be between 30 and 300 kg" },
  };
  const statError = (k) => {
    const raw = data[k];
    if (raw === "" || raw == null) return null; // empty is handled by the disabled-Continue state, not an inline error
    const n = Number(raw);
    const b = STAT_BOUNDS[k];
    if (!Number.isFinite(n) || n < b.min || n > b.max) return b.label;
    return null;
  };
  const statValid = (k) => data[k] !== "" && !statError(k);
  const canNext = () => {
    switch (steps[step]) {
      case "goal": return !!data.goal;
      case "level": return !!data.level;
      case "stats": return statValid("age") && statValid("height") && statValid("weight");
      case "schedule": return !!data.daysPerWeek;
      case "equipment": return !!data.equipment;
      case "food": return !!data.cookingTime;
      default: return true;
    }
  };
  const OptionGrid = ({ options, field, cols = 2 }) => (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 10, marginTop: 20 }}>
      {options.map(opt => {
        const active = data[field] === opt;
        return (
          <button key={opt} onClick={() => set(field, opt)} style={{
            padding: "16px 12px", borderRadius: 14, textAlign: "left",
            border: `1.5px solid ${active ? C.teal : C.cardBorder}`,
            background: active ? `${C.teal}14` : C.card,
            color: active ? C.teal : C.text, fontFamily: "Inter, sans-serif",
            fontWeight: 600, fontSize: 14, cursor: "pointer", transition: "all .15s",
          }}>{opt}</button>
        );
      })}
    </div>
  );
  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ padding: "24px 20px 0" }}>
        <div style={{ display: "flex", gap: 6, marginBottom: 22 }}>
          {steps.map((_, i) => <div key={i} style={{ flex: 1, height: 4, borderRadius: 4, background: i <= step ? C.teal : "#1A2327", transition: "background .3s" }} />)}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <div style={{ width: 30, height: 30, borderRadius: 9, background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Zap size={16} color="#0B0F10" strokeWidth={2.5} />
          </div>
          <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 16 }}>FORM</span>
        </div>
      </div>
      <div style={{ flex: 1, padding: "20px 20px 100px", overflowY: "auto" }}>
        {steps[step] === "goal" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>What's your main goal?</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>We'll build your training and nutrition plan around this.</p>
          <OptionGrid field="goal" cols={2} options={["Build Muscle", "Get Stronger", "Lose Fat", "Improve Fitness", "Get Lean/Toned", "Get Healthier"]} />
        </>)}
        {steps[step] === "level" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Training experience</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>This sets your starting intensity and progression speed.</p>
          <OptionGrid field="level" cols={1} options={["Beginner", "Intermediate", "Advanced"]} />
        </>)}
        {steps[step] === "stats" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>A few quick stats</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>Used to calculate your calorie and macro targets.</p>
          {[["age", "Age", "yrs"], ["height", "Height", "cm"], ["weight", "Weight", "kg"]].map(([k, label, unit]) => {
            const err = statError(k);
            return (
              <div key={k} style={{ marginTop: 16 }}>
                <label style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</label>
                <div style={{ display: "flex", alignItems: "center", background: C.card, border: `1.5px solid ${err ? C.red : C.cardBorder}`, borderRadius: 12, marginTop: 6, padding: "12px 14px" }}>
                  <input type="number" min={STAT_BOUNDS[k].min} max={STAT_BOUNDS[k].max} inputMode="numeric" value={data[k]}
                    onChange={e => set(k, e.target.value.replace(/^-/, ""))}
                    style={{ background: "transparent", border: "none", outline: "none", color: C.text, fontSize: 16, fontWeight: 600, width: "100%", fontFamily: "Inter, sans-serif" }} placeholder="0" />
                  <span style={{ color: C.faint, fontSize: 13 }}>{unit}</span>
                </div>
                {err && <p style={{ color: C.red, fontSize: 11.5, margin: "5px 0 0" }}>{err}</p>}
              </div>
            );
          })}
        </>)}
        {steps[step] === "schedule" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Training days per week</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>Be realistic — consistency beats intensity.</p>
          <OptionGrid field="daysPerWeek" cols={4} options={["2", "3", "4", "5", "6", "7"]} />
        </>)}
        {steps[step] === "equipment" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Where do you train?</h2>
          <OptionGrid field="equipment" cols={2} options={["Full Gym", "Home", "Bodyweight Only", "Custom Equipment"]} />
        </>)}
        {steps[step] === "food" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Food preferences</h2>
          <div style={{ marginTop: 16 }}>
            <label style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>Allergies or foods to avoid</label>
            <input value={data.dislikes} onChange={e => set("dislikes", e.target.value)} placeholder="e.g. shellfish, peanuts"
              style={{ width: "100%", marginTop: 6, background: C.card, border: `1.5px solid ${C.cardBorder}`, borderRadius: 12, padding: "12px 14px", color: C.text, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "Inter, sans-serif" }} />
          </div>
          <p style={{ color: C.sub, fontSize: 13, fontWeight: 600, marginTop: 20 }}>Cooking time per meal</p>
          <OptionGrid field="cookingTime" cols={3} options={["<10 min", "10-25 min", "25+ min"]} />
          <p style={{ color: C.sub, fontSize: 13, fontWeight: 600, marginTop: 20 }}>Grocery budget (optional)</p>
          <OptionGrid field="budget" cols={3} options={["Low", "Medium", "Flexible"]} />
        </>)}
        {steps[step] === "review" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Building your plan</h2>
          <p style={{ color: C.sub, fontSize: 14, marginBottom: 20 }}>Here's what we'll generate based on your answers.</p>
          <Card style={{ marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Goal</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>{data.goal}</span></div></Card>
          <Card style={{ marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Level</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>{data.level}</span></div></Card>
          <Card style={{ marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Schedule</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>{data.daysPerWeek} days / week · {data.equipment}</span></div></Card>
          <Card><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Nutrition</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>Personalized targets + {data.cookingTime} meals</span></div></Card>
        </>)}
      </div>
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, padding: 20, background: `linear-gradient(0deg, ${C.bg} 60%, transparent)`, display: "flex", gap: 10 }}>
        {step > 0 && (<button onClick={() => setStep(s => s - 1)} style={{ width: 50, borderRadius: 14, border: `1.5px solid ${C.cardBorder}`, background: C.card, color: C.text, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><ChevronLeft size={20} /></button>)}
        <button disabled={!canNext()} onClick={() => step === total - 1 ? onComplete(data) : setStep(s => s + 1)} style={{
          flex: 1, borderRadius: 14, border: "none", padding: "16px", fontWeight: 700, fontSize: 15,
          background: canNext() ? `linear-gradient(135deg, ${C.teal}, #22B8A6)` : "#1A2327",
          color: canNext() ? "#04211D" : C.faint, cursor: canNext() ? "pointer" : "not-allowed",
          fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        }}>{step === total - 1 ? "Generate My Plan" : "Continue"} <ArrowRight size={17} /></button>
      </div>
    </div>
  );
}

/* ========================================================================
   CAMERA STATUS SCREEN — permission / model-loading / error states
   ======================================================================== */
function CameraStatusScreen({ status, onExit, onRetry }) {
  const content = {
    "cam-requesting": { icon: <Loader2 size={30} className="spin" color={C.teal} />, title: null, body: "Requesting camera access…" },
    "loading-model": { icon: <Loader2 size={30} className="spin" color={C.teal} />, title: "Loading pose model", body: "Downloading the on-device movement-tracking model. This only happens once per session." },
    "cam-denied": { icon: <Camera size={34} color={C.sub} />, title: "Camera access needed", body: "FORM needs your camera to verify reps and form. Enable camera access in your browser settings, then try again." },
    "cam-unavailable": { icon: <AlertTriangle size={34} color={C.amber} />, title: "No camera found", body: "This device doesn't have an accessible camera. Verified rep tracking isn't available right now." },
    "model-error": { icon: <AlertTriangle size={34} color={C.amber} />, title: "Pose tracking unavailable", body: "The on-device movement-tracking model either failed to download (check your connection) or isn't running properly on this device's graphics driver. Verified rep counting can't run without it." },
  };
  const c = content[status] || content["cam-requesting"];
  return (
    <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: C.text, gap: 14, padding: 30, textAlign: "center", height: "100%" }}>
      {c.icon}
      {c.title && <h3 style={{ fontFamily: "Space Grotesk, sans-serif", margin: 0 }}>{c.title}</h3>}
      <p style={{ color: C.sub, fontSize: 13.5, maxWidth: 280, margin: 0 }}>{c.body}</p>
      <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
        {(status === "model-error" || status === "cam-denied") && onRetry && (
          <button onClick={onRetry} style={{ background: C.teal, border: "none", color: "#04211D", padding: "12px 20px", borderRadius: 12, fontWeight: 700 }}>Try Again</button>
        )}
        <button onClick={onExit} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, color: C.text, padding: "12px 20px", borderRadius: 12, fontWeight: 600 }}>Go Back</button>
      </div>
      <style>{`.spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

/* ========================================================================
   WORKOUT SESSION SCREEN
   Sequences through today's exercises. Owns one continuous camera stream
   and one MoveNet detector for the whole session (opened once, not
   per-exercise) for a smoother, lower-latency experience. Delegates rep
   logic entirely to the ExerciseAnalyzer + RepVerifier layers above.
   ======================================================================== */
function WorkoutSessionScreen({ exercises, startIndex, personalBests, bodyweight, onFinish, onExit }) {
  const videoRef = useRef(null);
  const [retryKey, setRetryKey] = useState(0);
  const sessionIdRef = useRef(uid()); // stable for this session's lifetime — used to dedupe the finish-XP grant
  const [finishing, setFinishing] = useState(false); // guards the Continue button against double-tap
  const [exIdx, setExIdx] = useState(startIndex || 0);
  const [setNum, setSetNum] = useState(1);
  const [subPhase, setSubPhase] = useState("positioning"); // positioning|active|paused|resting|exerciseDone|sessionDone
  const [reps, setReps] = useState(0);
  const [uiState, setUiState] = useState({ feedback: "Position yourself for this exercise", tone: "neutral" });
  const [lastRepScore, setLastRepScore] = useState(null);
  const [restSeconds, setRestSeconds] = useState(45);
  const [results, setResults] = useState({}); // { [exerciseKey]: { totalReps, avgForm, sets:[{reps,avgForm}], isPR } }
  const [flash, setFlash] = useState(false);

  const verifierRef = useRef(null);
  const repScoresRef = useRef([]);
  const positioningOkSinceRef = useRef(null);
  const stickyUntilRef = useRef(0);
  const lastUiUpdateRef = useRef(0);
  const poseRef = useRef(null);
  const canvasRef = useRef(null);
  const badFlagRef = useRef(false);

  const currentExercise = exercises[exIdx];
  const cfg = currentExercise ? EXERCISES[currentExercise.key] : null;

  const resetForNewSet = useCallback(() => {
    verifierRef.current = currentExercise ? createRepVerifier(currentExercise.key) : null;
    repScoresRef.current = [];
    setReps(0);
    setLastRepScore(null);
    positioningOkSinceRef.current = null;
    setSubPhase("positioning");
    setUiState({ feedback: cfg ? cfg.viewHint : "", tone: "neutral" });
  }, [currentExercise, cfg]);

  useEffect(() => { resetForNewSet(); }, [exIdx]); // eslint-disable-line

  function drawSkeleton(poseData) {
    const canvas = canvasRef.current;
    if (!canvas || !canvas.parentElement) return;
    const w = canvas.parentElement.clientWidth, h = canvas.parentElement.clientHeight;
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, w, h);
    try {
      if (!poseData || !poseData.keypoints || !poseData.keypoints.length) return;
      const vw = poseData.videoWidth, vh = poseData.videoHeight;
      // Guard against a 0-size container (e.g. during the very first
      // layout pass) or a video with no metadata yet — dividing by zero
      // here previously produced Infinity/NaN-scaled coordinates that
      // rendered as a giant distorted shape instead of just skipping the
      // frame.
      if (!w || !h || !vw || !vh) return;
      const scale = Math.max(w / vw, h / vh);
      if (!isFinite(scale) || scale <= 0) return;
      const dw = vw * scale, dh = vh * scale;
      const ox = (dw - w) / 2, oy = (dh - h) / 2;
      const map = (pt) => { const sx = pt.x * scale - ox; const sy = pt.y * scale - oy; return { x: w - sx, y: sy }; };
      const byName = {}; poseData.keypoints.forEach(k => byName[k.name] = k);
      const color = badFlagRef.current ? C.red : C.teal;
      ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.lineCap = "round";
      SKELETON_EDGES.forEach(([a, b]) => {
        const A = byName[a], B = byName[b];
        if (A && B && A.score > 0.3 && B.score > 0.3) {
          const pa = map(A), pb = map(B);
          ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
        }
      });
      ctx.fillStyle = color;
      poseData.keypoints.forEach(k => {
        if (k.score > 0.3) { const p = map(k); ctx.beginPath(); ctx.arc(p.x, p.y, 4.5, 0, Math.PI * 2); ctx.fill(); }
      });
      // Neck/head line: MoveNet has no "neck" keypoint, so this is the one
      // synthetic edge — midpoint of the shoulders to the nose — needed to
      // make the head visually connect to the rest of the skeleton like a
      // real body, matching the explicit head-tracking requirement.
      const lSh = byName["left_shoulder"], rSh = byName["right_shoulder"], nose = byName["nose"];
      if (lSh && rSh && nose && lSh.score > 0.3 && rSh.score > 0.3 && nose.score > 0.3) {
        const mid = { x: (lSh.x + rSh.x) / 2, y: (lSh.y + rSh.y) / 2 };
        const pMid = map(mid), pNose = map(nose);
        ctx.beginPath(); ctx.moveTo(pMid.x, pMid.y); ctx.lineTo(pNose.x, pNose.y); ctx.stroke();
      }
    } catch (e) {
      // Never let a single bad frame leave a stuck/garbled overlay —
      // the clearRect above already ran, so worst case is a blank frame.
      console.warn("drawSkeleton frame skipped:", e);
    }
  }

  function maybeUpdateUi(text, tone, now, force) {
    if (!force && now < stickyUntilRef.current) return;
    if (!force && now - lastUiUpdateRef.current < 150) return;
    lastUiUpdateRef.current = now;
    setUiState(u => (u.feedback === text && u.tone === tone) ? u : { feedback: text, tone });
  }

  const handleFrame = useCallback((poseData) => {
    poseRef.current = poseData;
    const now = poseData.t || performance.now();

    if (!currentExercise) return;
    const vis = checkVisibility(poseData, currentExercise.key);
    badFlagRef.current = !vis.ok;
    drawSkeleton(poseData);

    if (subPhase === "paused" || subPhase === "resting" || subPhase === "exerciseDone" || subPhase === "sessionDone") return;

    if (subPhase === "positioning") {
      if (vis.ok) {
        if (!positioningOkSinceRef.current) positioningOkSinceRef.current = now;
        if (now - positioningOkSinceRef.current > 700) {
          verifierRef.current = createRepVerifier(currentExercise.key);
          setSubPhase("active");
          setUiState({ feedback: "Begin when ready", tone: "good" });
          stickyUntilRef.current = now + 700;
        } else {
          maybeUpdateUi("Hold still — locking on", "good", now, true);
        }
      } else {
        positioningOkSinceRef.current = null;
        maybeUpdateUi(vis.message, "warn", now, true);
      }
      return;
    }

    // subPhase === 'active'
    if (!verifierRef.current) return;
    if (!vis.ok) {
      const res = verifierRef.current.update(null, now, false);
      maybeUpdateUi(res.feedback, res.tone, now, res.event === "aborted");
      return;
    }
    const metrics = cfg.getMetrics(poseData);
    const res = verifierRef.current.update(metrics, now, true);
    if (res.event === "verified") {
      repScoresRef.current.push(res.rep.formScore);
      stickyUntilRef.current = now + 1100;
      setLastRepScore(res.rep.formScore);
      setUiState({ feedback: "Good rep", tone: "good" });
      setFlash(true); setTimeout(() => setFlash(false), 260);
      setReps(r => r + 1);
    } else if (res.event === "rejected" || res.event === "aborted") {
      stickyUntilRef.current = now + 1300;
      setUiState({ feedback: res.feedback, tone: "warn" });
    } else {
      maybeUpdateUi(res.feedback, res.tone, now);
    }
  }, [currentExercise, cfg, subPhase]);

  const { status } = usePoseProvider(videoRef, true, handleFrame, retryKey);

  // advance set / exercise when target reps reached
  useEffect(() => {
    if (subPhase !== "active" || !currentExercise) return;
    if (reps >= currentExercise.reps) {
      const setAvg = repScoresRef.current.length ? Math.round(repScoresRef.current.reduce((a, b) => a + b, 0) / repScoresRef.current.length) : 0;
      setResults(prev => {
        const key = currentExercise.key;
        const existing = prev[key] || { totalReps: 0, sets: [], avgForm: 0 };
        const sets = [...existing.sets, { reps, avgForm: setAvg }];
        const totalReps = existing.totalReps + reps;
        const avgForm = Math.round(sets.reduce((a, s) => a + s.avgForm, 0) / sets.length);
        return { ...prev, [key]: { totalReps, sets, avgForm } };
      });
      if (setNum >= currentExercise.sets) {
        setSubPhase("exerciseDone");
      } else {
        setSubPhase("resting");
        setRestSeconds(45);
      }
    }
  }, [reps]); // eslint-disable-line

  // rest countdown
  useEffect(() => {
    if (subPhase !== "resting") return;
    if (restSeconds <= 0) { setSetNum(n => n + 1); resetForNewSet(); return; }
    const t = setTimeout(() => setRestSeconds(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [subPhase, restSeconds]); // eslint-disable-line

  function goNextExercise() {
    if (exIdx >= exercises.length - 1) {
      setSubPhase("sessionDone");
    } else {
      setExIdx(i => i + 1);
      setSetNum(1);
    }
  }

  function finishSession() {
    if (finishing) return; // already submitted — ignore a double-tap
    setFinishing(true);
    const perExercise = { ...results };
    let totalXp = 150; // workout complete base
    let totalReps = 0, totalFormWeighted = 0, prCount = 0, estLoad = 0;
    Object.entries(perExercise).forEach(([key, r]) => {
      totalReps += r.totalReps;
      totalFormWeighted += r.avgForm * r.totalReps;
      estLoad += estimateLoad(key, r.totalReps, bodyweight);
      const prevBest = personalBests[key]?.reps || 0;
      const isPR = r.totalReps > prevBest;
      perExercise[key] = { ...r, isPR };
      if (isPR) prCount++;
    });
    const avgForm = totalReps ? Math.round(totalFormWeighted / totalReps) : 0;
    totalXp += totalReps * 2;
    if (avgForm >= 85) totalXp += 60;
    totalXp += prCount * 50;
    onFinish({ perExercise, totalReps, avgForm, totalXp, prCount, estLoad, sessionId: sessionIdRef.current });
  }

  if (!currentExercise) return null;

  if (subPhase === "sessionDone") {
    const perExercise = { ...results };
    let totalReps = 0, totalFormWeighted = 0, prCount = 0, estLoad = 0;
    Object.entries(perExercise).forEach(([key, r]) => {
      totalReps += r.totalReps; totalFormWeighted += r.avgForm * r.totalReps;
      estLoad += estimateLoad(key, r.totalReps, bodyweight);
      if (r.totalReps > (personalBests[key]?.reps || 0)) prCount++;
    });
    const avgForm = totalReps ? Math.round(totalFormWeighted / totalReps) : 0;
    return (
      <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text }}>
        <style>{FONT_IMPORT}</style>
        <div style={{ flex: 1, overflowY: "auto", padding: "40px 22px 20px", textAlign: "center" }}>
          <Trophy size={40} color={C.amber} style={{ margin: "0 auto 10px" }} />
          <h1 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700, margin: "0 0 4px" }}>WORKOUT COMPLETE</h1>
          <p style={{ color: C.sub, fontSize: 13.5, marginBottom: 24 }}>Every rep below was camera-verified.</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>VERIFIED REPS</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 26, fontWeight: 700, color: C.teal }}>{totalReps}</div></Card>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>AVG FORM</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 26, fontWeight: 700, color: C.green }}>{avgForm}</div></Card>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>EST. LOAD MOVED</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 22, fontWeight: 700 }}>{estLoad} kg</div></Card>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>PERSONAL RECORDS</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 22, fontWeight: 700, color: C.amber }}>{prCount}</div></Card>
          </div>
          <p style={{ fontSize: 10.5, color: C.faint, marginBottom: 18 }}>Estimated load is derived from bodyweight and reps — not a scale measurement.</p>
          {Object.entries(perExercise).map(([key, r]) => (
            <Card key={key} style={{ marginBottom: 10, textAlign: "left" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14 }}>{EXERCISES[key].name}</div>
                {r.totalReps > (personalBests[key]?.reps || 0) && <Pill color={C.amber}><Trophy size={11} /> NEW PR</Pill>}
              </div>
              <div style={{ fontSize: 12.5, color: C.sub, marginTop: 3 }}>{r.totalReps} verified reps · {r.avgForm} avg form</div>
            </Card>
          ))}
          <button onClick={finishSession} disabled={finishing} style={{
            width: "100%", marginTop: 12, padding: 16, borderRadius: 14, border: "none",
            background: finishing ? "#1A2327" : `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: finishing ? C.faint : "#04211D", fontWeight: 700, fontSize: 15,
            fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}>{finishing ? "Saving…" : "Continue"} {!finishing && <ArrowRight size={17} />}</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ position: "absolute", inset: 0, background: "#050707" }}>
        {/* The <video> tag is always mounted (visibility is opacity-based,
            not conditional rendering). Previously it only mounted once
            status==="ready", but the camera stream gets attached to the
            ref earlier, while status is still "cam-requesting" — at that
            point the tag didn't exist yet, so the stream had nowhere to
            attach. The element was then mounted later with no source,
            and the browser rendered its default "no video" placeholder
            icon instead of the live feed. Keeping it always-mounted fixes
            that race condition. The mirror flip stays on this wrapper,
            not the <video> itself — a transform directly on a live
            camera <video> is a known trigger for corrupted/frozen
            preview frames on some Android WebView + GPU combinations. */}
        <div style={{ position: "absolute", inset: 0, transform: "scaleX(-1)" }}>
          <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover", opacity: status === "ready" ? 0.92 : 0, display: "block", transition: "opacity .25s ease" }} />
        </div>
      </div>
      {status === "ready" && <canvas ref={canvasRef} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }} />}
      {flash && <div style={{ position: "absolute", inset: 0, background: `${C.green}22`, pointerEvents: "none" }} />}

      <div style={{ position: "relative", zIndex: 2, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 16px 0" }}>
        <button onClick={onExit} style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <X size={18} color={C.text} />
        </button>
        <div style={{ background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "8px 14px", textAlign: "center" }}>
          <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 14, color: C.text }}>{currentExercise.name}</div>
          <div style={{ fontSize: 11, color: C.sub }}>Set {setNum} / {currentExercise.sets} · Exercise {exIdx + 1}/{exercises.length}</div>
        </div>
        {status === "ready" && subPhase === "active" ? (
          <button onClick={() => setSubPhase("paused")} style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Pause size={16} color={C.text} />
          </button>
        ) : <div style={{ width: 38 }} />}
      </div>

      {status !== "ready" && <CameraStatusScreen status={status} onExit={onExit} onRetry={() => setRetryKey(k => k + 1)} />}

      {status === "ready" && subPhase === "positioning" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, padding: 30, textAlign: "center" }}>
          <div style={{ background: "rgba(10,14,15,0.85)", border: `1px solid ${C.cardBorder}`, borderRadius: 16, padding: "20px 24px" }}>
            <ScanLine size={26} color={uiState.tone === "good" ? C.green : C.amber} style={{ marginBottom: 8 }} />
            <p style={{ color: C.text, fontWeight: 600, fontSize: 14, margin: 0 }}>{uiState.feedback}</p>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "paused" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
          <h3 style={{ color: C.text, fontFamily: "Space Grotesk, sans-serif" }}>Paused</h3>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setSubPhase("active")} style={{ background: C.teal, border: "none", color: "#04211D", padding: "12px 22px", borderRadius: 12, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}><Play size={15} fill="#04211D" /> Resume</button>
            <button onClick={onExit} style={{ background: "rgba(248,113,113,0.15)", border: `1px solid ${C.red}`, color: C.red, padding: "12px 22px", borderRadius: 12, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}><Square size={14} /> End Workout</button>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "resting" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
          <div style={{ background: "rgba(10,14,15,0.9)", border: `1px solid ${C.cardBorder}`, borderRadius: 20, padding: "26px 30px", textAlign: "center" }}>
            <Timer size={24} color={C.purple} style={{ marginBottom: 8 }} />
            <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 40, fontWeight: 700, color: C.text }}>{restSeconds}s</div>
            <div style={{ color: C.sub, fontSize: 12.5, marginTop: 4 }}>Rest — Set {setNum + 1} of {currentExercise.sets} next</div>
            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
              <button onClick={() => setRestSeconds(s => Math.max(0, s - 15))} style={{ background: "#1A2327", border: "none", color: C.text, padding: "8px 14px", borderRadius: 10, fontWeight: 600 }}>-15s</button>
              <button onClick={() => setRestSeconds(s => s + 15)} style={{ background: "#1A2327", border: "none", color: C.text, padding: "8px 14px", borderRadius: 10, fontWeight: 600 }}>+15s</button>
              <button onClick={() => setRestSeconds(0)} style={{ background: C.teal, border: "none", color: "#04211D", padding: "8px 16px", borderRadius: 10, fontWeight: 700 }}>Skip</button>
            </div>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "exerciseDone" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, padding: 24 }}>
          <div style={{ background: "rgba(10,14,15,0.92)", border: `1px solid ${C.cardBorder}`, borderRadius: 20, padding: "26px 26px", textAlign: "center", width: "100%", maxWidth: 340 }}>
            <Check size={28} color={C.green} style={{ marginBottom: 8 }} />
            <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 18, color: C.text }}>{currentExercise.name} complete</div>
            <div style={{ color: C.sub, fontSize: 13, marginTop: 6 }}>{results[currentExercise.key]?.totalReps || 0} verified reps · {results[currentExercise.key]?.avgForm || 0} avg form</div>
            {(results[currentExercise.key]?.totalReps || 0) > (personalBests[currentExercise.key]?.reps || 0) && (
              <div style={{ marginTop: 10 }}><Pill color={C.amber}><Trophy size={11} /> NEW PERSONAL RECORD</Pill></div>
            )}
            <button onClick={goNextExercise} style={{
              marginTop: 18, width: "100%", padding: 14, borderRadius: 13, border: "none",
              background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontSize: 14.5,
              fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            }}>{exIdx >= exercises.length - 1 ? "Finish Workout" : "Next Exercise"} <ArrowRight size={16} /></button>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "active" && (
        <>
          <div style={{ position: "relative", zIndex: 2, flex: 1 }} />
          <div style={{ position: "relative", zIndex: 2, padding: "0 16px 8px", display: "flex", justifyContent: "center" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8, padding: "8px 16px", borderRadius: 999,
              background: uiState.tone === "good" ? `${C.green}22` : uiState.tone === "warn" ? `${C.red}22` : "rgba(10,14,15,0.75)",
              border: `1px solid ${uiState.tone === "good" ? C.green : uiState.tone === "warn" ? C.red : C.cardBorder}`,
              transition: "all .2s", maxWidth: "88%",
            }}>
              {uiState.tone === "good" ? <Check size={15} color={C.green} /> : uiState.tone === "warn" ? <AlertTriangle size={15} color={C.red} /> : <Info size={15} color={C.sub} />}
              <span style={{ fontSize: 12.5, fontWeight: 600, color: uiState.tone === "good" ? C.green : uiState.tone === "warn" ? C.red : C.text, textAlign: "center" }}>{uiState.feedback}</span>
            </div>
          </div>
          <div style={{ position: "relative", zIndex: 2, background: "rgba(8,11,12,0.88)", backdropFilter: "blur(10px)", borderTop: `1px solid ${C.cardBorder}`, padding: "18px 20px 28px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 11, color: C.sub, fontWeight: 600, letterSpacing: 0.3 }}>VERIFIED REPS</div>
                <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 40, fontWeight: 700, color: C.text, lineHeight: 1 }}>
                  {reps}<span style={{ fontSize: 20, color: C.faint }}> / {currentExercise.reps}</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 11, color: C.sub, fontWeight: 600, letterSpacing: 0.3 }}>FORM</div>
                <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 28, fontWeight: 700, color: lastRepScore == null ? C.faint : (lastRepScore >= 85 ? C.green : lastRepScore >= 70 ? C.amber : C.red) }}>{lastRepScore ?? "—"}</div>
              </div>
            </div>
            <ProgressBar value={reps} max={currentExercise.reps} color={C.teal} height={10} />
            <p style={{ textAlign: "center", color: C.faint, fontSize: 10.5, marginTop: 14 }}>
              On-device pose tracking (TensorFlow.js MoveNet) — guidance, not a medical assessment.
            </p>
          </div>
        </>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* FOOD SCANNER (Stage 1 — unchanged: estimated camera recognition)        */
/* ---------------------------------------------------------------------- */
function FoodScanner({ onClose, onLog, onSearchFood, onManualEntry }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [camState, setCamState] = useState("requesting");
  const [phase, setPhase] = useState("scanning"); // scanning | result | low-confidence | recognition-error
  const [result, setResult] = useState(null); // { provider, items: [{foodId,name,confidence,grams,alternatives}] }
  const [streamRef, setStreamRef] = useState(null);
  const [submitting, setSubmitting] = useState(false); // guards "Log This Meal" against double-tap
  const online = useOnlineStatus();

  useEffect(() => {
    let cancelled = false;
    async function go() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        setStreamRef(stream);
        if (videoRef.current) {
          const v = videoRef.current;
          v.muted = true;
          v.playsInline = true;
          v.srcObject = stream;
          v.play().catch(() => {});
        }
        setCamState("granted");
        setTimeout(async () => {
          if (cancelled) return;
          let imageDataUrl = null;
          try {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            if (video && canvas && video.videoWidth) {
              canvas.width = video.videoWidth;
              canvas.height = video.videoHeight;
              canvas.getContext("2d").drawImage(video, 0, 0);
              imageDataUrl = canvas.toDataURL("image/jpeg", 0.7);
            }
          } catch (e) { /* capture failed — recognizeFood still runs via mock fallback */ }

          try {
            const recognized = await recognizeFood(imageDataUrl);
            if (cancelled) return;
            if (!recognized.items.length) { setPhase("recognition-error"); return; }
            const items = recognized.items.map((it, i) => ({ ...it, grams: it.estimatedGrams, key: `${it.foodId}_${i}` }));
            const avgConfidence = items.reduce((a, it) => a + it.confidence, 0) / items.length;
            setResult({ provider: recognized.provider, items });
            setPhase(avgConfidence < 0.55 ? "low-confidence" : "result");
          } catch (e) {
            if (!cancelled) setPhase("recognition-error");
          }
        }, 1600);
      } catch (err) {
        if (!cancelled) setCamState(err?.name === "NotFoundError" ? "unavailable" : "denied");
      }
    }
    go();
    return () => { cancelled = true; if (streamRef) streamRef.getTracks().forEach(t => t.stop()); };
    // eslint-disable-next-line
  }, []);

  const updateGrams = (key, grams) => setResult(r => ({ ...r, items: r.items.map(it => it.key === key ? { ...it, grams: Math.max(0, grams) } : it) }));
  const swapFood = (key, foodId) => setResult(r => ({
    ...r,
    items: r.items.map(it => {
      if (it.key !== key) return it;
      const food = findFood(foodId);
      return { ...it, foodId, name: food.name, grams: food.defaultServingGrams, confidence: 1 };
    }),
  }));

  const totals = useMemo(() => {
    if (!result) return null;
    const parts = result.items.map(it => {
      const food = findFood(it.foodId);
      return food ? scaleNutrition(food.per100, it.grams) : { cals: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };
    });
    return roundNutrition(sumNutrition(parts));
  }, [result]);

  const providerLabel = result ? RECOGNITION_LABELS[result.provider] : "";

  return (
    <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif" }}>
      <canvas ref={canvasRef} style={{ display: "none" }} />
      <div style={{ position: "absolute", inset: 0 }}>
        <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover", opacity: camState === "granted" ? (phase === "scanning" ? 0.85 : 0.35) : 0, transition: "opacity .2s ease" }} />
      </div>
      <div style={{ position: "relative", zIndex: 2, display: "flex", justifyContent: "space-between", padding: "18px 16px" }}>
        <button onClick={onClose} style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={18} color="#fff" /></button>
        {result && <Pill color={result.provider === "mock" ? C.amber : C.purple} bg="rgba(10,14,15,0.75)">{providerLabel}</Pill>}
      </div>
      {!online && camState === "requesting" ? null : null}
      {camState === "requesting" && (<div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", gap: 14 }}><Loader2 size={30} className="spin" color={C.teal} /><p style={{ color: C.sub }}>Requesting camera access…</p></div>)}
      {camState === "denied" && (<div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", gap: 14, padding: 30, textAlign: "center" }}><Camera size={34} color={C.sub} /><h3 style={{ fontFamily: "Space Grotesk, sans-serif" }}>Camera access needed</h3><p style={{ color: C.sub, fontSize: 13.5 }}>Enable camera access to scan your food.</p><button onClick={onClose} style={{ marginTop: 8, background: C.card, border: `1px solid ${C.cardBorder}`, color: "#fff", padding: "12px 20px", borderRadius: 12, fontWeight: 600 }}>Go Back</button></div>)}
      {camState === "unavailable" && (<div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", gap: 14, padding: 30, textAlign: "center" }}><AlertTriangle size={34} color={C.amber} /><h3 style={{ fontFamily: "Space Grotesk, sans-serif" }}>No camera found</h3><button onClick={onClose} style={{ marginTop: 8, background: C.card, border: `1px solid ${C.cardBorder}`, color: "#fff", padding: "12px 20px", borderRadius: 12, fontWeight: 600 }}>Go Back</button></div>)}
      {camState === "granted" && phase === "scanning" && (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <div style={{ width: 240, height: 240, border: `2px solid ${C.teal}`, borderRadius: 20, position: "relative", overflow: "hidden" }}>
            <div className="scanline" style={{ position: "absolute", left: 0, right: 0, height: 2, background: C.teal, boxShadow: `0 0 12px ${C.teal}` }} />
          </div>
          <p style={{ color: "#fff", marginTop: 20, fontWeight: 600 }}>Analyzing food…</p>
          <style>{`.scanline{animation:scan 1.8s ease-in-out infinite;} @keyframes scan{0%{top:0}50%{top:238px}100%{top:0}} .spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </div>
      )}
      {phase === "recognition-error" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, padding: 30, textAlign: "center" }}>
          <AlertTriangle size={30} color={C.amber} />
          <p style={{ color: "#fff", fontWeight: 600, fontSize: 15, margin: 0 }}>We couldn't confidently identify this food.</p>
          <p style={{ color: C.sub, fontSize: 13, margin: 0 }}>{!online ? "You're offline, which affects recognition quality." : "Try better lighting, or add it another way:"}</p>
          <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
            <button onClick={() => { onClose(); onSearchFood && onSearchFood(); }} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, color: "#fff", padding: "12px 18px", borderRadius: 12, fontWeight: 600, fontSize: 13 }}>Search Food</button>
            <button onClick={() => { onClose(); onManualEntry && onManualEntry(); }} style={{ background: C.teal, border: "none", color: "#04211D", padding: "12px 18px", borderRadius: 12, fontWeight: 700, fontSize: 13 }}>Enter Manually</button>
          </div>
        </div>
      )}
      {(phase === "result" || phase === "low-confidence") && result && totals && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
          <div style={{ background: C.bg2, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: "20px 20px 26px", border: `1px solid ${C.cardBorder}`, maxHeight: "78vh", overflowY: "auto" }}>
            <h3 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, color: C.text, margin: "0 0 4px" }}>Detected foods</h3>
            {phase === "low-confidence" && (
              <div style={{ display: "flex", gap: 8, alignItems: "flex-start", background: `${C.amber}14`, border: `1px solid ${C.amber}44`, borderRadius: 10, padding: 10, marginBottom: 10 }}>
                <AlertTriangle size={14} color={C.amber} style={{ marginTop: 1, flexShrink: 0 }} />
                <p style={{ fontSize: 11.5, color: C.amber, margin: 0 }}>Low confidence — double check these before logging, or use Search/Manual entry instead.</p>
              </div>
            )}
            <p style={{ color: C.sub, fontSize: 12.5, marginBottom: 12 }}>Portions are ESTIMATED from the photo — edit grams below, or use Scale Mode for a precise weight.</p>
            {result.items.map((it) => (
              <div key={it.key} style={{ padding: "10px 0", borderBottom: `1px solid ${C.cardBorder}` }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: 14, color: C.text }}>{it.name}</span>
                      <Pill color={it.confidence >= 0.8 ? C.green : it.confidence >= 0.55 ? C.amber : C.red}>{Math.round(it.confidence * 100)}%</Pill>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6 }}>
                      <button onClick={() => updateGrams(it.key, it.grams - 10)} style={{ width: 26, height: 26, borderRadius: 8, background: "#1A2327", border: "none", color: C.text, display: "flex", alignItems: "center", justifyContent: "center" }}><Minus size={12} /></button>
                      <span style={{ fontSize: 12.5, color: C.sub, minWidth: 66, textAlign: "center" }}>~{it.grams}g estimated</span>
                      <button onClick={() => updateGrams(it.key, it.grams + 10)} style={{ width: 26, height: 26, borderRadius: 8, background: "#1A2327", border: "none", color: C.text, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={12} /></button>
                    </div>
                  </div>
                  <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: C.teal }}>{Math.round(scaleNutrition(findFood(it.foodId).per100, it.grams).cals)}</div>
                </div>
                {it.alternatives && it.alternatives.length > 0 && (
                  <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 11, color: C.faint }}>Not right?</span>
                    {it.alternatives.map(alt => (
                      <button key={alt.foodId} onClick={() => swapFood(it.key, alt.foodId)} style={{ fontSize: 11, color: C.teal, background: "transparent", border: `1px solid ${C.tealDim}`, borderRadius: 8, padding: "3px 8px" }}>{alt.name}</button>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16, padding: 14, borderRadius: 14, background: `${C.teal}12`, border: `1px solid ${C.tealDim}` }}>
              <span style={{ fontWeight: 700, color: C.text, fontSize: 14 }}>Total (estimated)</span>
              <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: C.teal, fontSize: 16 }}>{totals.cals} kcal</span>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button onClick={onClose} style={{ flex: 1, padding: 14, borderRadius: 12, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600 }}>Discard</button>
              <button disabled={submitting} onClick={() => { if (submitting) return; setSubmitting(true); onLog({ name: result.items.map(f => f.name).join(", "), cals: totals.cals, protein: totals.protein, carbs: totals.carbs, fat: totals.fat, fiber: totals.fiber, source: result.provider === "mock" ? "scan-mock" : "scan" }); }} style={{ flex: 2, padding: 14, borderRadius: 12, border: "none", background: submitting ? "#1A2327" : `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: submitting ? C.faint : "#04211D", fontWeight: 700 }}>{submitting ? "Logging…" : "Log This Meal"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* SCALE MODE (Stage 1 — unchanged)                                        */
/* ---------------------------------------------------------------------- */
function ScaleMode({ onClose, onLog, onSaveMeal }) {
  const [items, setItems] = useState([{ foodId: "chicken_breast", grams: 186 }, { foodId: "white_rice", grams: 210 }, { foodId: "broccoli", grams: 95 }]);
  const [unit, setUnit] = useState("g"); // g | oz
  const [scaleState, setScaleState] = useState(SCALE_STATES.NOT_CONNECTED);
  const [scaleMessage, setScaleMessage] = useState(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [mealName, setMealName] = useState("");
  const [submitting, setSubmitting] = useState(false); // guards "Log Measured Meal" against double-tap
  const scaleProviderRef = useRef(new BluetoothScaleProvider());

  const totals = useMemo(() => nutritionForIngredients(items.map(it => ({ foodId: it.foodId, grams: it.grams }))), [items]);

  const gToOz = g => g / 28.3495;
  const ozToG = oz => oz * 28.3495;
  const displayVal = grams => unit === "g" ? Math.round(grams) : Math.round(gToOz(grams) * 10) / 10;
  const step = unit === "g" ? 5 : 0.5;

  const updateGrams = (i, deltaDisplay) => setItems(items.map((it, idx) => {
    if (idx !== i) return it;
    const deltaGrams = unit === "g" ? deltaDisplay : ozToG(deltaDisplay);
    return { ...it, grams: Math.max(0, Math.round(it.grams + deltaGrams)) };
  }));
  const setGramsDirect = (i, displayValue) => setItems(items.map((it, idx) => {
    if (idx !== i) return it;
    const val = Number(displayValue);
    if (Number.isNaN(val) || val < 0) return it; // guard against invalid/negative weights
    const grams = unit === "g" ? val : ozToG(val);
    return { ...it, grams: Math.round(grams) };
  }));
  const updateItem = (i, foodId) => setItems(items.map((it, idx) => idx === i ? { ...it, foodId, grams: findFood(foodId)?.defaultServingGrams || it.grams } : it));
  const removeItem = i => setItems(items.filter((_, idx) => idx !== i));
  const addItem = () => setItems([...items, { foodId: FOOD_DATABASE[0].id, grams: 100 }]);

  async function handlePairDevice() {
    setScaleState(SCALE_STATES.CONNECTING);
    setScaleMessage(null);
    const result = await scaleProviderRef.current.connect();
    setScaleState(scaleProviderRef.current.state);
    setScaleMessage(result.message);
  }

  const hasEmptyMeal = items.length === 0 || totals.cals === 0;

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}><Scale size={19} color={C.teal} /><h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Weigh Food</h2></div>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={17} color={C.text} /></button>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0 18px 14px" }}>
        <p style={{ color: C.sub, fontSize: 12.5, margin: 0, flex: 1 }}>Connect a compatible smart scale, or enter weight manually for precise nutrition.</p>
        <div style={{ display: "flex", background: "#1A2327", borderRadius: 9, padding: 2, marginLeft: 10, flexShrink: 0 }}>
          {["g", "oz"].map(u => (
            <button key={u} onClick={() => setUnit(u)} style={{ padding: "5px 10px", borderRadius: 7, border: "none", fontSize: 11.5, fontWeight: 700, background: unit === u ? C.teal : "transparent", color: unit === u ? "#04211D" : C.sub }}>{u}</button>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "0 18px" }}>
        <Card style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: `${C.faint}22`, display: "flex", alignItems: "center", justifyContent: "center" }}><Scale size={16} color={C.faint} /></div>
              <div>
                <div style={{ fontWeight: 600, fontSize: 13.5 }}>Smart scale</div>
                <div style={{ fontSize: 11.5, color: C.sub }}>
                  {scaleState === SCALE_STATES.CONNECTING ? "Connecting…" : scaleState === SCALE_STATES.ERROR ? "Not available" : "No compatible scale paired"}
                </div>
              </div>
            </div>
            <button onClick={handlePairDevice} disabled={scaleState === SCALE_STATES.CONNECTING} style={{ fontSize: 12.5, fontWeight: 600, color: C.teal, background: "transparent", border: `1px solid ${C.tealDim}`, borderRadius: 9, padding: "7px 12px" }}>
              {scaleState === SCALE_STATES.CONNECTING ? "Connecting…" : "Pair Device"}
            </button>
          </div>
          {scaleMessage && (
            <p style={{ fontSize: 11.5, color: C.amber, margin: "10px 0 0", display: "flex", gap: 6, alignItems: "flex-start" }}>
              <AlertTriangle size={12} style={{ marginTop: 1, flexShrink: 0 }} /> {scaleMessage}
            </p>
          )}
        </Card>

        {items.map((it, i) => {
          const food = findFood(it.foodId);
          const c = scaleNutrition(food.per100, it.grams);
          return (
            <Card key={i} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <select value={it.foodId} onChange={e => updateItem(i, e.target.value)} style={{ background: "transparent", border: "none", color: C.text, fontWeight: 700, fontSize: 14.5, fontFamily: "Inter, sans-serif", outline: "none" }}>
                  {FOOD_DATABASE.map(s => <option key={s.id} value={s.id} style={{ background: C.card }}>{s.name}</option>)}
                </select>
                <button onClick={() => removeItem(i)} style={{ background: "none", border: "none", color: C.faint }}><X size={16} /></button>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                <button onClick={() => updateGrams(i, -step)} style={{ width: 32, height: 32, borderRadius: 9, background: "#1A2327", border: "none", color: C.text, display: "flex", alignItems: "center", justifyContent: "center" }}><Minus size={15} /></button>
                <div style={{ flex: 1, textAlign: "center" }}>
                  <input
                    type="number" inputMode="decimal" value={displayVal(it.grams)}
                    onChange={e => setGramsDirect(i, e.target.value)}
                    style={{ width: 70, textAlign: "center", background: "transparent", border: "none", outline: "none", color: C.text, fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}
                  />
                  <span style={{ color: C.sub, fontSize: 13 }}> {unit}</span>
                </div>
                <button onClick={() => updateGrams(i, step)} style={{ width: 32, height: 32, borderRadius: 9, background: "#1A2327", border: "none", color: C.text, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={15} /></button>
              </div>
              <div style={{ fontSize: 12, color: C.sub }}>{Math.round(c.cals)} kcal · {c.protein.toFixed(1)}g P · {c.carbs.toFixed(1)}g C · {c.fat.toFixed(1)}g F</div>
            </Card>
          );
        })}
        <button onClick={addItem} style={{ width: "100%", padding: 13, borderRadius: 12, border: `1.5px dashed ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginBottom: 6 }}><Plus size={15} /> Add Ingredient</button>
        <p style={{ fontSize: 10.5, color: C.faint, textAlign: "center", margin: "0 0 20px" }}>{NUTRITION_SOURCE_LABEL}</p>
      </div>

      <div style={{ padding: 18, borderTop: `1px solid ${C.cardBorder}`, background: C.bg2 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ fontWeight: 700, fontSize: 15 }}>{totals.cals} kcal</span>
          <span style={{ fontSize: 13, color: C.sub }}>{totals.protein}g Protein · {totals.carbs}g Carbs · {totals.fat}g Fat</span>
        </div>
        {hasEmptyMeal && <p style={{ fontSize: 11.5, color: C.amber, margin: "0 0 10px" }}>Add at least one ingredient with a non-zero weight before logging.</p>}
        <div style={{ display: "flex", gap: 10 }}>
          <button disabled={hasEmptyMeal} onClick={() => setSaveOpen(true)} style={{ flex: 1, padding: 15, borderRadius: 14, border: `1px solid ${C.cardBorder}`, background: "transparent", color: hasEmptyMeal ? C.faint : C.text, fontWeight: 700, fontSize: 13.5 }}>Save as Meal</button>
          <button disabled={hasEmptyMeal || submitting} onClick={() => { if (submitting) return; setSubmitting(true); onLog({ name: items.map(i => findFood(i.foodId).name).join(", "), cals: totals.cals, protein: totals.protein, carbs: totals.carbs, fat: totals.fat, fiber: totals.fiber, source: "scale" }); }} style={{ flex: 2, padding: 15, borderRadius: 14, border: "none", background: (hasEmptyMeal || submitting) ? "#1A2327" : `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: (hasEmptyMeal || submitting) ? C.faint : "#04211D", fontWeight: 700, fontSize: 15, fontFamily: "Space Grotesk, sans-serif" }}>{submitting ? "Logging…" : "Log Measured Meal"}</button>
        </div>
      </div>

      {saveOpen && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(4,6,7,0.8)", zIndex: 60, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <Card style={{ width: "100%", maxWidth: 360 }}>
            <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 15 }}>Name this meal</span>
            <input value={mealName} onChange={e => setMealName(e.target.value)} placeholder="e.g. My Chicken Bowl" autoFocus
              style={{ width: "100%", marginTop: 12, background: "#1A2327", border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "12px 14px", color: C.text, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
            <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
              <button onClick={() => setSaveOpen(false)} style={{ flex: 1, padding: 12, borderRadius: 10, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600 }}>Cancel</button>
              <button disabled={!mealName.trim()} onClick={() => {
                onSaveMeal && onSaveMeal({ name: mealName.trim(), ingredients: items.map(i => ({ foodId: i.foodId, grams: i.grams })), ...totals });
                setSaveOpen(false); setMealName("");
              }} style={{ flex: 1, padding: 12, borderRadius: 10, border: "none", background: mealName.trim() ? C.teal : "#1A2327", color: mealName.trim() ? "#04211D" : C.faint, fontWeight: 700 }}>Save</button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* RECIPES                                                                  */
/* ---------------------------------------------------------------------- */
const RECIPE_LIBRARY = [
  { id: "chicken_rice_bowl", name: "Chicken Rice Bowl", baseServings: 1, prepTime: "20 min",
    ingredients: [{ foodId: "chicken_breast", grams: 180 }, { foodId: "white_rice", grams: 200 }, { foodId: "broccoli", grams: 100 }, { foodId: "olive_oil", grams: 10 }],
    instructions: ["Season and grill the chicken breast until cooked through.", "Steam the broccoli until tender-crisp.", "Serve everything over cooked rice, drizzled with olive oil."] },
  { id: "salmon_potato_veg", name: "Salmon, Potatoes & Vegetables", baseServings: 1, prepTime: "25 min",
    ingredients: [{ foodId: "salmon", grams: 160 }, { foodId: "sweet_potato", grams: 180 }, { foodId: "asparagus", grams: 100 }, { foodId: "olive_oil", grams: 8 }],
    instructions: ["Roast the sweet potato and asparagus with olive oil at 200°C/400°F for 20 minutes.", "Pan-sear or bake the salmon until just cooked through.", "Plate together."] },
  { id: "high_protein_yogurt_bowl", name: "High-Protein Yogurt Bowl", baseServings: 1, prepTime: "5 min",
    ingredients: [{ foodId: "greek_yogurt", grams: 200 }, { foodId: "banana", grams: 100 }, { foodId: "oats", grams: 30 }],
    instructions: ["Stir the oats into the Greek yogurt and let sit 5 minutes to soften.", "Top with sliced banana."] },
  { id: "tofu_stir_fry_recipe", name: "Tofu Stir-Fry", baseServings: 1, prepTime: "20 min",
    ingredients: [{ foodId: "tofu", grams: 200 }, { foodId: "white_rice", grams: 150 }, { foodId: "broccoli", grams: 120 }, { foodId: "olive_oil", grams: 10 }],
    instructions: ["Pan-fry cubed tofu in olive oil until golden on most sides.", "Add broccoli and stir-fry until tender-crisp.", "Serve over cooked rice."] },
  { id: "protein_smoothie_recipe", name: "Protein Smoothie", baseServings: 1, prepTime: "5 min",
    ingredients: [{ foodId: "protein_powder", grams: 32 }, { foodId: "banana", grams: 118 }, { foodId: "greek_yogurt", grams: 100 }],
    instructions: ["Add all ingredients to a blender with ice and a splash of water or milk.", "Blend until smooth."] },
];

function RecipesScreen({ onClose, onLogEntry, onAddIngredientsToGrocery }) {
  const [openId, setOpenId] = useState(null);
  const [servingsById, setServingsById] = useState({});
  const [toast, setToast] = useState(null);

  const getServings = (recipe) => servingsById[recipe.id] || recipe.baseServings;
  const setServings = (recipe, n) => setServingsById(s => ({ ...s, [recipe.id]: Math.max(1, n) }));
  const scaledIngredients = (recipe) => {
    const servings = getServings(recipe);
    const ratio = servings / recipe.baseServings;
    return recipe.ingredients.map(ing => ({ ...ing, grams: Math.round(ing.grams * ratio) }));
  };

  function flashToast(msg) { setToast(msg); setTimeout(() => setToast(null), 1800); }

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 52, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text, paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Recipes</h2>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={17} color={C.text} /></button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 18px 40px" }}>
        {RECIPE_LIBRARY.map(recipe => {
          const isOpen = openId === recipe.id;
          const servings = getServings(recipe);
          const ingredients = scaledIngredients(recipe);
          const macros = nutritionForIngredients(ingredients);
          return (
            <Card key={recipe.id} style={{ marginBottom: 12 }}>
              <div onClick={() => setOpenId(isOpen ? null : recipe.id)} style={{ cursor: "pointer" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, fontFamily: "Space Grotesk, sans-serif" }}>{recipe.name}</div>
                    <div style={{ fontSize: 12, color: C.sub, marginTop: 3 }}>{macros.cals} kcal · {macros.protein}g P · {recipe.prepTime} · serves {servings}</div>
                  </div>
                  <ChevronLeft size={16} color={C.sub} style={{ transform: isOpen ? "rotate(90deg)" : "rotate(-90deg)", transition: "transform .15s" }} />
                </div>
              </div>
              {isOpen && (
                <div style={{ marginTop: 14, borderTop: `1px solid ${C.cardBorder}`, paddingTop: 14 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
                    <span style={{ fontSize: 12.5, color: C.sub }}>Servings</span>
                    <button onClick={() => setServings(recipe, servings - 1)} style={{ width: 26, height: 26, borderRadius: 8, background: "#1A2327", border: "none", color: C.text }}>−</button>
                    <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif" }}>{servings}</span>
                    <button onClick={() => setServings(recipe, servings + 1)} style={{ width: 26, height: 26, borderRadius: 8, background: "#1A2327", border: "none", color: C.text }}>+</button>
                  </div>
                  <div style={{ fontSize: 12.5, color: C.sub, marginBottom: 4, fontWeight: 600 }}>Ingredients</div>
                  {ingredients.map(ing => (
                    <div key={ing.foodId} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0" }}>
                      <span>{findFood(ing.foodId).name}</span><span style={{ color: C.sub }}>{ing.grams} g</span>
                    </div>
                  ))}
                  <div style={{ fontSize: 12.5, color: C.sub, margin: "12px 0 4px", fontWeight: 600 }}>Instructions</div>
                  <ol style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: C.text, lineHeight: 1.6 }}>
                    {recipe.instructions.map((step, i) => <li key={i}>{step}</li>)}
                  </ol>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 8, marginTop: 14 }}>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => { onAddIngredientsToGrocery(ingredients); flashToast("Added to grocery list"); }} style={{ flex: 1, padding: 11, borderRadius: 10, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontSize: 12.5, fontWeight: 600 }}>Add to Grocery List</button>
                      <button onClick={() => { onLogEntry({ name: recipe.name, ...macros, source: "recipe" }); flashToast("Added to today's log"); }} style={{ flex: 1, padding: 11, borderRadius: 10, border: "none", background: C.teal, color: "#04211D", fontSize: 12.5, fontWeight: 700 }}>Add to Today</button>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          );
        })}
      </div>
      {toast && (
        <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 999, padding: "10px 18px", fontSize: 13, fontWeight: 600, color: C.text }}>{toast}</div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* SEARCH FOOD (manual fallback + first-class logging path)                */
/* ---------------------------------------------------------------------- */
function SearchFoodScreen({ onClose, onLogEntry }) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [grams, setGrams] = useState(100);
  const [submitting, setSubmitting] = useState(false); // guards "Log Food" against double-tap
  const results = useMemo(() => searchFoods(query), [query]);

  if (selected) {
    const nutrition = scaleNutrition(selected.per100, grams);
    return (
      <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 53, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text, paddingTop: "env(safe-area-inset-top, 0px)" }}>
        <style>{FONT_IMPORT}</style>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
          <button onClick={() => setSelected(null)} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><ChevronLeft size={18} color={C.text} /></button>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 17, fontWeight: 700, margin: 0 }}>{selected.name}</h2>
          <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={17} color={C.text} /></button>
        </div>
        <div style={{ flex: 1, padding: "20px 18px" }}>
          <Card>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 16, marginBottom: 16 }}>
              <button onClick={() => setGrams(g => Math.max(0, g - 10))} style={{ width: 36, height: 36, borderRadius: 10, background: "#1A2327", border: "none", color: C.text }}><Minus size={16} /></button>
              <div style={{ textAlign: "center" }}>
                <input type="number" inputMode="numeric" value={grams} onChange={e => setGrams(Math.max(0, Number(e.target.value) || 0))}
                  style={{ width: 90, textAlign: "center", background: "transparent", border: "none", outline: "none", color: C.text, fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 28 }} />
                <div style={{ color: C.sub, fontSize: 12 }}>grams</div>
              </div>
              <button onClick={() => setGrams(g => g + 10)} style={{ width: 36, height: 36, borderRadius: 10, background: "#1A2327", border: "none", color: C.text }}><Plus size={16} /></button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 6 }}>
              <div><div style={{ fontSize: 11, color: C.sub }}>CALORIES</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{Math.round(nutrition.cals)}</div></div>
              <div><div style={{ fontSize: 11, color: C.sub }}>PROTEIN</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{Math.round(nutrition.protein)}g</div></div>
              <div><div style={{ fontSize: 11, color: C.sub }}>CARBS</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{Math.round(nutrition.carbs)}g</div></div>
              <div><div style={{ fontSize: 11, color: C.sub }}>FAT</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{Math.round(nutrition.fat)}g</div></div>
            </div>
          </Card>
          <p style={{ fontSize: 10.5, color: C.faint, textAlign: "center", margin: "10px 0 0" }}>{NUTRITION_SOURCE_LABEL}</p>
        </div>
        <div style={{ padding: 18, borderTop: `1px solid ${C.cardBorder}` }}>
          <button disabled={grams <= 0 || submitting} onClick={() => { if (submitting) return; setSubmitting(true); onLogEntry({ name: selected.name, ...roundNutrition(nutrition), source: "search" }); onClose(); }} style={{ width: "100%", padding: 15, borderRadius: 14, border: "none", background: (grams > 0 && !submitting) ? `linear-gradient(135deg, ${C.teal}, #22B8A6)` : "#1A2327", color: (grams > 0 && !submitting) ? "#04211D" : C.faint, fontWeight: 700, fontSize: 15, fontFamily: "Space Grotesk, sans-serif" }}>{submitting ? "Logging…" : "Log Food"}</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 53, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text, paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Search Food</h2>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={17} color={C.text} /></button>
      </div>
      <div style={{ padding: "10px 18px" }}>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search the food database…" autoFocus
          style={{ width: "100%", background: C.card, border: `1.5px solid ${C.cardBorder}`, borderRadius: 12, padding: "12px 14px", color: C.text, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "8px 18px 30px" }}>
        {results.length === 0 && <p style={{ color: C.sub, fontSize: 13, textAlign: "center", marginTop: 30 }}>No foods match "{query}".</p>}
        {results.map(food => (
          <Card key={food.id} onClick={() => { setSelected(food); setGrams(food.defaultServingGrams); }} style={{ marginBottom: 8, cursor: "pointer" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{food.name}</div>
                <div style={{ fontSize: 11.5, color: C.sub }}>{food.category} · per 100g: {food.per100.cals} kcal, {food.per100.protein}g P</div>
              </div>
              <ChevronLeft size={16} color={C.faint} style={{ transform: "rotate(180deg)" }} />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* LEVEL UP CELEBRATION                                                     */
/* ---------------------------------------------------------------------- */
function LevelUpOverlay({ from, to, rank, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2600);
    return () => clearTimeout(t);
  }, [onDone]);
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(4,6,7,0.88)", zIndex: 90, display: "flex", alignItems: "center", justifyContent: "center", animation: "fadeIn .25s ease" }} onClick={onDone}>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes popIn { 0% { transform: scale(0.6); opacity: 0; } 60% { transform: scale(1.08); opacity: 1; } 100% { transform: scale(1); } }
      `}</style>
      <div style={{ textAlign: "center", animation: "popIn .5s cubic-bezier(.34,1.56,.64,1)" }}>
        <div style={{ width: 84, height: 84, borderRadius: 22, margin: "0 auto 18px", background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 40px ${C.teal}66` }}>
          <Award size={40} color="#0B0F10" />
        </div>
        <div style={{ color: C.amber, fontWeight: 700, letterSpacing: 2, fontSize: 12, fontFamily: "Inter, sans-serif" }}>LEVEL UP</div>
        <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 34, color: C.text, margin: "6px 0" }}>{from} → {to}</div>
        <div style={{ color: C.sub, fontSize: 13 }}>Now {rank.name} rank</div>
      </div>
    </div>
  );
}

function DailySummary({ onClose, pct, xp, workoutDone, reps, formScore, nutritionPct, streak, coachNote, weeklyQuestsDone, weeklyQuestsTotal }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(4,6,7,0.75)", zIndex: 60, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div style={{ width: "100%", maxWidth: 480, background: C.bg2, borderTopLeftRadius: 26, borderTopRightRadius: 26, border: `1px solid ${C.cardBorder}`, padding: "28px 22px 30px", fontFamily: "Inter, sans-serif" }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: C.sub, fontWeight: 700, letterSpacing: 1 }}>DAY COMPLETE</div>
          <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 44, fontWeight: 700, color: C.teal, margin: "6px 0" }}>{pct}%</div>
          <Pill color={C.purple}>+{xp} XP</Pill>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>WORKOUT</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{workoutDone ? "Completed" : "Not done"}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>VERIFIED REPS</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{reps}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>FORM SCORE</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{formScore}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>NUTRITION</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{nutritionPct}%</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>QUESTS</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{weeklyQuestsDone} / {weeklyQuestsTotal}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>STREAK</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{streak} days</div></Card>
        </div>
        {coachNote && (
          <Card style={{ marginTop: 12, border: `1px solid ${C.purpleDim}`, background: `${C.purple}0A` }}>
            <div style={{ fontSize: 10.5, color: C.purple, fontWeight: 700, letterSpacing: 0.5, marginBottom: 5 }}>COACH NOTE</div>
            <p style={{ fontSize: 12.5, color: C.text, margin: 0, lineHeight: 1.5 }}>{coachNote}</p>
          </Card>
        )}
        <button onClick={onClose} style={{ width: "100%", marginTop: 20, padding: 15, borderRadius: 14, border: "none", background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontFamily: "Space Grotesk, sans-serif" }}>Done</button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* HOME                                                                     */
/* ---------------------------------------------------------------------- */
function HomeScreen({
  profile, workoutPlan, todayResults, nutrition, meals, loggedTotals, water, onAddWater, onStartWorkout, onOpenSummary,
  levelInfo, rank, streak, dailyQuests, weeklyQuests, bodyQuest, coachLine,
}) {
  const xpPct = (levelInfo.xpIntoLevel / levelInfo.xpForNextLevel) * 100;
  const completedExercises = Object.keys(todayResults).length;
  const totalSegments = 8;
  const filledSegments = Math.round((water / Math.max(nutrition.water, 0.1)) * totalSegments);
  const topWeeklyQuests = weeklyQuests.slice(0, 2);

  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
        <div><p style={{ color: C.sub, fontSize: 13, margin: 0 }}>Welcome back</p><h1 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 22, fontWeight: 700, margin: "2px 0 0" }}>{profile.name || "Athlete"}</h1></div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "8px 12px" }}><Flame size={16} color={C.amber} /><span style={{ fontWeight: 700, fontSize: 14 }}>{streak}</span></div>
      </div>

      <Card style={{ marginBottom: 14, background: `linear-gradient(135deg, ${C.tealDim}55, ${C.purpleDim}55)`, border: `1px solid ${C.tealDim}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 19, color: C.text }}>Level {levelInfo.level} — {rank.name.toUpperCase()}</div><div style={{ fontSize: 12, color: C.sub }}>{levelInfo.xpIntoLevel} / {levelInfo.xpForNextLevel} XP to next level</div></div>
          <Trophy size={26} color={C.amber} />
        </div>
        <ProgressBar value={xpPct} max={100} color={C.teal} height={8} />
      </Card>

      {/* AI Coach — "what should I do next?" */}
      <Card style={{ marginBottom: 14, border: `1px solid ${C.purpleDim}`, background: `${C.purple}0A` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}><Sparkles size={15} color={C.purple} /><span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 13.5 }}>Today's Focus</span></div>
        <p style={{ fontSize: 13, color: C.text, lineHeight: 1.5, margin: 0 }}>{coachLine}</p>
      </Card>

      <div onClick={onStartWorkout} style={{ cursor: "pointer" }}>
        <Card style={{ marginBottom: 14, border: `1px solid ${C.tealDim}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <Pill color={C.teal}>TODAY'S WORKOUT</Pill>
              <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 17, marginTop: 8 }}>{workoutPlan.length} exercises · {completedExercises}/{workoutPlan.length} done</div>
              <div style={{ fontSize: 12.5, color: C.sub, marginTop: 3 }}>{workoutPlan.map(e => e.name).join(" · ")}</div>
            </div>
            <Dumbbell size={22} color={C.teal} />
          </div>
          <button style={{ marginTop: 14, width: "100%", padding: 14, borderRadius: 13, border: "none", background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <Play size={16} fill="#04211D" /> START TODAY'S WORKOUT
          </button>
        </Card>
      </div>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Nutrition Today</span><UtensilsCrossed size={17} color={C.purple} /></div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><span style={{ fontSize: 13, color: C.sub }}>Calories</span><span style={{ fontSize: 13, fontWeight: 600 }}>{loggedTotals.cals} / {nutrition.calories} kcal</span></div>
        <ProgressBar value={loggedTotals.cals} max={nutrition.calories} color={C.purple} />
        <div style={{ display: "flex", justifyContent: "space-between", margin: "10px 0 6px" }}><span style={{ fontSize: 13, color: C.sub }}>Protein</span><span style={{ fontSize: 13, fontWeight: 600 }}>{loggedTotals.protein} / {nutrition.protein} g</span></div>
        <ProgressBar value={loggedTotals.protein} max={nutrition.protein} color={C.teal} />
      </Card>

      {/* Daily quests */}
      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Daily Quests</span><Target size={17} color={C.teal} /></div>
        {dailyQuests.map(q => (
          <div key={q.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ width: 18, height: 18, borderRadius: 6, border: `1.5px solid ${q.done ? C.green : C.cardBorder}`, background: q.done ? C.green : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {q.done && <Check size={12} color="#04211D" />}
              </div>
              <span style={{ fontSize: 13, color: q.done ? C.sub : C.text, textDecoration: q.done ? "line-through" : "none" }}>{q.label}</span>
            </div>
            <span style={{ fontSize: 11, color: C.faint }}>+{q.xp}</span>
          </div>
        ))}
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Today's Meals</span>
        {meals.map(m => (
          <div key={m.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderTop: `1px solid ${C.cardBorder}`, marginTop: 10 }}>
            <div><div style={{ fontSize: 13.5, fontWeight: 600, color: m.logged ? C.sub : C.text, textDecoration: m.logged ? "line-through" : "none" }}>{m.name}</div><div style={{ fontSize: 11.5, color: C.faint }}>{m.tag} · {m.cals} kcal</div></div>
            {m.logged ? <Check size={16} color={C.green} /> : <Pill color={C.sub}>Planned</Pill>}
          </div>
        ))}
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}><Droplets size={18} color="#5EEAD4" /><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Hydration</span></div>
          <span style={{ fontSize: 13, fontWeight: 600 }}>{water.toFixed(2)}L / {nutrition.water}L</span>
        </div>
        <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
          {Array.from({ length: totalSegments }).map((_, i) => (
            <div key={i} onClick={() => onAddWater((i + 1 === filledSegments ? i : i + 1) / totalSegments * nutrition.water - water)}
              style={{ flex: 1, height: 26, borderRadius: 7, cursor: "pointer", background: i < filledSegments ? "linear-gradient(180deg,#5EEAD4,#2DD4BF)" : "#1A2327", border: `1px solid ${i < filledSegments ? "#2DD4BF" : C.cardBorder}` }} />
          ))}
        </div>
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Weekly Quests</span><Target size={17} color={C.purple} /></div>
        {topWeeklyQuests.map(q => (
          <div key={q.id} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5 }}><span style={{ color: C.text }}>{q.label}</span><span style={{ color: C.purple, fontWeight: 600 }}>{q.progress}/{q.total}</span></div>
            <div style={{ marginTop: 5 }}><ProgressBar value={q.progress} max={q.total} color={C.purple} height={6} /></div>
          </div>
        ))}
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Body Quest</span>
          <span style={{ fontSize: 12, color: C.sub }}>{bodyQuest.stageName} · {bodyQuest.pct}%</span>
        </div>
        <div style={{ marginTop: 8 }}><ProgressBar value={bodyQuest.pct} max={100} color={C.teal} height={6} /></div>
      </Card>

      <button onClick={onOpenSummary} style={{ width: "100%", padding: 13, borderRadius: 13, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600, fontSize: 13 }}>View Daily Summary</button>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* TRAIN                                                                    */
/* ---------------------------------------------------------------------- */
function TrainScreen({ workoutPlan, todayResults, lastSession, onStart }) {
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Train" subtitle="Camera-verified sets — no manual logging." />
      {workoutPlan.map((ex, i) => {
        const today = todayResults[ex.key];
        const last = lastSession[ex.key];
        return (
          <Card key={ex.id} style={{ marginBottom: 12, opacity: today ? 0.8 : 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: today ? `${C.green}22` : `${C.teal}18`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: today ? C.green : C.teal }}>
                  {today ? <Check size={18} /> : i + 1}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, fontFamily: "Space Grotesk, sans-serif" }}>{ex.name}</div>
                  <div style={{ fontSize: 12.5, color: C.sub }}>{ex.sets} sets × {ex.reps} reps{last ? ` · last: ${last.totalReps} reps, ${last.avgForm} form` : ""}</div>
                </div>
              </div>
              {!today && (<button onClick={() => onStart(i)} style={{ background: C.teal, border: "none", borderRadius: 10, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center" }}><Play size={16} color="#04211D" fill="#04211D" /></button>)}
            </div>
            {today?.isPR && (<div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 6 }}><Trophy size={14} color={C.amber} /><span style={{ fontSize: 12, fontWeight: 700, color: C.amber }}>NEW PERSONAL RECORD</span></div>)}
          </Card>
        );
      })}
      <Card style={{ marginTop: 6, background: "transparent", border: `1px dashed ${C.cardBorder}` }}>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <ShieldCheck size={16} color={C.sub} style={{ marginTop: 2, flexShrink: 0 }} />
          <p style={{ fontSize: 12, color: C.sub, margin: 0 }}>Reps are verified on-device with real pose tracking (TensorFlow.js MoveNet) — a full extend-flex-extend cycle must be completed to count. Guidance only, not a medical-grade assessment.</p>
        </div>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* EAT (Stage 1 — unchanged)                                                */
/* ---------------------------------------------------------------------- */
function NutritionRing({ pct, size = 54, label }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(1, pct / 100));
  const color = pct >= 80 ? C.green : pct >= 50 ? C.teal : C.amber;
  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#1A2327" strokeWidth={6} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={6} fill="none"
          strokeDasharray={circ} strokeDashoffset={circ * (1 - clamped)} strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: "stroke-dashoffset .5s ease" }} />
      </svg>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column" }}>
        <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 15, color: C.text }}>{pct}</span>
      </div>
    </div>
  );
}

function EatScreen({
  nutrition, meals, loggedEntries, water, savedMeals,
  onToggleMeal, onReplaceMeal, onRemoveEntry, onAddWater, onLogSavedMeal, onDeleteSavedMeal,
  onOpenScanner, onOpenScale, onOpenSearch, onOpenRecipes,
  grocery, groceryChecked, onToggleGroceryItem, onAddCustomGroceryItem, onRemoveGroceryItem,
}) {
  const [customItemText, setCustomItemText] = useState("");
  const totals = useMemo(() => roundNutrition(sumNutrition(loggedEntries)), [loggedEntries]);
  const remaining = {
    cals: Math.max(0, nutrition.calories - totals.cals),
    protein: Math.max(0, nutrition.protein - totals.protein),
    carbs: Math.max(0, nutrition.carbs - totals.carbs),
    fat: Math.max(0, nutrition.fat - totals.fat),
  };
  const score = computeNutritionScore(totals, nutrition);
  const mealsRemainingToday = meals.filter(m => !m.logged).length;
  const tip = getNutritionTip({ logged: totals, targets: nutrition, mealsRemainingToday });

  const SOURCE_LABEL = {
    planned: { label: "Planned", color: C.sub }, scan: { label: "AI Estimated", color: C.purple },
    "scan-mock": { label: "Dev Mock", color: C.amber }, scale: { label: "Measured", color: C.green },
    search: { label: "Searched", color: C.teal }, recipe: { label: "Recipe", color: C.purple },
    "saved-meal": { label: "Saved Meal", color: C.teal },
  };

  const groceryByCategory = useMemo(() => {
    const groups = {};
    CATEGORIES.forEach(c => { groups[c] = []; });
    grocery.forEach(item => {
      const cat = item.category || "Pantry";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(item);
    });
    return groups;
  }, [grocery]);

  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Eat" subtitle="Scan, weigh, search, and stay on target." />

      {/* Dashboard */}
      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 15 }}>Today</span>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <NutritionRing pct={score} />
            <span style={{ fontSize: 11, color: C.sub }}>Nutrition<br />Score</span>
          </div>
        </div>
        {[
          ["Calories", totals.cals, nutrition.calories, "", C.purple],
          ["Protein", totals.protein, nutrition.protein, "g", C.teal],
          ["Carbs", totals.carbs, nutrition.carbs, "g", C.amber],
          ["Fat", totals.fat, nutrition.fat, "g", C.red],
        ].map(([label, val, target, unit, color]) => (
          <div key={label} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}>
              <span style={{ color: C.sub }}>{label}</span>
              <span style={{ fontWeight: 600 }}>{val}{unit} / {target}{unit}</span>
            </div>
            <ProgressBar value={val} max={Math.max(target, 1)} color={color} height={7} />
          </div>
        ))}
        <div style={{ marginTop: 4 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 12.5, marginBottom: 4 }}>
            <span style={{ color: C.sub, display: "flex", alignItems: "center", gap: 5 }}><Droplets size={13} color="#5EEAD4" /> Water</span>
            <span style={{ fontWeight: 600 }}>{water.toFixed(2)}L / {nutrition.water}L</span>
          </div>
          <ProgressBar value={water} max={Math.max(nutrition.water, 0.1)} color="#5EEAD4" height={7} />
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button onClick={() => onAddWater(-0.25)} style={{ flex: 1, padding: 8, borderRadius: 9, background: "#1A2327", border: "none", color: C.text, fontSize: 12, fontWeight: 600 }}>−250ml</button>
            <button onClick={() => onAddWater(0.25)} style={{ flex: 1, padding: 8, borderRadius: 9, background: "#5EEAD422", border: `1px solid #2DD4BF44`, color: "#5EEAD4", fontSize: 12, fontWeight: 600 }}>+250ml</button>
          </div>
        </div>
      </Card>

      {/* Smart tip */}
      <Card style={{ marginBottom: 16, border: `1px solid ${C.purpleDim}`, background: `${C.purple}0A` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}><Sparkles size={15} color={C.purple} /><span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 13.5 }}>Nutrition Tip</span></div>
        <p style={{ fontSize: 13, color: C.text, lineHeight: 1.5, margin: 0 }}>{tip}</p>
      </Card>

      {/* Actions */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
        <button onClick={onOpenScanner} style={{ padding: "14px 10px", borderRadius: 16, border: `1px solid ${C.tealDim}`, background: `${C.teal}10`, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, color: C.teal, cursor: "pointer" }}><Camera size={20} /><span style={{ fontWeight: 700, fontSize: 12.5, fontFamily: "Space Grotesk, sans-serif" }}>SCAN FOOD</span></button>
        <button onClick={onOpenScale} style={{ padding: "14px 10px", borderRadius: 16, border: `1px solid ${C.purpleDim}`, background: `${C.purple}10`, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, color: C.purple, cursor: "pointer" }}><Scale size={20} /><span style={{ fontWeight: 700, fontSize: 12.5, fontFamily: "Space Grotesk, sans-serif" }}>WEIGH FOOD</span></button>
        <button onClick={onOpenSearch} style={{ padding: "14px 10px", borderRadius: 16, border: `1px solid ${C.cardBorder}`, background: C.card, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, color: C.text, cursor: "pointer" }}><ScanLine size={20} color={C.sub} /><span style={{ fontWeight: 700, fontSize: 12.5, fontFamily: "Space Grotesk, sans-serif" }}>SEARCH FOOD</span></button>
        <button onClick={onOpenRecipes} style={{ padding: "14px 10px", borderRadius: 16, border: `1px solid ${C.cardBorder}`, background: C.card, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, color: C.text, cursor: "pointer" }}><UtensilsCrossed size={20} color={C.sub} /><span style={{ fontWeight: 700, fontSize: 12.5, fontFamily: "Space Grotesk, sans-serif" }}>RECIPES</span></button>
      </div>

      {/* Today's log */}
      <Card style={{ marginBottom: 16 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14 }}>Logged Today</span>
        {loggedEntries.length === 0 && <p style={{ fontSize: 12.5, color: C.sub, margin: "10px 0 0" }}>Nothing logged yet — scan, weigh, or search a food to get started.</p>}
        {loggedEntries.map((e) => {
          const src = SOURCE_LABEL[e.source] || { label: e.source, color: C.sub };
          return (
            <div key={e.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderTop: `1px solid ${C.cardBorder}`, marginTop: 9 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.name}</div>
                <Pill color={src.color}>{src.label}</Pill>
              </div>
              <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: C.teal, marginLeft: 10 }}>{Math.round(e.cals)} kcal</span>
              <button onClick={() => onRemoveEntry(e.id)} style={{ background: "none", border: "none", color: C.faint, marginLeft: 8, padding: 4 }}><X size={14} /></button>
            </div>
          );
        })}
      </Card>

      {/* Today's meal plan */}
      <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 15 }}>Today's Meal Plan</span>
      {meals.map(m => (
        <Card key={m.id} style={{ marginTop: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div><Pill color={C.sub}>{m.tag}</Pill><div style={{ fontWeight: 700, fontSize: 15, marginTop: 6, fontFamily: "Space Grotesk, sans-serif" }}>{m.name}</div><div style={{ fontSize: 12, color: C.sub, marginTop: 2 }}>{m.cals} kcal · {m.protein}g P · {m.time}</div></div>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button onClick={() => onReplaceMeal(m.id)} style={{ flex: 1, padding: 10, borderRadius: 10, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontSize: 12.5, fontWeight: 600 }}>Replace</button>
            <button onClick={() => onToggleMeal(m)} style={{ flex: 1, padding: 10, borderRadius: 10, border: "none", background: m.logged ? `${C.green}22` : C.teal, color: m.logged ? C.green : "#04211D", fontSize: 12.5, fontWeight: 700 }}>{m.logged ? "Logged ✓" : "Log Meal"}</button>
          </div>
        </Card>
      ))}

      {/* Saved meals */}
      {savedMeals.length > 0 && (
        <Card style={{ marginTop: 16 }}>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Saved Meals</span>
          {savedMeals.map(sm => (
            <div key={sm.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderTop: `1px solid ${C.cardBorder}`, marginTop: 9 }}>
              <div><div style={{ fontSize: 13, fontWeight: 600 }}>{sm.name}</div><div style={{ fontSize: 11.5, color: C.sub }}>{sm.cals} kcal · {sm.protein}g P</div></div>
              <div style={{ display: "flex", gap: 6 }}>
                <button onClick={() => onLogSavedMeal(sm)} style={{ padding: "7px 12px", borderRadius: 9, border: "none", background: C.teal, color: "#04211D", fontSize: 12, fontWeight: 700 }}>Log</button>
                <button onClick={() => onDeleteSavedMeal(sm.id)} style={{ background: "none", border: "none", color: C.faint, padding: 4 }}><X size={14} /></button>
              </div>
            </div>
          ))}
        </Card>
      )}

      {/* Grocery list */}
      <Card style={{ marginTop: 16 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Grocery List</span>
        <p style={{ fontSize: 12, color: C.sub, margin: "4px 0 12px" }}>Auto-generated from today's meal plan.</p>
        {Object.entries(groceryByCategory).filter(([, items]) => items.length > 0).map(([cat, items]) => (
          <div key={cat} style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.faint, letterSpacing: 0.4, marginBottom: 6, textTransform: "uppercase" }}>{cat}</div>
            {items.map(item => {
              const checked = !!groceryChecked[item.key];
              return (
                <div key={item.key} onClick={() => onToggleGroceryItem(item.key)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "7px 0", cursor: "pointer" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <div style={{ width: 18, height: 18, borderRadius: 6, border: `1.5px solid ${checked ? C.teal : C.cardBorder}`, background: checked ? C.teal : "transparent", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      {checked && <Check size={12} color="#04211D" />}
                    </div>
                    <span style={{ fontSize: 13.5, color: checked ? C.sub : C.text, textDecoration: checked ? "line-through" : "none" }}>{item.name}</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 11.5, color: C.faint }}>{item.quantity}</span>
                    {item.custom && (
                      <button onClick={(e) => { e.stopPropagation(); onRemoveGroceryItem(item.key); }} style={{ background: "none", border: "none", color: C.faint, padding: 2 }}><X size={13} /></button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <input value={customItemText} onChange={e => setCustomItemText(e.target.value)} placeholder="Add custom item…"
            style={{ flex: 1, background: "#1A2327", border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "9px 12px", color: C.text, fontSize: 13, outline: "none" }} />
          <button onClick={() => { if (customItemText.trim()) { onAddCustomGroceryItem(customItemText.trim()); setCustomItemText(""); } }} style={{ padding: "9px 14px", borderRadius: 10, border: "none", background: C.teal, color: "#04211D", fontWeight: 700 }}><Plus size={15} /></button>
        </div>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* PROGRESS                                                                 */
/* ---------------------------------------------------------------------- */
function ProgressScreen({ stats, formHistory, weightLog, onLogWeight, sessionVolumeTrend, currentWeight }) {
  const [weightInput, setWeightInput] = useState("");
  const radarData = [
    { stat: "Strength", v: stats.strength }, { stat: "Muscle", v: stats.muscle },
    { stat: "Endurance", v: stats.endurance }, { stat: "Mobility", v: stats.mobility },
    { stat: "Form", v: stats.form }, { stat: "Consistency", v: stats.consistency },
  ];
  const formTrend = formHistory.length ? formHistory : [{ d: "—", v: stats.form }];
  const weightTrend = weightLog.length ? weightLog.slice(-8).map(w => ({ d: w.date.slice(5), v: w.weightKg })) : [{ d: "—", v: currentWeight }];
  const volumeTrend = sessionVolumeTrend.length ? sessionVolumeTrend : [{ d: "—", v: 0 }];
  const weightErr = weightInput !== "" && (Number(weightInput) < 30 || Number(weightInput) > 300 || !Number.isFinite(Number(weightInput)));
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Progress" subtitle="You vs. you — tracked over time." />
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Attributes</span>
        <div style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData} outerRadius="70%">
              <PolarGrid stroke={C.cardBorder} />
              <PolarAngleAxis dataKey="stat" tick={{ fill: C.sub, fontSize: 11 }} />
              <Radar dataKey="v" stroke={C.teal} fill={C.teal} fillOpacity={0.35} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Weight Trend</span>
          <span style={{ fontSize: 12, color: C.sub }}>{currentWeight} kg</span>
        </div>
        {weightLog.length === 0 && <p style={{ fontSize: 11.5, color: C.faint, margin: "0 0 8px" }}>No weigh-ins logged yet — log one below to start a real trend.</p>}
        <div style={{ height: 160, marginTop: 6 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={weightTrend}>
              <CartesianGrid stroke={C.cardBorder} vertical={false} />
              <XAxis dataKey="d" stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} domain={["dataMin - 1", "dataMax + 1"]} />
              <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, fontSize: 12 }} />
              <Line type="monotone" dataKey="v" stroke={C.teal} strokeWidth={2.5} dot={weightLog.length <= 1} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
          <input type="number" inputMode="decimal" value={weightInput} onChange={e => setWeightInput(e.target.value.replace(/^-/, ""))} placeholder="Log today's weight (kg)"
            style={{ flex: 1, background: "#1A2327", border: `1px solid ${weightErr ? C.red : C.cardBorder}`, borderRadius: 10, padding: "9px 12px", color: C.text, fontSize: 13, outline: "none" }} />
          <button disabled={!weightInput || weightErr} onClick={() => { onLogWeight(Number(weightInput)); setWeightInput(""); }}
            style={{ padding: "9px 16px", borderRadius: 10, border: "none", background: (!weightInput || weightErr) ? "#1A2327" : C.teal, color: (!weightInput || weightErr) ? C.faint : "#04211D", fontWeight: 700, fontSize: 12.5 }}>Log</button>
        </div>
        {weightErr && <p style={{ color: C.red, fontSize: 11, margin: "5px 0 0" }}>Enter a weight between 30 and 300 kg.</p>}
      </Card>
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Verified Rep Volume — Recent Sessions</span>
        <p style={{ fontSize: 11, color: C.faint, margin: "2px 0 0" }}>Total camera-verified reps per session.</p>
        <div style={{ height: 160, marginTop: 6 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={volumeTrend}>
              <CartesianGrid stroke={C.cardBorder} vertical={false} />
              <XAxis dataKey="d" stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, fontSize: 12 }} />
              <Bar dataKey="v" fill={C.purple} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Verified Form Score — Recent Sessions</span>
        <div style={{ height: 140, marginTop: 6 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={formTrend}>
              <CartesianGrid stroke={C.cardBorder} vertical={false} />
              <XAxis dataKey="d" stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} domain={[50, 100]} />
              <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, fontSize: 12 }} />
              <Line type="monotone" dataKey="v" stroke={C.green} strokeWidth={2.5} dot={{ r: 3, fill: C.green }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* PROFILE + AI COACH + BODY QUEST                                         */
/* ---------------------------------------------------------------------- */
function CoachPanel({ profile, lastSession, nutritionSummary, levelInfo, rank, bodyQuest, weeklyQuests }) {
  const keys = Object.keys(lastSession);
  const workoutLine = keys.length
    ? `Your last session verified ${keys.map(k => `${lastSession[k].totalReps} ${EXERCISES[k].name.toLowerCase()} reps`).join(", ")} with an average form score of ${Math.round(keys.reduce((a, k) => a + lastSession[k].avgForm, 0) / keys.length)}.`
    : `Complete your first camera-verified workout and I'll fold that into your recommendations too.`;
  const nutritionLine = nutritionSummary ? getNutritionTip(nutritionSummary) : "";
  const nearestQuest = weeklyQuests.filter(q => q.progress < q.total).sort((a, b) => (a.total - a.progress) - (b.total - b.progress))[0];
  const questLine = nearestQuest
    ? ` You're ${nearestQuest.progress}/${nearestQuest.total} on "${nearestQuest.label}" — closest quest to finishing this week.`
    : " You've cleared this week's quests — nice work staying consistent.";
  const fallbackMsg = `${workoutLine} ${nutritionLine}${questLine}`.trim();

  // The panel always renders instantly with the local fallback message
  // (computed from real on-device training + nutrition + quest data),
  // then quietly upgrades to a backend-generated message if the secure
  // coach API is reachable. Nothing here changes if VITE_COACH_API_URL is
  // unset or the network request fails — the UI is identical either way.
  const [msg, setMsg] = useState(fallbackMsg);
  useEffect(() => {
    setMsg(fallbackMsg);
    let cancelled = false;
    fetchCoachMessage({ profile, lastSession, level: levelInfo.level, rank: rank.name, bodyQuest, nutrition: nutritionSummary, weeklyQuests }).then(remote => {
      if (!cancelled && remote) setMsg(remote);
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line
  }, [JSON.stringify(lastSession), JSON.stringify(nutritionSummary), JSON.stringify(weeklyQuests)]);

  return (
    <Card style={{ marginBottom: 16, border: `1px solid ${C.purpleDim}`, background: `${C.purple}0A` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}><Sparkles size={17} color={C.purple} /><span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>AI Coach</span></div>
      <p style={{ fontSize: 13.5, color: C.text, lineHeight: 1.5, margin: 0 }}>{msg}</p>
    </Card>
  );
}

/* ========================================================================
   SETTINGS — camera permission status/controls, plus basic app info.
   Two ways of checking are combined because WebView support for the
   Permissions API varies by device: `navigator.permissions.query` gives a
   non-invasive read (no prompt) when supported, while "Check Camera
   Access" does a real getUserMedia probe (stops the stream immediately)
   for a ground-truth answer, which also happens to be the path that
   actually triggers Android's permission dialog the first time.
   ======================================================================== */
async function queryCameraPermission() {
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const result = await navigator.permissions.query({ name: "camera" });
      return result.state; // 'granted' | 'denied' | 'prompt'
    }
  } catch (e) { /* some WebViews don't support querying 'camera' — fall through */ }
  return "unknown";
}

async function probeCameraAccess() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    stream.getTracks().forEach(t => t.stop());
    return "granted";
  } catch (err) {
    if (err && err.name === "NotFoundError") return "no-camera";
    return "denied";
  }
}

function SettingsScreen({ onClose }) {
  const [status, setStatus] = useState("checking");
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    let cancelled = false;
    queryCameraPermission().then(s => { if (!cancelled) setStatus(s); });
    return () => { cancelled = true; };
  }, []);

  async function handleCheck() {
    setChecking(true);
    const result = await probeCameraAccess();
    setStatus(result);
    setChecking(false);
  }

  function handleOpenAppSettings() {
    try {
      NativeSettings.open({ optionAndroid: AndroidSettings.ApplicationDetails });
    } catch (e) {
      // Running in a plain browser (no native bridge) — nothing to open.
    }
  }

  const statusMeta = {
    checking: { label: "Checking…", color: C.sub, desc: "Looking up your current camera permission." },
    unknown: { label: "Unknown", color: C.amber, desc: "This device can't report camera status without asking. Tap \"Check Camera Access\" below to find out for sure." },
    prompt: { label: "Not decided yet", color: C.amber, desc: "Android hasn't asked you yet. Tap \"Check Camera Access\" to trigger the permission prompt." },
    granted: { label: "Camera access is ON", color: C.green, desc: "Train and Eat can use your camera for verified reps and food scanning." },
    denied: { label: "Camera access is OFF", color: C.red, desc: "Verified reps and food scanning won't work until you turn this on in Android's app settings." },
    "no-camera": { label: "No camera found", color: C.amber, desc: "This device doesn't appear to have an accessible camera." },
  };
  const meta = statusMeta[status] || statusMeta.unknown;

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 55, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text, paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <SettingsIcon size={19} color={C.teal} />
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Settings</h2>
        </div>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <X size={17} color={C.text} />
        </button>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 18px 40px" }}>
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Camera size={17} color={meta.color} />
              <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Camera Access</span>
            </div>
            <Pill color={meta.color}>{meta.label}</Pill>
          </div>
          <p style={{ fontSize: 13, color: C.sub, lineHeight: 1.5, margin: "0 0 16px" }}>{meta.desc}</p>

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={handleCheck} disabled={checking} style={{
              flex: 1, padding: 13, borderRadius: 12, border: "none",
              background: checking ? "#1A2327" : `linear-gradient(135deg, ${C.teal}, #22B8A6)`,
              color: checking ? C.faint : "#04211D", fontWeight: 700, fontSize: 13,
              display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
            }}>
              <RefreshCw size={14} className={checking ? "spin" : ""} /> {checking ? "Checking…" : "Check Camera Access"}
            </button>
            {(status === "denied" || status === "granted" || status === "no-camera") && (
              <button onClick={handleOpenAppSettings} style={{
                flex: 1, padding: 13, borderRadius: 12, border: `1px solid ${C.cardBorder}`, background: "transparent",
                color: C.text, fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}>
                <ExternalLink size={14} /> Open App Settings
              </button>
            )}
          </div>
          <style>{`.spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </Card>

        <Card style={{ marginBottom: 16, background: "transparent", border: `1px dashed ${C.cardBorder}` }}>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
            <ShieldCheck size={16} color={C.sub} style={{ marginTop: 2, flexShrink: 0 }} />
            <p style={{ fontSize: 12, color: C.sub, margin: 0 }}>
              If camera access shows as OFF, tap "Open App Settings", choose <strong>Permissions → Camera</strong>, and
              set it to Allow. Come back here and tap "Check Camera Access" to confirm it worked.
            </p>
          </div>
        </Card>

        <Card>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>About</span>
          <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
            <span style={{ color: C.sub }}>Version</span><span style={{ fontWeight: 600 }}>1.0.0</span>
          </div>
          <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
            <span style={{ color: C.sub }}>Pose tracking</span><span style={{ fontWeight: 600 }}>On-device (TensorFlow.js)</span>
          </div>
        </Card>
      </div>
    </div>
  );
}


function RankBadge({ rank, size = 44 }) {
  return (
    <div style={{ width: size, height: size, borderRadius: 14, background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <Award size={size * 0.5} color="#0B0F10" />
    </div>
  );
}

function ProfileScreen({
  profile, lastSession, onOpenSettings, onOpenAchievements, nutritionSummary,
  levelInfo, rank, stats, bodyQuest, milestone, weeklyQuests, xpToday, xpThisWeek, recentXpEvents,
}) {
  const next = nextRank(levelInfo.level);
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Profile" subtitle={`${rank.name} · Level ${levelInfo.level}`}
        right={(
          <button onClick={onOpenSettings} style={{ width: 38, height: 38, borderRadius: 12, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <SettingsIcon size={17} color={C.sub} />
          </button>
        )} />

      <Card style={{ marginBottom: 16, textAlign: "center" }}>
        <div style={{ width: 68, height: 68, borderRadius: "50%", margin: "0 auto 10px", background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 24, color: "#0B0F10" }}>{(profile.name || "A")[0]}</span></div>
        <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 17 }}>{profile.name || "Athlete"}</div>
        <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2 }}>{profile.goal} · {profile.level}</div>
      </Card>

      <CoachPanel profile={profile} lastSession={lastSession} nutritionSummary={nutritionSummary} levelInfo={levelInfo} rank={rank} bodyQuest={bodyQuest} weeklyQuests={weeklyQuests} />

      {/* Level + Rank */}
      <Card style={{ marginBottom: 16, border: `1px solid ${C.tealDim}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <RankBadge rank={rank} />
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 17 }}>Level {levelInfo.level} — {rank.name.toUpperCase()}</div>
            <div style={{ fontSize: 11.5, color: C.sub, marginTop: 2 }}>{rank.description}</div>
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: C.sub, marginBottom: 5 }}>
          <span>{levelInfo.xpIntoLevel} / {levelInfo.xpForNextLevel} XP</span>
          {next && <span>Next: {next.name} at Lv.{next.minLevel}</span>}
        </div>
        <ProgressBar value={levelInfo.xpIntoLevel} max={levelInfo.xpForNextLevel} color={C.teal} height={8} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 14 }}>
          <div><div style={{ fontSize: 10.5, color: C.sub }}>XP TODAY</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 18, color: C.teal }}>+{xpToday}</div></div>
          <div><div style={{ fontSize: 10.5, color: C.sub }}>XP THIS WEEK</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 18, color: C.purple }}>+{xpThisWeek}</div></div>
        </div>
        {recentXpEvents.length > 0 && (
          <div style={{ marginTop: 14, borderTop: `1px solid ${C.cardBorder}`, paddingTop: 10 }}>
            <div style={{ fontSize: 11, color: C.sub, fontWeight: 600, marginBottom: 6 }}>RECENT XP</div>
            {recentXpEvents.map(e => (
              <div key={e.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, padding: "4px 0" }}>
                <span style={{ color: C.text }}>{e.reason}</span><span style={{ color: C.teal, fontWeight: 600 }}>+{e.amount}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      <button onClick={onOpenAchievements} style={{ width: "100%", marginBottom: 16, padding: 14, borderRadius: 14, border: `1px solid ${C.cardBorder}`, background: C.card, color: C.text, fontWeight: 700, fontSize: 13.5, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
        <Trophy size={16} color={C.amber} /> View Achievements
      </button>

      <Card style={{ marginBottom: 16 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Character Stats</span>
        <div style={{ marginTop: 12 }}>
          {Object.entries(stats).map(([k, v]) => (
            <div key={k} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}><span style={{ textTransform: "capitalize", color: C.text }}>{k}</span><span style={{ color: C.teal, fontWeight: 700 }}>{v}</span></div>
              <ProgressBar value={v} max={100} color={k === "form" ? C.green : k === "consistency" ? C.purple : C.teal} height={6} />
            </div>
          ))}
        </div>
      </Card>

      {/* Body Quest */}
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Body Quest</span>
          <Award size={17} color={C.amber} />
        </div>
        <div style={{ fontSize: 11.5, color: C.sub, marginBottom: 14 }}>Current stage: <strong style={{ color: C.text }}>{bodyQuest.stageName.toUpperCase()}</strong> · {bodyQuest.pct}% to {bodyQuest.nextStageName || "max stage"}</div>
        <div style={{ display: "flex", alignItems: "center", marginBottom: 16 }}>
          {BODY_QUEST_STAGES.map((s, i) => (
            <React.Fragment key={s.name}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}>
                <div style={{ width: 34, height: 34, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: i <= bodyQuest.stageIndex ? `linear-gradient(135deg, ${C.teal}, ${C.purple})` : "#1A2327", border: `1px solid ${i <= bodyQuest.stageIndex ? C.teal : C.cardBorder}` }}>
                  {i <= bodyQuest.stageIndex ? <Check size={15} color="#04211D" /> : <Lock size={13} color={C.faint} />}
                </div>
                <span style={{ fontSize: 9.5, color: i <= bodyQuest.stageIndex ? C.text : C.faint, marginTop: 5, textAlign: "center" }}>{s.name}</span>
              </div>
              {i < BODY_QUEST_STAGES.length - 1 && <div style={{ flex: 0.6, height: 2, background: i < bodyQuest.stageIndex ? C.teal : C.cardBorder, marginBottom: 16 }} />}
            </React.Fragment>
          ))}
        </div>
        <div style={{ background: "#1A2327", borderRadius: 12, padding: 12 }}>
          <div style={{ fontSize: 10.5, color: C.sub, fontWeight: 700, letterSpacing: 0.3, marginBottom: 4 }}>NEXT MILESTONE</div>
          <div style={{ fontSize: 12.5, color: C.text, marginBottom: 8 }}>{milestone.label}</div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ flex: 1 }}><ProgressBar value={milestone.have} max={milestone.need} color={C.teal} height={6} /></div>
            <span style={{ fontSize: 12, fontWeight: 700, color: C.teal }}>{milestone.have} / {milestone.need}</span>
          </div>
        </div>
      </Card>

      <Card>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Weekly Quests</span>
        {weeklyQuests.map(q => (
          <div key={q.id} style={{ marginTop: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 5 }}>
              <span>{q.label} {q.progress >= q.total && <Check size={12} color={C.green} style={{ verticalAlign: "-1px", marginLeft: 4 }} />}</span>
              <span style={{ color: C.purple, fontWeight: 700 }}>+{q.xp} XP</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ flex: 1 }}><ProgressBar value={q.progress} max={q.total} color={q.progress >= q.total ? C.green : C.purple} height={6} /></div>
              <span style={{ fontSize: 11, color: C.sub, minWidth: 34, textAlign: "right" }}>{q.progress}/{q.total}</span>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* ACHIEVEMENTS SCREEN                                                      */
/* ---------------------------------------------------------------------- */
function AchievementsScreen({ onClose, achievementsStatus }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 54, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text, paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Achievements</h2>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={17} color={C.text} /></button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "14px 18px 40px" }}>
        {achievementsStatus.map(a => (
          <Card key={a.id} style={{ marginBottom: 10, opacity: a.unlocked ? 1 : 0.75 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: a.unlocked ? `linear-gradient(135deg, ${C.teal}, ${C.purple})` : "#1A2327", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                {a.unlocked ? <Trophy size={18} color="#04211D" /> : <Lock size={16} color={C.faint} />}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 14, fontFamily: "Space Grotesk, sans-serif", color: a.unlocked ? C.text : C.sub }}>{a.name}</div>
                <div style={{ fontSize: 11.5, color: C.sub, marginTop: 2 }}>{a.desc}</div>
                {a.unlocked ? (
                  <div style={{ fontSize: 10.5, color: C.green, marginTop: 4 }}>Unlocked {new Date(a.unlockedAt).toLocaleDateString()}</div>
                ) : (
                  <div style={{ marginTop: 6 }}><ProgressBar value={a.progress} max={1} color={C.teal} height={5} /></div>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* NAV                                                                      */
/* ---------------------------------------------------------------------- */
function BottomNav({ tab, setTab }) {
  const items = [
    { id: "home", label: "Home", icon: HomeIcon }, { id: "train", label: "Train", icon: Dumbbell },
    { id: "eat", label: "Eat", icon: UtensilsCrossed }, { id: "progress", label: "Progress", icon: TrendingUp },
    { id: "profile", label: "Profile", icon: User },
  ];
  return (
    <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, maxWidth: 480, margin: "0 auto", background: "rgba(11,15,16,0.92)", backdropFilter: "blur(12px)", borderTop: `1px solid ${C.cardBorder}`, display: "flex", padding: "10px 6px calc(env(safe-area-inset-bottom,0px) + 10px)", zIndex: 20 }}>
      {items.map(({ id, label, icon: Icon }) => {
        const active = tab === id;
        return (
          <button key={id} onClick={() => setTab(id)} style={{ flex: 1, background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0", cursor: "pointer" }}>
            <Icon size={20} color={active ? C.teal : C.faint} strokeWidth={active ? 2.4 : 2} />
            <span style={{ fontSize: 10.5, color: active ? C.teal : C.faint, fontWeight: active ? 700 : 500, fontFamily: "Inter, sans-serif" }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* ROOT APP                                                                 */
/* ---------------------------------------------------------------------- */
function uid() {
  return (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`);
}

// Aggregates today's planned meals' ingredients into a shopping list,
// grouped by the same category field the food database already carries —
// no separate hardcoded grocery list exists anywhere.
function buildGroceryList(meals, groceryCustom) {
  const totals = {};
  meals.forEach(m => (m.ingredients || []).forEach(ing => {
    totals[ing.foodId] = (totals[ing.foodId] || 0) + ing.grams;
  }));
  const auto = Object.entries(totals).map(([foodId, grams]) => {
    const food = findFood(foodId);
    if (!food) return null;
    return { key: foodId, name: food.name, category: food.category, quantity: `${Math.round(grams)}g`, custom: false };
  }).filter(Boolean);
  const custom = groceryCustom.map(c => ({ key: `custom_${c.id}`, name: c.name, category: c.category || "Pantry", quantity: "", custom: true }));
  return [...auto, ...custom];
}

function FormApp() {
  const [profile, setProfile] = useState(null);
  const [tab, setTab] = useState("home");
  const [workoutPlan, setWorkoutPlan] = useState([]);
  const [nutrition, setNutrition] = useState(null);
  const [meals, setMeals] = useState([]);
  const [nutritionLog, setNutritionLog] = useState({ date: dateKey(), entries: [], water: 0 });
  const [savedMeals, setSavedMeals] = useState([]);
  const [groceryChecked, setGroceryChecked] = useState({});
  const [groceryCustom, setGroceryCustom] = useState([]);
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionStartIndex, setSessionStartIndex] = useState(0);
  const [todayResults, setTodayResults] = useState({});
  const [lastSession, setLastSession] = useState({});
  const [formHistory, setFormHistory] = useState([]);
  const [weightLog, setWeightLog] = useState([]); // [{id, date, weightKg}] — real, user-logged, not decorative
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scaleOpen, setScaleOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [recipesOpen, setRecipesOpen] = useState(false);
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [achievementsOpen, setAchievementsOpen] = useState(false);
  const [xpToast, setXpToast] = useState(null);
  const [levelUpFlash, setLevelUpFlash] = useState(null);

  // ---- Progression ground truth (everything else on screen is derived
  // from just these — see src/progression.js) ----
  const [personalBests, setPersonalBests] = useState({
    squat: { reps: 40 }, pushup: { reps: 32 }, bicepcurl: { reps: 38 }, lunge: { reps: 30 },
  });
  const [totalXp, setTotalXp] = useState(0);
  const [xpLedger, setXpLedger] = useState([]); // full audit trail — every award, ever
  const [activityLog, setActivityLog] = useState({ workoutSessions: [], nutritionByDate: {} });
  const [unlockedAchievements, setUnlockedAchievements] = useState({}); // { [id]: timestamp }
  const [awardedQuestIds, setAwardedQuestIds] = useState({}); // dedupe guard for quest/achievement XP

  const loadedRef = useRef(false);
  const prevLevelRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const saved = await storage.get("form:profile");
        if (saved?.value) {
          const p = JSON.parse(saved.value);
          setProfile(p);
          setWorkoutPlan(buildWorkoutPlan(p));
          setNutrition(buildNutritionTargets(p));
          let freshMeals = buildMealPlan(p);

          // Nutrition log is date-keyed: a stale (yesterday's) log is
          // discarded here, which is the app's daily-reset behavior. A
          // same-day log is restored and cross-referenced back onto the
          // freshly-built meal plan so "logged" checkmarks survive a
          // cold restart instead of just resetting to unlogged.
          const savedLog = await storage.get("form:nutritionLog");
          let log = { date: dateKey(), entries: [], water: 0 };
          if (savedLog?.value) {
            const parsed = JSON.parse(savedLog.value);
            if (parsed.date === dateKey()) log = parsed;
          }
          const loggedPlannedIds = new Set(log.entries.filter(e => e.source === "planned").map(e => e.id));
          freshMeals = freshMeals.map(m => loggedPlannedIds.has(m.id) ? { ...m, logged: true } : m);
          setMeals(freshMeals);
          setNutritionLog(log);
        }

        const savedMealsRaw = await storage.get("form:savedMeals");
        if (savedMealsRaw?.value) setSavedMeals(JSON.parse(savedMealsRaw.value));
        const groceryRaw = await storage.get("form:grocery");
        if (groceryRaw?.value) {
          const g = JSON.parse(groceryRaw.value);
          setGroceryChecked(g.checked || {});
          setGroceryCustom(g.custom || []);
        }

        const pbRaw = await storage.get("form:personalBests");
        if (pbRaw?.value) setPersonalBests(JSON.parse(pbRaw.value));
        const xpRaw = await storage.get("form:totalXp");
        if (xpRaw?.value) setTotalXp(Number(xpRaw.value) || 0);
        const ledgerRaw = await storage.get("form:xpLedger");
        if (ledgerRaw?.value) setXpLedger(JSON.parse(ledgerRaw.value));
        const logRaw = await storage.get("form:activityLog");
        if (logRaw?.value) setActivityLog(JSON.parse(logRaw.value));
        const achRaw = await storage.get("form:unlockedAchievements");
        if (achRaw?.value) setUnlockedAchievements(JSON.parse(achRaw.value));
        const awardedRaw = await storage.get("form:awardedQuestIds");
        if (awardedRaw?.value) setAwardedQuestIds(JSON.parse(awardedRaw.value));
        const weightRaw = await storage.get("form:weightLog");
        if (weightRaw?.value) setWeightLog(JSON.parse(weightRaw.value));
      } catch (e) { /* no saved profile yet — onboarding will run */ }
      loadedRef.current = true;
    })();
  }, []);

  useEffect(() => { if (loadedRef.current) storage.set("form:nutritionLog", JSON.stringify(nutritionLog)).catch(() => {}); }, [nutritionLog]);
  useEffect(() => { if (loadedRef.current) storage.set("form:savedMeals", JSON.stringify(savedMeals)).catch(() => {}); }, [savedMeals]);
  useEffect(() => { if (loadedRef.current) storage.set("form:grocery", JSON.stringify({ checked: groceryChecked, custom: groceryCustom })).catch(() => {}); }, [groceryChecked, groceryCustom]);
  useEffect(() => { if (loadedRef.current) storage.set("form:personalBests", JSON.stringify(personalBests)).catch(() => {}); }, [personalBests]);
  useEffect(() => { if (loadedRef.current) storage.set("form:totalXp", String(totalXp)).catch(() => {}); }, [totalXp]);
  useEffect(() => { if (loadedRef.current) storage.set("form:xpLedger", JSON.stringify(xpLedger)).catch(() => {}); }, [xpLedger]);
  useEffect(() => { if (loadedRef.current) storage.set("form:activityLog", JSON.stringify(activityLog)).catch(() => {}); }, [activityLog]);
  useEffect(() => { if (loadedRef.current) storage.set("form:unlockedAchievements", JSON.stringify(unlockedAchievements)).catch(() => {}); }, [unlockedAchievements]);
  useEffect(() => { if (loadedRef.current) storage.set("form:awardedQuestIds", JSON.stringify(awardedQuestIds)).catch(() => {}); }, [awardedQuestIds]);
  useEffect(() => { if (loadedRef.current) storage.set("form:weightLog", JSON.stringify(weightLog)).catch(() => {}); }, [weightLog]);

  // Level-up celebration: fires only on a genuine increase seen *after*
  // the initial load has settled, so restoring a returning user's real
  // (possibly higher) level from storage never falsely triggers it.
  useEffect(() => {
    const { level } = levelForTotalXp(totalXp);
    if (loadedRef.current && prevLevelRef.current !== null && level > prevLevelRef.current) {
      setLevelUpFlash({ from: prevLevelRef.current, to: level });
    }
    prevLevelRef.current = level;
  }, [totalXp]);

  // Android hardware back button: close whatever's on top before falling
  // back to tab navigation, and only exit from Home with nothing open.
  useEffect(() => {
    if (!CapApp) return;
    let handle;
    const onBack = () => {
      if (levelUpFlash) { setLevelUpFlash(null); return; }
      if (sessionActive) { setSessionActive(false); return; }
      if (scannerOpen) { setScannerOpen(false); return; }
      if (scaleOpen) { setScaleOpen(false); return; }
      if (searchOpen) { setSearchOpen(false); return; }
      if (recipesOpen) { setRecipesOpen(false); return; }
      if (summaryOpen) { setSummaryOpen(false); return; }
      if (achievementsOpen) { setAchievementsOpen(false); return; }
      if (settingsOpen) { setSettingsOpen(false); return; }
      if (tab !== "home") { setTab("home"); return; }
      CapApp.exitApp();
    };
    CapApp.addListener("backButton", onBack).then(h => { handle = h; });
    return () => { if (handle) handle.remove(); };
  }, [levelUpFlash, sessionActive, scannerOpen, scaleOpen, searchOpen, recipesOpen, summaryOpen, achievementsOpen, settingsOpen, tab]);

  const completeOnboarding = async (data) => {
    const p = { ...data, name: "Athlete", age: Number(data.age), height: Number(data.height), weight: Number(data.weight) };
    setProfile(p);
    setWorkoutPlan(buildWorkoutPlan(p));
    setNutrition(buildNutritionTargets(p));
    setMeals(buildMealPlan(p));
    setNutritionLog({ date: dateKey(), entries: [], water: 0 });
    setWeightLog([{ id: uid(), date: dateKey(), weightKg: p.weight }]);
    try { await storage.set("form:profile", JSON.stringify(p)); } catch (e) {}
    loadedRef.current = true;
  };

  // Logging a new weight both records a real trend point AND updates the
  // profile/nutrition targets to match — previously profile.weight was
  // frozen forever at whatever the user typed during onboarding, so meal
  // targets and load estimates would silently go stale.
  function logWeight(weightKg) {
    if (!Number.isFinite(weightKg) || weightKg < 30 || weightKg > 300) return;
    const today = dateKey();
    setWeightLog(log => {
      const existingIdx = log.findIndex(w => w.date === today);
      if (existingIdx >= 0) {
        const next = [...log];
        next[existingIdx] = { ...next[existingIdx], weightKg };
        return next;
      }
      return [...log, { id: uid(), date: today, weightKg }];
    });
    setProfile(p => {
      const next = { ...p, weight: weightKg };
      storage.set("form:profile", JSON.stringify(next)).catch(() => {});
      return next;
    });
    setNutrition(buildNutritionTargets({ ...profile, weight: weightKg }));
  }

  // ---- The ONE place XP is ever granted. Every award is a real,
  // reason-labeled, timestamped ledger entry — nothing here can be
  // triggered by simply re-rendering or refreshing, and an optional
  // dedupeKey blocks the same discrete achievement/quest/session from
  // paying out twice, even across app restarts (the ledger is persisted). ----
  function grantXp(amount, reason, dedupeKey = null) {
    if (amount <= 0) return;
    if (dedupeKey && xpLedger.some(e => e.dedupeKey === dedupeKey)) return;
    setXpLedger(l => [...l, { id: uid(), amount, reason, dedupeKey, at: Date.now() }]);
    setTotalXp(t => t + amount);
    setXpToast(amount);
    setTimeout(() => setXpToast(null), 2200);
  }

  const handleSessionFinish = (summary) => {
    setTodayResults(prev => ({ ...prev, ...summary.perExercise }));
    setLastSession(summary.perExercise);
    setPersonalBests(prev => {
      const next = { ...prev };
      Object.entries(summary.perExercise).forEach(([k, r]) => { if (r.isPR) next[k] = { reps: r.totalReps }; });
      return next;
    });
    setFormHistory(h => [...h.slice(-6), { d: `S${h.length + 1}`, v: summary.avgForm }]);

    // Smart progression: only bump next session's rep target for an
    // exercise that was actually earned (good form + all sets done);
    // never auto-increases on a weak or incomplete session.
    setWorkoutPlan(plan => plan.map(ex => {
      const r = summary.perExercise[ex.key];
      if (!r) return ex;
      const lastResult = { avgForm: r.avgForm, setsCompleted: r.sets.length, targetSets: ex.sets };
      return { ...ex, reps: suggestNextReps(ex.reps, lastResult, BASELINE_REPS[ex.key] || ex.reps) };
    }));

    // One real, audited XP grant for the whole session — the base amount
    // Stage 2/3 already computed from verified reps/form/PRs — tied to a
    // session-STABLE key (generated once when the session started, not
    // per-call) so a double-tap on "Continue" genuinely can't pay it twice.
    grantXp(summary.totalXp, "Workout completed", `session_${summary.sessionId}`);

    setActivityLog(log => ({
      ...log,
      workoutSessions: [...log.workoutSessions, {
        id: uid(), date: dateKey(), avgForm: summary.avgForm, totalReps: summary.totalReps, prCount: summary.prCount,
      }],
    }));
    setSessionActive(false);
    setTab("home");
  };

  // ---- Nutrition log: the single place entries are added/removed ----
  function logNutritionEntry(entry) {
    setNutritionLog(log => ({ ...log, entries: [...log.entries, { id: uid(), loggedAt: Date.now(), ...entry }] }));
    grantXp(8, "Logged a meal");
  }
  function removeNutritionEntry(id) {
    setNutritionLog(log => ({ ...log, entries: log.entries.filter(e => e.id !== id) }));
  }
  function addWater(deltaLiters) {
    setNutritionLog(log => ({ ...log, water: Math.max(0, Math.round((log.water + deltaLiters) * 100) / 100) }));
  }
  function toggleMealLogged(meal) {
    if (meal.logged) {
      setMeals(ms => ms.map(m => m.id === meal.id ? { ...m, logged: false } : m));
      removeNutritionEntry(meal.id);
    } else {
      setMeals(ms => ms.map(m => m.id === meal.id ? { ...m, logged: true } : m));
      // Idempotent guard: if this meal id is somehow already in the log
      // (e.g. a double-tap fired this handler twice before the button's
      // "logged" state visually updated), do not add a second entry.
      setNutritionLog(log => {
        if (log.entries.some(e => e.id === meal.id)) return log;
        return { ...log, entries: [...log.entries, { id: meal.id, name: meal.name, cals: meal.cals, protein: meal.protein, carbs: meal.carbs, fat: meal.fat, fiber: meal.fiber || 0, source: "planned", mealSlot: meal.tag, loggedAt: Date.now() }] };
      });
      // Dedupe key is scoped to today's date, not just the meal id, so
      // logging the same meal slot again tomorrow still earns XP normally —
      // only same-day repeats (double-taps, or toggling off/on to farm) are blocked.
      grantXp(10, "Logged a planned meal", `meallog_${meal.id}_${dateKey()}`);
    }
  }
  function replaceMeal(mealId) {
    setMeals(ms => ms.map(m => m.id === mealId ? { ...findReplacementMeal(m), logged: false } : m));
    removeNutritionEntry(mealId);
  }
  function logFoodEntry(entry) { logNutritionEntry(entry); setScannerOpen(false); setScaleOpen(false); }
  function addSavedMeal(data) { setSavedMeals(sm => [...sm, { id: uid(), ...data }]); }
  function logSavedMeal(sm) { logNutritionEntry({ name: sm.name, cals: sm.cals, protein: sm.protein, carbs: sm.carbs, fat: sm.fat, fiber: sm.fiber || 0, source: "saved-meal" }); }
  function deleteSavedMeal(id) { setSavedMeals(sm => sm.filter(m => m.id !== id)); }
  function toggleGroceryItem(key) { setGroceryChecked(gc => ({ ...gc, [key]: !gc[key] })); }
  function addCustomGroceryItem(name) { setGroceryCustom(gc => [...gc, { id: uid(), name, category: "Pantry" }]); }
  function removeGroceryItem(key) {
    if (!key.startsWith("custom_")) return;
    const id = key.slice(7);
    setGroceryCustom(gc => gc.filter(c => c.id !== id));
    setGroceryChecked(gc => { const { [key]: _, ...rest } = gc; return rest; });
  }
  function addIngredientsToGrocery(ingredients) {
    setGroceryCustom(gc => [...gc, ...ingredients.map(ing => {
      const food = findFood(ing.foodId);
      return { id: uid(), name: `${food.name} (${ing.grams}g)`, category: food.category };
    })]);
  }

  // ---- Live nutrition-by-date tracking, feeds streaks + weekly protein quest ----
  useEffect(() => {
    if (!loadedRef.current || !nutrition) return;
    const totals = roundNutrition(sumNutrition(nutritionLog.entries));
    const proteinHit = nutrition.protein > 0 && totals.protein >= nutrition.protein * 0.9;
    setActivityLog(log => {
      const existing = log.nutritionByDate[nutritionLog.date];
      if (existing && existing.cals === totals.cals && existing.protein === totals.protein && existing.proteinHit === proteinHit) return log;
      return { ...log, nutritionByDate: { ...log.nutritionByDate, [nutritionLog.date]: { cals: totals.cals, protein: totals.protein, proteinHit } } };
    });
  }, [nutritionLog, nutrition]);

  if (!profile) return <Onboarding onComplete={completeOnboarding} />;

  // ---- Derived progression state — computed fresh every render from the
  // ground truth above. This is the ONLY place these values are calculated;
  // every screen reads from here rather than keeping its own copy. ----
  const workoutStreak = computeStreak(activityLog.workoutSessions.map(s => s.date));
  const nutritionStreak = computeStreak(Object.entries(activityLog.nutritionByDate).filter(([, v]) => v.proteinHit).map(([d]) => d));
  const levelInfo = levelForTotalXp(totalXp);
  const rank = rankForLevel(levelInfo.level);
  const stats = computeBodyStats(activityLog, workoutStreak);
  const bodyQuest = bodyQuestProgress(stats);
  const milestone = bodyQuestMilestone(activityLog);
  const weeklyQuests = generateWeeklyQuests({ activityLog, nutrition, profile });
  const xpToday = xpEarnedSince(xpLedger, startOfTodayTs());
  const xpThisWeek = xpEarnedSince(xpLedger, startOfWeekTs());
  const recentXpEvents = xpLedger.slice(-5).reverse();
  const sessionVolumeTrend = activityLog.workoutSessions.slice(-8).map((s, i) => ({ d: `S${i + 1}`, v: s.totalReps }));

  const totalVerifiedReps = Object.values(todayResults).reduce((a, r) => a + r.totalReps, 0);
  const avgFormToday = Object.values(todayResults).length ? Math.round(Object.values(todayResults).reduce((a, r) => a + r.avgForm, 0) / Object.values(todayResults).length) : 0;
  const loggedTotals = roundNutrition(sumNutrition(nutritionLog.entries));
  const nutritionLoggedPct = Math.round((meals.filter(m => m.logged).length / Math.max(meals.length, 1)) * 100);
  const dayPct = Math.round((Object.keys(todayResults).length / Math.max(workoutPlan.length, 1)) * 60 + nutritionLoggedPct * 0.4);
  const grocery = buildGroceryList(meals, groceryCustom);
  const nutritionSummary = { logged: loggedTotals, targets: nutrition, mealsRemainingToday: meals.filter(m => !m.logged).length };
  const workoutDoneToday = workoutPlan.length > 0 && Object.keys(todayResults).length === workoutPlan.length;
  const dailyQuests = generateDailyQuests({
    workoutDoneToday,
    proteinPct: nutrition.protein > 0 ? loggedTotals.protein / nutrition.protein : 0,
    waterPct: nutrition.water > 0 ? nutritionLog.water / nutrition.water : 0,
    avgFormToday,
    allPlannedMealsLoggedToday: meals.length > 0 && meals.every(m => m.logged),
  });
  const aStats = achievementStats(activityLog, personalBests, workoutStreak, nutritionStreak);
  const achievementsStatus = ACHIEVEMENTS.map(a => ({
    ...a, unlocked: !!unlockedAchievements[a.id], unlockedAt: unlockedAchievements[a.id],
    progress: a.progress(aStats),
  }));
  const nearestIncompleteQuest = weeklyQuests.filter(q => q.progress < q.total).sort((a, b) => (a.total - a.progress) - (b.total - b.progress))[0];
  const homeCoachLine = getNutritionTip({ logged: loggedTotals, targets: nutrition, mealsRemainingToday: meals.filter(m => !m.logged).length })
    + (nearestIncompleteQuest ? ` Next up: ${nearestIncompleteQuest.label} (${nearestIncompleteQuest.progress}/${nearestIncompleteQuest.total}).` : "");

  // ---- Quest/achievement completion -> one-time XP grants, persisted so
  // a refresh or re-render can never pay the same one out twice. ----
  useEffect(() => {
    if (!loadedRef.current) return;
    const weekTag = dateKey(new Date(startOfWeekTs()));
    weeklyQuests.forEach(q => {
      if (q.progress >= q.total) {
        const key = `weekly_${q.id}_${weekTag}`;
        if (!awardedQuestIds[key]) {
          setAwardedQuestIds(a => ({ ...a, [key]: true }));
          grantXp(q.xp, `Weekly quest: ${q.label}`, key);
        }
      }
    });
    dailyQuests.forEach(q => {
      if (q.done) {
        const key = `daily_${q.id}_${dateKey()}`;
        if (!awardedQuestIds[key]) {
          setAwardedQuestIds(a => ({ ...a, [key]: true }));
          grantXp(q.xp, `Daily quest: ${q.label}`, key);
        }
      }
    });
    achievementsStatus.forEach(a => {
      if (!unlockedAchievements[a.id] && a.check(aStats)) {
        setUnlockedAchievements(u => ({ ...u, [a.id]: Date.now() }));
        grantXp(100, `Achievement: ${a.name}`, `ach_${a.id}`);
      }
    });
    // eslint-disable-next-line
  }, [activityLog, nutritionLog, meals, todayResults]);

  return (
    <div style={{ minHeight: "100vh", background: C.bg, maxWidth: 480, margin: "0 auto", position: "relative", fontFamily: "Inter, sans-serif", paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <OfflineBanner />

      {xpToast !== null && (
        <div style={{ position: "fixed", top: 18, left: "50%", transform: "translateX(-50%)", zIndex: 70, background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, color: "#04211D", fontWeight: 700, padding: "10px 18px", borderRadius: 999, fontFamily: "Space Grotesk, sans-serif", fontSize: 14, boxShadow: "0 8px 24px rgba(45,212,191,0.35)", display: "flex", alignItems: "center", gap: 6 }}>
          <Zap size={15} /> +{xpToast} XP
        </div>
      )}
      {levelUpFlash && <LevelUpOverlay from={levelUpFlash.from} to={levelUpFlash.to} rank={rankForLevel(levelUpFlash.to)} onDone={() => setLevelUpFlash(null)} />}

      {tab === "home" && (
        <HomeScreen profile={profile} workoutPlan={workoutPlan} todayResults={todayResults} nutrition={nutrition} meals={meals}
          loggedTotals={loggedTotals} water={nutritionLog.water} onAddWater={addWater}
          levelInfo={levelInfo} rank={rank} streak={workoutStreak} dailyQuests={dailyQuests} weeklyQuests={weeklyQuests} bodyQuest={bodyQuest} coachLine={homeCoachLine}
          onStartWorkout={() => { setSessionStartIndex(0); setSessionActive(true); }} onOpenSummary={() => setSummaryOpen(true)} />
      )}
      {tab === "train" && (
        <TrainScreen workoutPlan={workoutPlan} todayResults={todayResults} lastSession={lastSession}
          onStart={(idx) => { setSessionStartIndex(idx); setSessionActive(true); }} />
      )}
      {tab === "eat" && (
        <EatScreen
          nutrition={nutrition} meals={meals} loggedEntries={nutritionLog.entries} water={nutritionLog.water} savedMeals={savedMeals}
          onToggleMeal={toggleMealLogged} onReplaceMeal={replaceMeal} onRemoveEntry={removeNutritionEntry} onAddWater={addWater}
          onLogSavedMeal={logSavedMeal} onDeleteSavedMeal={deleteSavedMeal}
          onOpenScanner={() => setScannerOpen(true)} onOpenScale={() => setScaleOpen(true)} onOpenSearch={() => setSearchOpen(true)} onOpenRecipes={() => setRecipesOpen(true)}
          grocery={grocery} groceryChecked={groceryChecked} onToggleGroceryItem={toggleGroceryItem} onAddCustomGroceryItem={addCustomGroceryItem} onRemoveGroceryItem={removeGroceryItem}
        />
      )}
      {tab === "progress" && <ProgressScreen stats={stats} formHistory={formHistory} weightLog={weightLog} onLogWeight={logWeight} sessionVolumeTrend={sessionVolumeTrend} currentWeight={profile.weight} />}
      {tab === "profile" && (
        <ProfileScreen profile={profile} lastSession={lastSession} onOpenSettings={() => setSettingsOpen(true)} onOpenAchievements={() => setAchievementsOpen(true)} nutritionSummary={nutritionSummary}
          levelInfo={levelInfo} rank={rank} stats={stats} bodyQuest={bodyQuest} milestone={milestone} weeklyQuests={weeklyQuests}
          xpToday={xpToday} xpThisWeek={xpThisWeek} recentXpEvents={recentXpEvents} />
      )}

      <BottomNav tab={tab} setTab={setTab} />

      {sessionActive && (
        <WorkoutSessionScreen exercises={workoutPlan} startIndex={sessionStartIndex} personalBests={personalBests} bodyweight={profile.weight || 75}
          onFinish={handleSessionFinish} onExit={() => setSessionActive(false)} />
      )}
      {scannerOpen && <FoodScanner onClose={() => setScannerOpen(false)} onLog={logFoodEntry} onSearchFood={() => setSearchOpen(true)} onManualEntry={() => setScaleOpen(true)} />}
      {scaleOpen && <ScaleMode onClose={() => setScaleOpen(false)} onLog={logFoodEntry} onSaveMeal={addSavedMeal} />}
      {searchOpen && <SearchFoodScreen onClose={() => setSearchOpen(false)} onLogEntry={logNutritionEntry} />}
      {recipesOpen && <RecipesScreen onClose={() => setRecipesOpen(false)} onLogEntry={logNutritionEntry} onAddIngredientsToGrocery={addIngredientsToGrocery} />}
      {summaryOpen && (
        <DailySummary onClose={() => setSummaryOpen(false)} pct={Math.min(100, dayPct)} xp={xpToday}
          workoutDone={workoutDoneToday}
          reps={totalVerifiedReps} formScore={avgFormToday || stats.form} nutritionPct={nutritionLoggedPct}
          streak={workoutStreak} coachNote={homeCoachLine}
          weeklyQuestsDone={weeklyQuests.filter(q => q.progress >= q.total).length} weeklyQuestsTotal={weeklyQuests.length} />
      )}
      {settingsOpen && <SettingsScreen onClose={() => setSettingsOpen(false)} />}
      {achievementsOpen && <AchievementsScreen onClose={() => setAchievementsOpen(false)} achievementsStatus={achievementsStatus} />}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <FormApp />
    </ErrorBoundary>
  );
}
