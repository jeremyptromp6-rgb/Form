// PROGRESSION ENGINE
//
// Every gamification number in the app (level, rank, streak, Body Quest
// stage, quest progress, achievement status) is DERIVED here from two
// small pieces of persisted ground truth that App.jsx owns:
//
//   totalXp     — a single running total, only ever increased by awardXp()
//   activityLog — { workoutSessions: [...], nutritionByDate: {...} }
//   personalBests — per-exercise best verified rep count (existing, Stage 2)
//
// Nothing in this file is stored redundantly — level/rank/streak/Body
// Quest/quests/achievements are pure functions of that ground truth,
// recomputed on render. That's what "do not create duplicate or
// disconnected versions of the same data" (Stage 4 spec) means in
// practice: there is exactly one place `level` can be wrong, and it's
// levelForTotalXp() below.

/* ------------------------------- dates -------------------------------- */

export function dateKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
export function todayKey() { return dateKey(new Date()); }
export function startOfTodayTs() { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); }
export function startOfWeekTs() {
  const d = new Date();
  const day = d.getDay();
  const diffToMonday = day === 0 ? 6 : day - 1;
  d.setDate(d.getDate() - diffToMonday);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
function daysAgoKey(n) { const d = new Date(); d.setDate(d.getDate() - n); return dateKey(d); }

/* ------------------------------ XP ledger ------------------------------ */

export function xpEarnedSince(ledger, sinceTs) {
  return ledger.filter(e => e.at >= sinceTs).reduce((a, e) => a + e.amount, 0);
}

/* --------------------------- level + rank ------------------------------ */

// Gradually increasing requirement so early levels come quickly and later
// ones feel earned — not a flat "1000 XP per level" that never changes.
export function xpRequiredForLevel(level) {
  return 500 + (level - 1) * 60;
}

export function levelForTotalXp(totalXp) {
  let level = 1;
  let remaining = Math.max(0, totalXp);
  while (remaining >= xpRequiredForLevel(level)) {
    remaining -= xpRequiredForLevel(level);
    level += 1;
  }
  return { level, xpIntoLevel: Math.round(remaining), xpForNextLevel: xpRequiredForLevel(level) };
}

export const RANKS = [
  { name: "Rookie", minLevel: 1, description: "Just getting started — every verified session builds your foundation." },
  { name: "Starter", minLevel: 6, description: "Consistency is forming. Keep showing up." },
  { name: "Athlete", minLevel: 11, description: "Real training habits — your body is responding." },
  { name: "Iron", minLevel: 16, description: "Disciplined and strong. Few make it this far." },
  { name: "Elite", minLevel: 21, description: "Elite-level consistency and verified performance." },
  { name: "Master", minLevel: 26, description: "Mastery of your own training — an example to others." },
  { name: "Champion", minLevel: 31, description: "Sustained excellence at the top tier." },
];

export function rankForLevel(level) {
  let current = RANKS[0];
  for (const r of RANKS) if (level >= r.minLevel) current = r;
  return current;
}
export function nextRank(level) {
  return RANKS.find(r => r.minLevel > level) || null;
}

/* -------------------------------- streaks ------------------------------- */

// A day "counts" toward a streak based on the caller-supplied date set.
// Doesn't zero out the streak just because *today* hasn't happened yet —
// only a genuinely missed prior day breaks it. That's the "don't punish
// mid-day" behavior the spec asks for; true rest-day freezes are not
// implemented (see final report).
export function computeStreak(dateStrings) {
  const set = new Set(dateStrings);
  let streak = 0;
  let cursor = new Date();
  if (!set.has(dateKey(cursor))) cursor.setDate(cursor.getDate() - 1);
  while (set.has(dateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

/* ------------------------------ body stats ------------------------------ */

// Heuristic proxies built from real, stored behavior — not a clinical
// measurement. Each stat is documented so it's clear what actually moves it.
export function computeBodyStats(activityLog, workoutStreak) {
  const sessions = activityLog.workoutSessions || [];
  const recent20 = sessions.slice(-20);
  // No sessions yet -> 0, same honest "nothing recorded" convention as
  // `consistency` below, rather than a flattering placeholder average.
  const avgFormRecent = recent20.length ? recent20.reduce((a, s) => a + s.avgForm, 0) / recent20.length : 0;
  const totalRepsAllTime = sessions.reduce((a, s) => a + s.totalReps, 0);
  // Real PR *events* from session history — NOT personalBests' current
  // values. personalBests holds seeded starting baselines even for a
  // brand-new account with zero real workouts, so summing it directly
  // would inflate strength before the user has done anything real.
  const totalPRs = sessions.reduce((a, s) => a + (s.prCount || 0), 0);

  // Form: directly the recent verified average — the most literal, real signal available.
  const form = Math.round(Math.max(0, Math.min(100, avgFormRecent)));
  // Consistency: sessions in the last 14 days relative to a "good" cadence of 8.
  const last14 = sessions.filter(s => s.date >= daysAgoKey(13)).length;
  const consistency = Math.round(Math.max(0, Math.min(100, (last14 / 8) * 100)));
  // Strength/Muscle/Endurance/Mobility: scaled off cumulative verified rep
  // volume and streak — crude but real (never a static/hardcoded number).
  const volumeScore = Math.min(100, Math.round(totalRepsAllTime / 6));
  const strength = Math.round(Math.max(0, Math.min(100, volumeScore * 0.7 + Math.min(30, totalPRs * 10))));
  const muscle = Math.round(Math.max(0, Math.min(100, volumeScore * 0.8 + form * 0.15)));
  const endurance = Math.round(Math.max(0, Math.min(100, volumeScore * 0.6 + Math.min(30, workoutStreak * 3))));
  const mobility = Math.round(Math.max(0, Math.min(100, form * 0.6 + volumeScore * 0.3)));

  return { strength, muscle, endurance, mobility, form, consistency };
}

/* ------------------------------ body quest ------------------------------- */

export const BODY_QUEST_STAGES = [
  { name: "Starter", minAvg: 0 },
  { name: "Foundation", minAvg: 38 },
  { name: "Builder", minAvg: 55 },
  { name: "Athlete", minAvg: 70 },
  { name: "Elite", minAvg: 85 },
];

export function bodyQuestProgress(stats) {
  const vals = Object.values(stats);
  const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
  let idx = 0;
  for (let i = 0; i < BODY_QUEST_STAGES.length; i++) if (avg >= BODY_QUEST_STAGES[i].minAvg) idx = i;
  const cur = BODY_QUEST_STAGES[idx];
  const next = BODY_QUEST_STAGES[idx + 1];
  const pct = next ? Math.round(((avg - cur.minAvg) / (next.minAvg - cur.minAvg)) * 100) : 100;
  return { stageIndex: idx, stageName: cur.name, nextStageName: next ? next.name : null, avg: Math.round(avg), pct: Math.max(0, Math.min(100, pct)) };
}

// The single "next milestone" shown on the Body Quest screen — tied to a
// real, trackable count (sessions in the last 14 days with avgForm >= 85),
// not a static line of copy.
export function bodyQuestMilestone(activityLog) {
  const need = 6;
  const have = (activityLog.workoutSessions || []).filter(s => s.date >= daysAgoKey(13) && s.avgForm >= 85).length;
  return { label: "Complete 6 workouts with average form above 85", have: Math.min(need, have), need };
}

/* ------------------------------ quests ---------------------------------- */

export function generateWeeklyQuests({ activityLog, nutrition, profile }) {
  const weekStartKey = dateKey(new Date(startOfWeekTs()));
  const sessionsThisWeek = (activityLog.workoutSessions || []).filter(s => s.date >= weekStartKey);
  const proteinDaysThisWeek = Object.entries(activityLog.nutritionByDate || {})
    .filter(([d, v]) => d >= weekStartKey && v.proteinHit).length;
  const prsThisWeek = sessionsThisWeek.reduce((a, s) => a + (s.prCount || 0), 0);
  const targetWorkouts = Math.max(2, Math.min(6, Number(profile.daysPerWeek) || 4));

  return [
    { id: "form_master", label: "Complete 3 workouts with average form above 90", total: 3, progress: Math.min(3, sessionsThisWeek.filter(s => s.avgForm >= 90).length), xp: 150 },
    { id: "consistency", label: `Complete ${targetWorkouts} planned workouts`, total: targetWorkouts, progress: Math.min(targetWorkouts, sessionsThisWeek.length), xp: 120 },
    { id: "protein_target", label: "Hit protein target 5 days", total: 5, progress: Math.min(5, proteinDaysThisWeek), xp: 100 },
    { id: "personal_best", label: "Improve one exercise performance", total: 1, progress: prsThisWeek > 0 ? 1 : 0, xp: 80 },
  ];
}

export function generateDailyQuests({ workoutDoneToday, proteinPct, waterPct, avgFormToday, allPlannedMealsLoggedToday }) {
  return [
    { id: "d_workout", label: "Complete today's workout", done: workoutDoneToday, xp: 40 },
    { id: "d_protein", label: "Hit protein target", done: proteinPct >= 1, xp: 25 },
    { id: "d_water", label: "Drink today's water target", done: waterPct >= 1, xp: 15 },
    { id: "d_form", label: "Achieve a strong form score (85+)", done: avgFormToday >= 85, xp: 25 },
    { id: "d_meals", label: "Log all of today's planned meals", done: allPlannedMealsLoggedToday, xp: 20 },
  ];
}

/* ---------------------------- achievements -------------------------------- */

export const ACHIEVEMENTS = [
  { id: "first_rep", name: "First Rep", desc: "Complete your first verified rep.",
    check: s => s.totalRepsAllTime >= 1, progress: s => Math.min(1, s.totalRepsAllTime) },
  { id: "first_workout", name: "First Workout", desc: "Complete your first workout.",
    check: s => s.totalWorkoutsAllTime >= 1, progress: s => Math.min(1, s.totalWorkoutsAllTime) },
  { id: "form_master", name: "Form Master", desc: "Reach a 90+ average form score in a session.",
    check: s => s.bestSessionAvgForm >= 90, progress: s => Math.min(1, s.bestSessionAvgForm / 90) },
  { id: "consistent", name: "Consistent", desc: "Maintain a 7-day workout streak.",
    check: s => s.workoutStreak >= 7, progress: s => Math.min(1, s.workoutStreak / 7) },
  { id: "pr_breaker", name: "PR Breaker", desc: "Set a personal record on any exercise.",
    check: s => s.totalPRsEver >= 1, progress: s => Math.min(1, s.totalPRsEver) },
  { id: "iron_mind", name: "Iron Mind", desc: "Complete a full planned workout, every set.",
    check: s => s.totalWorkoutsAllTime >= 1, progress: s => Math.min(1, s.totalWorkoutsAllTime) },
  { id: "nutrition_on_track", name: "Nutrition on Track", desc: "Hit your protein target 5 days in a row.",
    check: s => s.nutritionStreak >= 5, progress: s => Math.min(1, s.nutritionStreak / 5) },
];

export function achievementStats(activityLog, personalBests, workoutStreak, nutritionStreak) {
  const sessions = activityLog.workoutSessions || [];
  return {
    totalRepsAllTime: sessions.reduce((a, s) => a + s.totalReps, 0),
    totalWorkoutsAllTime: sessions.length,
    bestSessionAvgForm: sessions.reduce((a, s) => Math.max(a, s.avgForm), 0),
    totalPRsEver: sessions.reduce((a, s) => a + (s.prCount || 0), 0),
    workoutStreak,
    nutritionStreak,
  };
}

/* ---------------------------- smart progression ---------------------------- */

// Only progresses reps when the previous session actually earned it —
// good form AND all sets completed. Poor form maintains or gently backs
// off; nothing here increases load automatically just because a session
// happened. Capped so a hot streak can't runaway past a sane ceiling.
export function suggestNextReps(currentTarget, lastResult, baselineTarget) {
  if (!lastResult) return currentTarget;
  const ceiling = Math.round(baselineTarget * 1.6);
  if (lastResult.avgForm >= 85 && lastResult.setsCompleted >= lastResult.targetSets) {
    return Math.min(ceiling, currentTarget + 1);
  }
  if (lastResult.avgForm < 68) {
    return Math.max(baselineTarget, currentTarget - 1);
  }
  return currentTarget;
}
