// FORM — secure backend (AI Coach + Food Recognition)
//
// This is the ONLY place the Anthropic API key exists. The Android app
// never sees it (see src/coach-api.js and src/foodRecognition.js on the
// client). Deploy this somewhere with HTTPS (Render, Fly.io, Railway, a
// small VPS, etc.), put ANTHROPIC_API_KEY in that host's environment/
// secret manager (never commit it), and point the app's
// VITE_COACH_API_URL / VITE_FOOD_RECOGNITION_API_URL at this server's
// public URLs.
//
// Neither feature is required for the app to work. Without this deployed:
//   - AI Coach falls back to a locally-computed summary (src/App.jsx).
//   - Food scanning falls back to the clearly-labeled dev mock provider
//     (src/foodRecognition.js) — it never pretends to be real recognition.

import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import "dotenv/config";

const app = express();
// 10mb because /api/food-recognition accepts a base64-encoded photo —
// /api/coach's tiny JSON payload is unaffected by the higher limit.
app.use(express.json({ limit: "10mb" }));

// Lock this down to your actual app origin(s) in production. For a
// packaged Android app there is no browser "origin" header on native
// requests, so this mainly matters if you also serve a web build.
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));

app.use(["/api/coach", "/api/food-recognition"], rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false }));

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
// Check https://docs.claude.com for current model names/pricing before
// deploying. Both endpoints below need a model with vision support for
// food-recognition to work — check the docs for which current models
// support image input.
const MODEL = process.env.ANTHROPIC_MODEL || "claude-haiku-4-5-20251001";

app.get("/healthz", (_req, res) => res.json({ ok: true }));

/* ------------------------------- AI Coach ------------------------------- */

app.post("/api/coach", async (req, res) => {
  if (!ANTHROPIC_API_KEY) {
    return res.status(503).json({ error: "coach-not-configured" });
  }
  try {
    const { profile = {}, lastSession = {}, level, rank, bodyQuest, weeklyQuests = [], nutrition } = req.body || {};
    const prompt = buildCoachPrompt(profile, lastSession, level, rank, bodyQuest, weeklyQuests, nutrition);

    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: 220, messages: [{ role: "user", content: prompt }] }),
    });

    if (!upstream.ok) {
      console.error("Anthropic API error:", upstream.status, await upstream.text().catch(() => ""));
      return res.status(502).json({ error: "upstream-error" });
    }

    const data = await upstream.json();
    const message = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join(" ").trim();
    res.json({ message: message || null });
  } catch (err) {
    console.error("Coach endpoint error:", err);
    res.status(500).json({ error: "server-error" });
  }
});

function buildCoachPrompt(profile, lastSession, level, rank, bodyQuest, weeklyQuests, nutrition) {
  const keys = Object.keys(lastSession || {});
  const sessionLine = keys.length
    ? keys.map((k) => `${lastSession[k].totalReps} verified ${k} reps at ${lastSession[k].avgForm} avg form`).join("; ")
    : "no verified session yet";
  const lines = [
    "You are a concise, encouraging coach inside a mobile fitness + nutrition app called FORM.",
    `Athlete goal: ${profile.goal || "unspecified"}. Level: ${profile.level || "unspecified"}. Trains ${profile.daysPerWeek || "?"} days/week.`,
    `Most recent camera-verified training session: ${sessionLine}.`,
    `Current progression: Level ${level ?? "?"}, Rank ${rank || "?"}.`,
  ];
  if (bodyQuest) {
    lines.push(`Body Quest stage: ${bodyQuest.stageName} (${bodyQuest.avg}/100 average across strength/muscle/endurance/mobility/form/consistency).`);
  }
  if (Array.isArray(weeklyQuests) && weeklyQuests.length) {
    const incomplete = weeklyQuests.filter((q) => q.progress < q.total);
    lines.push(incomplete.length
      ? `Weekly quests in progress: ${incomplete.map((q) => `${q.label} (${q.progress}/${q.total})`).join("; ")}.`
      : "All weekly quests are already complete.");
  }
  if (nutrition && nutrition.targets) {
    const { logged = {}, targets = {}, mealsRemainingToday } = nutrition;
    lines.push(
      `Today's nutrition so far: ${Math.round(logged.cals || 0)}/${targets.calories} kcal, ${Math.round(logged.protein || 0)}/${targets.protein}g protein. ${mealsRemainingToday ?? "?"} planned meals still remaining today.`
    );
  }
  lines.push(
    "In 2-3 short sentences, give ONE practical, specific recommendation covering training and/or nutrition — whichever is more useful right now, optionally nudging toward the nearest incomplete quest. Only suggest increasing training load if recent form has genuinely been strong; if form has been inconsistent or low, recommend maintaining rather than progressing. Never suggest unsafe calorie restriction, skipping meals, exercising through pain, or overtraining. Do not diagnose injuries or give medical advice. Be encouraging and concrete."
  );
  return lines.join("\n");
}

/* --------------------------- Food Recognition ---------------------------- */
// Sends the captured photo to a vision-capable Claude model, constrained to
// matching against the app's own food database (knownFoods) rather than
// inventing nutrition numbers itself — actual nutrition math still happens
// entirely client-side from src/foodDatabase.js. If the model isn't
// confident about something, it's told to say so rather than guess.

app.post("/api/food-recognition", async (req, res) => {
  if (!ANTHROPIC_API_KEY) {
    return res.status(503).json({ error: "recognition-not-configured" });
  }
  try {
    const { image, knownFoods = [] } = req.body || {};
    if (!image || typeof image !== "string") {
      return res.status(400).json({ error: "missing-image" });
    }
    const match = image.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!match) return res.status(400).json({ error: "invalid-image-format" });
    const [, mediaType, base64Data] = match;

    const prompt = buildRecognitionPrompt(knownFoods);
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 500,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: base64Data } },
            { type: "text", text: prompt },
          ],
        }],
      }),
    });

    if (!upstream.ok) {
      console.error("Anthropic API error:", upstream.status, await upstream.text().catch(() => ""));
      return res.status(502).json({ error: "upstream-error" });
    }

    const data = await upstream.json();
    const text = (data.content || []).map((b) => (b.type === "text" ? b.text : "")).join("").trim();
    const items = parseRecognitionResponse(text, knownFoods);
    res.json({ items });
  } catch (err) {
    console.error("Food recognition endpoint error:", err);
    res.status(500).json({ error: "server-error" });
  }
});

function buildRecognitionPrompt(knownFoods) {
  const list = knownFoods.map((f) => `${f.id}: ${f.name}`).join("\n");
  return [
    "Identify which of the following known foods (if any) are visible in this photo of a meal.",
    "Known foods (id: name):",
    list || "(none provided)",
    "",
    'Respond with ONLY a JSON array, no other text, no markdown fences. Each element: {"foodId": "<id from the list above>", "confidence": <0 to 1>}.',
    "Only include foods you can actually see with reasonable confidence. If you don't recognize any of the known foods in the photo, respond with an empty array [].",
    "Do not invent foods that aren't in the known list, and do not estimate exact nutrition — only identify which known foods are present.",
  ].join("\n");
}

function parseRecognitionResponse(text, knownFoods) {
  try {
    const jsonMatch = text.match(/\[[\s\S]*\]/);
    const parsed = JSON.parse(jsonMatch ? jsonMatch[0] : text);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .map((raw) => {
        const food = knownFoods.find((f) => f.id === raw.foodId);
        if (!food) return null; // never trust an id the client's database doesn't actually have
        const confidence = Math.max(0, Math.min(1, Number(raw.confidence) || 0));
        const alternatives = knownFoods.filter((f) => f.id !== food.id).slice(0, 2).map((f) => ({ foodId: f.id, name: f.name }));
        return { foodId: food.id, name: food.name, confidence, estimatedGrams: null, alternatives };
      })
      .filter(Boolean);
  } catch (e) {
    console.error("Failed to parse recognition response:", text);
    return [];
  }
}

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => {
  console.log(`FORM backend listening on :${PORT}`);
  if (!ANTHROPIC_API_KEY) {
    console.warn("ANTHROPIC_API_KEY is not set — /api/coach and /api/food-recognition will return 503 until it is.");
  }
});
