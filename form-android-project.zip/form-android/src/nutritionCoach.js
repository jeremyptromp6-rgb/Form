// Local, fully rule-based nutrition guidance. No network required, so
// this is what's shown instantly and what the AI Coach panel falls back
// to if no backend is configured or reachable. Deliberately conservative:
// never suggests going under a safe calorie floor, never frames anything
// as "you failed today", and reframes a skipped/overshot day as
// recalculating forward rather than "compensating" for it.

const SAFE_MIN_CALORIES = 1200;

export function computeNutritionScore(logged, targets) {
  if (!targets || !targets.calories) return 0;
  const calRatio = logged.cals / targets.calories;
  const proteinRatio = targets.protein ? Math.min(1, logged.protein / targets.protein) : 0;
  // Calorie score peaks at exactly on-target and falls off in both directions.
  const calScore = Math.max(0, 1 - Math.abs(1 - calRatio));
  const score = calScore * 0.5 + proteinRatio * 0.5;
  return Math.round(Math.max(0, Math.min(1, score)) * 100);
}

export function getNutritionTip({ logged, targets, mealsRemainingToday }) {
  if (!targets || !targets.calories) {
    return "Complete onboarding to get personalized nutrition targets.";
  }
  if (targets.calories < SAFE_MIN_CALORIES) {
    return "Your calorie target looks unusually low for general guidance — worth reviewing with a doctor or dietitian.";
  }

  const remainingCals = Math.max(0, targets.calories - logged.cals);
  const remainingProtein = Math.max(0, targets.protein - logged.protein);
  const calPct = logged.cals / targets.calories;
  const proteinPct = targets.protein ? logged.protein / targets.protein : 1;

  if (logged.cals === 0) {
    return "Nothing logged yet today — logging breakfast early makes it a lot easier to land your targets by dinner.";
  }
  if (calPct >= 1.08) {
    return "You're a bit over today's calorie target. No need to under-eat tomorrow to compensate — just aim for your normal targets next time.";
  }
  if (proteinPct < 0.6 && remainingCals > 200) {
    return `You're at ${Math.round(proteinPct * 100)}% of today's protein with ${remainingCals} kcal left — a protein-forward option (Greek yogurt, chicken, tofu) would help close the gap.`;
  }
  if (remainingCals > 0 && remainingCals < 400 && mealsRemainingToday > 0) {
    return `About ${remainingCals} kcal left today — a lighter meal or snack fits best from here rather than a full plate.`;
  }
  if (remainingCals <= 0) {
    return "You've hit today's calorie target. Nice work staying consistent.";
  }
  return `On track — ${Math.round(calPct * 100)}% of calories and ${Math.round(proteinPct * 100)}% of protein logged so far today.`;
}

// "Smart" meal replacement: given a target calorie/protein pair, ranks
// candidate meals by closeness rather than swapping in something random,
// per the "stay reasonably close to the original nutrition target" rule.
export function scoreMealCloseness(meal, targetCals, targetProtein) {
  const calDiff = Math.abs(meal.cals - targetCals) / Math.max(targetCals, 1);
  const proteinDiff = Math.abs(meal.protein - targetProtein) / Math.max(targetProtein, 1);
  return calDiff * 0.6 + proteinDiff * 0.4; // lower is closer
}
