// FOOD DATABASE
// Every nutrition number in the app flows through this file. No screen is
// allowed to hardcode calories/macros for a named food — they all call
// scaleNutrition()/sumNutrition() against entries here. That's what makes
// "if the base food is stored per 100g, nutrition = per100 * grams/100"
// actually true everywhere instead of just in one screen.
//
// `source` is intentionally honest: these are typical reference values
// (the kind found on standard nutrition-fact panels), not a live database
// lookup or a verified USDA API call. Real product barcodes/live lookups
// would replace this file's role without changing anything that calls it.

export const NUTRITION_SOURCE_LABEL = "Built-in nutrition reference (typical values — not a live database lookup)";

export const CATEGORIES = ["Protein", "Carbohydrates", "Produce", "Dairy", "Pantry"];

export const FOOD_DATABASE = [
  { id: "chicken_breast", name: "Chicken Breast", category: "Protein", defaultServingGrams: 150,
    per100: { cals: 165, protein: 31, carbs: 0, fat: 3.6, fiber: 0 } },
  { id: "turkey_breast", name: "Turkey Breast", category: "Protein", defaultServingGrams: 130,
    per100: { cals: 135, protein: 30, carbs: 0, fat: 1, fiber: 0 } },
  { id: "salmon", name: "Salmon", category: "Protein", defaultServingGrams: 150,
    per100: { cals: 208, protein: 20, carbs: 0, fat: 13, fiber: 0 } },
  { id: "eggs", name: "Eggs (whole)", category: "Protein", defaultServingGrams: 100,
    per100: { cals: 143, protein: 13, carbs: 1.1, fat: 9.5, fiber: 0 } },
  { id: "tofu", name: "Tofu (firm)", category: "Protein", defaultServingGrams: 150,
    per100: { cals: 76, protein: 8, carbs: 1.9, fat: 4.8, fiber: 0.3 } },
  { id: "protein_powder", name: "Whey Protein Powder", category: "Protein", defaultServingGrams: 32,
    per100: { cals: 380, protein: 78, carbs: 8, fat: 5, fiber: 1 } },
  { id: "greek_yogurt", name: "Greek Yogurt", category: "Dairy", defaultServingGrams: 200,
    per100: { cals: 59, protein: 10, carbs: 3.6, fat: 0.4, fiber: 0 } },
  { id: "white_rice", name: "White Rice (cooked)", category: "Carbohydrates", defaultServingGrams: 180,
    per100: { cals: 130, protein: 2.7, carbs: 28, fat: 0.3, fiber: 0.4 } },
  { id: "quinoa", name: "Quinoa (cooked)", category: "Carbohydrates", defaultServingGrams: 150,
    per100: { cals: 120, protein: 4.4, carbs: 21, fat: 1.9, fiber: 2.8 } },
  { id: "sweet_potato", name: "Sweet Potato", category: "Carbohydrates", defaultServingGrams: 150,
    per100: { cals: 86, protein: 1.6, carbs: 20, fat: 0.1, fiber: 3 } },
  { id: "oats", name: "Rolled Oats (dry)", category: "Carbohydrates", defaultServingGrams: 50,
    per100: { cals: 389, protein: 16.9, carbs: 66, fat: 6.9, fiber: 10.6 } },
  { id: "sourdough", name: "Sourdough Bread", category: "Carbohydrates", defaultServingGrams: 60,
    per100: { cals: 289, protein: 11, carbs: 56, fat: 1.8, fiber: 2.5 } },
  { id: "broccoli", name: "Broccoli", category: "Produce", defaultServingGrams: 100,
    per100: { cals: 34, protein: 2.8, carbs: 7, fat: 0.4, fiber: 2.6 } },
  { id: "spinach", name: "Spinach", category: "Produce", defaultServingGrams: 60,
    per100: { cals: 23, protein: 2.9, carbs: 3.6, fat: 0.4, fiber: 2.2 } },
  { id: "asparagus", name: "Asparagus", category: "Produce", defaultServingGrams: 100,
    per100: { cals: 20, protein: 2.2, carbs: 3.9, fat: 0.1, fiber: 2.1 } },
  { id: "avocado", name: "Avocado", category: "Produce", defaultServingGrams: 100,
    per100: { cals: 160, protein: 2, carbs: 8.5, fat: 14.7, fiber: 6.7 } },
  { id: "banana", name: "Banana", category: "Produce", defaultServingGrams: 118,
    per100: { cals: 89, protein: 1.1, carbs: 23, fat: 0.3, fiber: 2.6 } },
  { id: "olive_oil", name: "Olive Oil", category: "Pantry", defaultServingGrams: 14,
    per100: { cals: 884, protein: 0, carbs: 0, fat: 100, fiber: 0 } },
];

export function findFood(id) {
  return FOOD_DATABASE.find(f => f.id === id) || null;
}

export function searchFoods(query) {
  const q = (query || "").trim().toLowerCase();
  if (!q) return FOOD_DATABASE;
  return FOOD_DATABASE.filter(f => f.name.toLowerCase().includes(q));
}

// The one and only place per-100g -> per-serving math happens.
export function scaleNutrition(per100, grams) {
  const f = (grams || 0) / 100;
  return {
    cals: per100.cals * f,
    protein: per100.protein * f,
    carbs: per100.carbs * f,
    fat: per100.fat * f,
    fiber: (per100.fiber || 0) * f,
  };
}

export function sumNutrition(list) {
  return list.reduce(
    (a, n) => ({
      cals: a.cals + (n.cals || 0),
      protein: a.protein + (n.protein || 0),
      carbs: a.carbs + (n.carbs || 0),
      fat: a.fat + (n.fat || 0),
      fiber: a.fiber + (n.fiber || 0),
    }),
    { cals: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
  );
}

export function roundNutrition(n) {
  return {
    cals: Math.round(n.cals), protein: Math.round(n.protein),
    carbs: Math.round(n.carbs), fat: Math.round(n.fat), fiber: Math.round(n.fiber || 0),
  };
}

// A "MealIngredient" is { foodId, grams }. This turns that into totals by
// looking the food up in the database every time — never cached/duplicated
// into a hardcoded macro count on the meal itself.
export function nutritionForIngredients(ingredients) {
  const parts = ingredients.map(ing => {
    const food = findFood(ing.foodId);
    if (!food) return { cals: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };
    return scaleNutrition(food.per100, ing.grams);
  });
  return roundNutrition(sumNutrition(parts));
}
