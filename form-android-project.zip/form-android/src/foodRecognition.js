// FOOD RECOGNITION PROVIDER
//
// This is the abstraction the spec asks for: a swappable "what's in this
// photo" service. There are two implementations behind the same
// `recognizeFood(imageDataUrl)` function:
//
//   - Mock provider (always available): picks a plausible plate of foods
//     from the built-in database. This is a DEVELOPMENT FALLBACK ONLY —
//     it never claims to have looked at the actual photo, and every
//     result it returns is tagged provider: "mock" so the UI can (and
//     does, see FoodScanner) show a visible "DEV MOCK" badge instead of
//     presenting it as real recognition.
//
//   - Remote provider: posts the captured photo to this app's own secure
//     backend (server/index.js -> /api/food-recognition), which forwards
//     it to a real vision-capable model server-side. The Android app
//     never holds an API key — same pattern as coach-api.js. Only used
//     if VITE_FOOD_RECOGNITION_API_URL is set; if that request fails for
//     any reason (offline, backend not deployed, timeout), this silently
//     falls back to the mock provider rather than blocking the user —
//     but the UI is told which one actually answered, so it can label it
//     correctly either way.
//
// Both paths return the same shape:
//   { provider: "mock" | "remote",
//     items: [{ foodId, name, confidence, estimatedGrams, alternatives: [{foodId,name}] }] }

import { FOOD_DATABASE, findFood } from "./foodDatabase";

const ENDPOINT = import.meta.env.VITE_FOOD_RECOGNITION_API_URL || "";

export const RECOGNITION_LABELS = {
  mock: "DEV MOCK — not real recognition",
  remote: "AI ESTIMATED",
};

const MOCK_SCENES = [
  ["chicken_breast", "white_rice", "broccoli"],
  ["eggs", "sourdough", "avocado"],
  ["salmon", "quinoa", "asparagus"],
  ["turkey_breast", "sweet_potato", "spinach"],
  ["greek_yogurt", "banana", "oats"],
];

function alternativesFor(food) {
  return FOOD_DATABASE
    .filter(f => f.category === food.category && f.id !== food.id)
    .slice(0, 2)
    .map(f => ({ foodId: f.id, name: f.name }));
}

async function mockRecognize() {
  // Simulated latency so the "Analyzing food…" UI state gets exercised
  // the same way a real network call would, rather than resolving instantly.
  await new Promise(r => setTimeout(r, 1400 + Math.random() * 600));
  const scene = MOCK_SCENES[Math.floor(Math.random() * MOCK_SCENES.length)];
  const items = scene.map(id => {
    const food = findFood(id);
    return {
      foodId: id,
      name: food.name,
      confidence: 0.68 + Math.random() * 0.27,
      estimatedGrams: food.defaultServingGrams,
      alternatives: alternativesFor(food),
    };
  });
  return { provider: "mock", items };
}

async function remoteRecognize(imageDataUrl) {
  if (!ENDPOINT) return null;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image: imageDataUrl,
        // The backend matches model output against this list rather than
        // inventing nutrition numbers itself — see server/index.js.
        knownFoods: FOOD_DATABASE.map(f => ({ id: f.id, name: f.name })),
      }),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) return null;
    const data = await res.json();
    if (!data || !Array.isArray(data.items)) return null;
    return { provider: "remote", items: data.items };
  } catch (e) {
    return null;
  }
}

export async function recognizeFood(imageDataUrl) {
  const remote = await remoteRecognize(imageDataUrl);
  if (remote) return remote;
  return mockRecognize();
}
