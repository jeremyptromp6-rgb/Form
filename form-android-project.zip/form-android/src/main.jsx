import React from "react";
import ReactDOM from "react-dom/client";
import { SplashScreen } from "@capacitor/splash-screen";
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Hide the native splash screen once React has mounted and painted, so the
// user never sees a blank white frame between the splash and the UI.
requestAnimationFrame(() => {
  SplashScreen.hide().catch(() => {});
});
