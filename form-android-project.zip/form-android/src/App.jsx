import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, RadarChart, PolarGrid, PolarAngleAxis, Radar,
} from "recharts";
import {
  Home as HomeIcon, Dumbbell, UtensilsCrossed, TrendingUp, User, Flame,
  Camera, X, Check, AlertTriangle, ChevronLeft, Plus, Minus,
  Droplets, Trophy, Target, Scale, Sparkles, Play, Info,
  Zap, Award, Lock, ArrowRight, Loader2, ScanLine, Pause, Square, Timer,
  ShieldCheck, WifiOff, Settings as SettingsIcon, RefreshCw, ExternalLink,
} from "lucide-react";
import { storage } from "./storage";
import { useOnlineStatus } from "./network";
import { fetchCoachMessage } from "./coach-api";
// @capacitor/app ships a web implementation too, so this static import is
// safe both in the native Android build and in `npm run dev` in a browser.
import { App as CapApp } from "@capacitor/app";
// capacitor-native-settings also ships a web fallback (no-ops with a
// console warning on plain web); on Android it opens the OS "App info"
// screen for this app so the user can flip the camera permission.
import { NativeSettings, AndroidSettings } from "capacitor-native-settings";

/* ------------------------------------------------------------------------
   ERROR BOUNDARY
   Catches render-time errors anywhere in the app and shows a recoverable
   screen instead of a blank/crashed WebView.
   ------------------------------------------------------------------------ */
class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error, info) { console.error("FORM crashed:", error, info); }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: "100vh", background: "#0B0F10", color: "#EAF2F1", display: "flex",
          flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14,
          padding: 30, textAlign: "center", fontFamily: "Inter, sans-serif",
        }}>
          <AlertTriangle size={32} color="#FBBF24" />
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", margin: 0 }}>Something went wrong</h2>
          <p style={{ color: "#8CA1A0", fontSize: 13.5, maxWidth: 280, margin: 0 }}>
            FORM hit an unexpected error. Your data is safe — reloading usually fixes this.
          </p>
          <button onClick={() => window.location.reload()} style={{
            marginTop: 6, background: "#2DD4BF", border: "none", color: "#04211D",
            padding: "12px 22px", borderRadius: 12, fontWeight: 700,
          }}>Reload FORM</button>
        </div>
      );
    }
    return this.props.children;
  }
}

function OfflineBanner() {
  const online = useOnlineStatus();
  if (online) return null;
  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, zIndex: 80, maxWidth: 480, margin: "0 auto",
      background: "#3B2E12", borderBottom: "1px solid #6B4E1A", color: "#FBBF24",
      fontSize: 12, fontWeight: 600, padding: "8px 14px", display: "flex", alignItems: "center",
      justifyContent: "center", gap: 6, fontFamily: "Inter, sans-serif",
      paddingTop: "calc(8px + env(safe-area-inset-top, 0px))",
    }}>
      <WifiOff size={13} /> You're offline — AI Coach and food scan sync are unavailable
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* DESIGN TOKENS                                                          */
/* ---------------------------------------------------------------------- */
const C = {
  bg: "#0B0F10",
  bg2: "#10161A",
  card: "#141B1F",
  cardBorder: "#1F2A2E",
  teal: "#2DD4BF",
  tealDim: "#134E4A",
  purple: "#A78BFA",
  purpleDim: "#3B2E5C",
  green: "#4ADE80",
  amber: "#FBBF24",
  red: "#F87171",
  text: "#EAF2F1",
  sub: "#8CA1A0",
  faint: "#4E6362",
};

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap');`;

/* ========================================================================
   POSE PROVIDER
   Real on-device pose estimation via TensorFlow.js + MoveNet, loaded lazily
   from CDN. Runs entirely client-side in the browser — no camera frames are
   ever sent to a server or to an LLM. This is the only layer that touches
   raw video; everything downstream works purely off (x,y,score) keypoints.
   ======================================================================== */
const TFJS_URL = "https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.20.0/dist/tf.min.js";
const POSE_DETECTION_URL = "https://cdn.jsdelivr.net/npm/@tensorflow-models/pose-detection@2.1.3/dist/pose-detection.min.js";

function loadScriptOnce(src) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[data-src="${src}"]`)) { resolve(); return; }
    const s = document.createElement("script");
    s.src = src; s.async = true; s.dataset.src = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("load-failed"));
    document.body.appendChild(s);
  });
}

let poseDepsPromise = null;
function ensurePoseDependencies() {
  if (!poseDepsPromise) {
    poseDepsPromise = (async () => {
      await loadScriptOnce(TFJS_URL);
      await loadScriptOnce(POSE_DETECTION_URL);
      if (!window.tf || !window.poseDetection) throw new Error("pose-deps-unavailable");
      try { await window.tf.setBackend("webgl"); } catch (e) { await window.tf.setBackend("cpu"); }
      await window.tf.ready();
    })().catch(err => { poseDepsPromise = null; throw err; });
  }
  return poseDepsPromise;
}

let sharedDetectorPromise = null;
function getDetector() {
  if (!sharedDetectorPromise) {
    sharedDetectorPromise = ensurePoseDependencies().then(() =>
      window.poseDetection.createDetector(window.poseDetection.SupportedModels.MoveNet, {
        modelType: window.poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
      })
    ).catch(err => { sharedDetectorPromise = null; throw err; });
  }
  return sharedDetectorPromise;
}

/**
 * usePoseProvider — owns the camera stream + the MoveNet detector + the
 * per-frame inference loop. Reports poses via a callback ref (not React
 * state) so the 30–60fps detection loop never forces a full re-render;
 * only the caller decides when a frame actually needs to reach the UI.
 */
function usePoseProvider(videoRef, active, onFrame, retryKey) {
  const [status, setStatus] = useState("idle");
  // idle | cam-requesting | cam-denied | cam-unavailable | loading-model | model-error | ready
  const rafRef = useRef(null);
  const streamRef = useRef(null);
  const onFrameRef = useRef(onFrame);
  useEffect(() => { onFrameRef.current = onFrame; }, [onFrame]);

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    let detector = null;

    async function start() {
      setStatus("cam-requesting");
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          // No forced width/height "ideal" here on purpose — forcing a
          // resolution the camera hardware has to rescale to is a known
          // cause of corrupted/frozen preview frames on some Android
          // WebViews. Letting the camera pick its own native mode is
          // more reliable; MoveNet works fine at whatever size comes back.
          video: { facingMode: "user" }, audio: false,
        });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          const v = videoRef.current;
          // Setting these as JS properties (not just JSX attributes) right
          // before play() is required on some Android WebView versions —
          // otherwise autoplay can be silently blocked, leaving the video
          // element stuck on a single undecoded/garbled frame.
          v.muted = true;
          v.playsInline = true;
          v.srcObject = stream;
          try {
            await v.play();
          } catch (playErr) {
            // Autoplay can be rejected once right after the permission
            // prompt closes — one retry a beat later resolves it.
            await new Promise(r => setTimeout(r, 300));
            await v.play().catch(() => {});
          }
        }
      } catch (err) {
        if (!cancelled) setStatus(err && err.name === "NotFoundError" ? "cam-unavailable" : "cam-denied");
        return;
      }
      setStatus("loading-model");
      try {
        detector = await getDetector();
        if (cancelled) return;
        setStatus("ready");
        loop();
      } catch (err) {
        if (!cancelled) setStatus("model-error");
      }
    }

    async function loop() {
      if (cancelled) return;
      const video = videoRef.current;
      if (video && detector && video.readyState >= 2) {
        try {
          const poses = await detector.estimatePoses(video, { flipHorizontal: false });
          const p = poses && poses[0]
            ? { keypoints: poses[0].keypoints, videoWidth: video.videoWidth, videoHeight: video.videoHeight, t: performance.now() }
            : { keypoints: [], videoWidth: video.videoWidth, videoHeight: video.videoHeight, t: performance.now() };
          if (!cancelled) onFrameRef.current && onFrameRef.current(p);
        } catch (e) { /* transient inference error on a single frame — skip it */ }
      }
      rafRef.current = requestAnimationFrame(loop);
    }

    start();
    return () => {
      cancelled = true;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    };
  }, [active, retryKey]); // eslint-disable-line

  return { status };
}

/* ---------------- geometry helpers ---------------- */
function kp(pose, name, minScore = 0.3) {
  if (!pose || !pose.keypoints) return null;
  const k = pose.keypoints.find(p => p.name === name);
  if (!k || k.score == null || k.score < minScore) return null;
  return k;
}
function angleDeg(A, B, C) {
  if (!A || !B || !C) return null;
  const BA = { x: A.x - B.x, y: A.y - B.y };
  const BC = { x: C.x - B.x, y: C.y - B.y };
  const mBA = Math.hypot(BA.x, BA.y), mBC = Math.hypot(BC.x, BC.y);
  if (mBA < 1e-3 || mBC < 1e-3) return null;
  const cos = Math.max(-1, Math.min(1, (BA.x * BC.x + BA.y * BC.y) / (mBA * mBC)));
  return Math.acos(cos) * (180 / Math.PI);
}
function verticalLeanDeg(top, bottom) {
  if (!top || !bottom) return null;
  const v = { x: top.x - bottom.x, y: top.y - bottom.y };
  const mag = Math.hypot(v.x, v.y);
  if (mag < 1e-3) return null;
  const cos = Math.max(-1, Math.min(1, (-v.y) / mag));
  return Math.acos(cos) * (180 / Math.PI);
}
function midpoint(a, b) {
  if (a && b) return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, score: Math.min(a.score, b.score) };
  return a || b || null;
}

/* ========================================================================
   EXERCISE ANALYZER
   One entry per supported exercise: required landmarks, the primary joint
   angle that defines the rep cycle, secondary form metrics, thresholds,
   short live-feedback copy, and a form-scoring function. New exercises are
   added by extending this object — nothing else needs to change.
   ======================================================================== */
const EXERCISES = {
  squat: {
    name: "Bodyweight Squat",
    viewHint: "Face the camera, full body in frame",
    required: ["left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle", "left_shoulder", "right_shoulder"],
    topAngle: 160, bottomAngle: 110, minRepMs: 700,
    getMetrics(pose) {
      const angles = [];
      const lA = angleDeg(kp(pose, "left_hip"), kp(pose, "left_knee"), kp(pose, "left_ankle"));
      const rA = angleDeg(kp(pose, "right_hip"), kp(pose, "right_knee"), kp(pose, "right_ankle"));
      if (lA != null) angles.push(lA);
      if (rA != null) angles.push(rA);
      if (!angles.length) return null;
      const primary = angles.reduce((a, b) => a + b, 0) / angles.length;
      const sh = midpoint(kp(pose, "left_shoulder"), kp(pose, "right_shoulder"));
      const hip = midpoint(kp(pose, "left_hip"), kp(pose, "right_hip"));
      const torsoLean = verticalLeanDeg(sh, hip);
      const lKnee = kp(pose, "left_knee"), rKnee = kp(pose, "right_knee");
      const lAnkle = kp(pose, "left_ankle"), rAnkle = kp(pose, "right_ankle");
      let valgus = 0;
      if (lKnee && lAnkle && rKnee && rAnkle) {
        const stance = Math.abs(lAnkle.x - rAnkle.x) || 1;
        const kneeGap = Math.abs(lKnee.x - rKnee.x);
        valgus = Math.max(0, (stance - kneeGap) / stance);
      }
      return { primary, torsoLean, valgus };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return m.valgus > 0.35 ? "Knees aligned" : (m.torsoLean != null && m.torsoLean > 35 ? "Chest up" : "Go deeper");
      if (phase === "BOTTOM") return "Good depth — drive up";
      if (phase === "ASCENDING") return "Full extension";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 15 - (110 - rep.minAngle));
      if (rep.avgTorsoLean != null && rep.avgTorsoLean > 25) s -= Math.min(20, (rep.avgTorsoLean - 25) * 0.8);
      if (rep.maxValgus != null && rep.maxValgus > 0.3) s -= Math.min(20, (rep.maxValgus - 0.3) * 60);
      if (rep.durationMs < 1000) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
  pushup: {
    name: "Push-Up",
    viewHint: "Turn side-on to the camera, full body in frame",
    required: ["left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist", "left_hip", "right_hip"],
    topAngle: 155, bottomAngle: 95, minRepMs: 600,
    getMetrics(pose) {
      const sides = [
        { sh: kp(pose, "left_shoulder"), el: kp(pose, "left_elbow"), wr: kp(pose, "left_wrist"), hip: kp(pose, "left_hip"), an: kp(pose, "left_ankle") },
        { sh: kp(pose, "right_shoulder"), el: kp(pose, "right_elbow"), wr: kp(pose, "right_wrist"), hip: kp(pose, "right_hip"), an: kp(pose, "right_ankle") },
      ];
      const angles = []; let bodyAngle = null;
      sides.forEach(s => {
        const a = angleDeg(s.sh, s.el, s.wr);
        if (a != null) angles.push(a);
        if (bodyAngle == null) { const ba = angleDeg(s.sh, s.hip, s.an); if (ba != null) bodyAngle = ba; }
      });
      if (!angles.length) return null;
      const primary = angles.reduce((a, b) => a + b, 0) / angles.length;
      const alignment = bodyAngle == null ? 0 : Math.abs(180 - bodyAngle);
      return { primary, alignment };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return m.alignment > 20 ? "Hips level" : "Go lower";
      if (phase === "BOTTOM") return "Push up — full extension";
      if (phase === "ASCENDING") return "Elbows in";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 15 - (95 - rep.minAngle));
      if (rep.avgAlignment != null && rep.avgAlignment > 15) s -= Math.min(25, (rep.avgAlignment - 15) * 1.1);
      if (rep.durationMs < 800) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
  bicepcurl: {
    name: "Bicep Curl",
    viewHint: "Face the camera, arms visible at your sides",
    required: ["left_shoulder", "right_shoulder", "left_elbow", "right_elbow", "left_wrist", "right_wrist"],
    topAngle: 150, bottomAngle: 60, minRepMs: 600,
    getMetrics(pose) {
      const angles = []; const drifts = [];
      const lSh = kp(pose, "left_shoulder"), lEl = kp(pose, "left_elbow"), lWr = kp(pose, "left_wrist");
      const rSh = kp(pose, "right_shoulder"), rEl = kp(pose, "right_elbow"), rWr = kp(pose, "right_wrist");
      const lHip = kp(pose, "left_hip"), rHip = kp(pose, "right_hip");
      const scale = (lSh && lHip) ? Math.hypot(lSh.x - lHip.x, lSh.y - lHip.y) : ((rSh && rHip) ? Math.hypot(rSh.x - rHip.x, rSh.y - rHip.y) : 100);
      const lA = angleDeg(lSh, lEl, lWr); if (lA != null) { angles.push(lA); if (lSh && lEl) drifts.push(Math.abs(lEl.x - lSh.x) / scale); }
      const rA = angleDeg(rSh, rEl, rWr); if (rA != null) { angles.push(rA); if (rSh && rEl) drifts.push(Math.abs(rEl.x - rSh.x) / scale); }
      if (!angles.length) return null;
      const primary = angles.reduce((a, b) => a + b, 0) / angles.length;
      const drift = drifts.length ? Math.max(...drifts) : 0;
      return { primary, drift };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return "Control the movement";
      if (phase === "BOTTOM") return m.drift > 0.55 ? "Keep elbows stable" : "Full contraction";
      if (phase === "ASCENDING") return "Full extension";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 12 - (60 - rep.minAngle));
      if (rep.maxDrift != null && rep.maxDrift > 0.5) s -= Math.min(25, (rep.maxDrift - 0.5) * 50);
      if (rep.durationMs < 800) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
  lunge: {
    name: "Reverse Lunge",
    viewHint: "Turn side-on to the camera, full body in frame",
    required: ["left_hip", "right_hip", "left_knee", "right_knee", "left_ankle", "right_ankle", "left_shoulder", "right_shoulder"],
    topAngle: 160, bottomAngle: 100, minRepMs: 700,
    getMetrics(pose) {
      const lA = angleDeg(kp(pose, "left_hip"), kp(pose, "left_knee"), kp(pose, "left_ankle"));
      const rA = angleDeg(kp(pose, "right_hip"), kp(pose, "right_knee"), kp(pose, "right_ankle"));
      const avail = [lA, rA].filter(v => v != null);
      if (!avail.length) return null;
      const primary = Math.min(...avail);
      const sh = midpoint(kp(pose, "left_shoulder"), kp(pose, "right_shoulder"));
      const hip = midpoint(kp(pose, "left_hip"), kp(pose, "right_hip"));
      const torsoLean = verticalLeanDeg(sh, hip);
      return { primary, torsoLean, hipX: hip ? hip.x : null };
    },
    feedback(phase, m) {
      if (phase === "DESCENDING") return m.torsoLean != null && m.torsoLean > 30 ? "Torso upright" : "Go deeper";
      if (phase === "BOTTOM") return "Good depth — drive up";
      if (phase === "ASCENDING") return "Control your balance";
      return "Good rep";
    },
    score(rep) {
      let s = 100;
      s -= Math.max(0, 15 - (100 - rep.minAngle));
      if (rep.avgTorsoLean != null && rep.avgTorsoLean > 25) s -= Math.min(20, (rep.avgTorsoLean - 25) * 0.8);
      if (rep.sway > 0.18) s -= Math.min(15, (rep.sway - 0.18) * 80);
      if (rep.durationMs < 1000) s -= 8;
      return Math.max(55, Math.min(100, Math.round(s)));
    },
  },
};

const SKELETON_EDGES = [
  ["left_shoulder", "right_shoulder"], ["left_shoulder", "left_elbow"], ["left_elbow", "left_wrist"],
  ["right_shoulder", "right_elbow"], ["right_elbow", "right_wrist"],
  ["left_shoulder", "left_hip"], ["right_shoulder", "right_hip"], ["left_hip", "right_hip"],
  ["left_hip", "left_knee"], ["left_knee", "left_ankle"], ["right_hip", "right_knee"], ["right_knee", "right_ankle"],
];

/* ========================================================================
   VISIBILITY / SAFETY GATE
   Refuses to feed the rep verifier anything unless the required landmarks
   are confidently visible, the subject is a reasonable distance from the
   camera, and average tracking confidence is high enough to trust.
   ======================================================================== */
function checkVisibility(pose, exerciseKey) {
  const cfg = EXERCISES[exerciseKey];
  if (!pose || !pose.keypoints || !pose.keypoints.length) {
    return { ok: false, reason: "no-person", message: "No person detected — step into frame." };
  }
  const avgScore = pose.keypoints.reduce((a, k) => a + (k.score || 0), 0) / pose.keypoints.length;
  if (avgScore < 0.15) return { ok: false, reason: "no-person", message: "No person detected — step into frame." };
  const missing = cfg.required.filter(name => !kp(pose, name, 0.3));
  if (missing.length) return { ok: false, reason: "out-of-frame", message: "Move back so your full body is visible." };
  const visible = pose.keypoints.filter(k => k.score >= 0.3);
  const ys = visible.map(k => k.y);
  const bboxH = Math.max(...ys) - Math.min(...ys);
  const ratio = pose.videoHeight ? bboxH / pose.videoHeight : 0.5;
  if (ratio > 0.97) return { ok: false, reason: "too-close", message: "Step back — you're too close to the camera." };
  if (ratio < 0.2) return { ok: false, reason: "too-far", message: "Move closer to the camera." };
  if (avgScore < 0.35) return { ok: false, reason: "low-confidence", message: "We can't clearly see your movement — check lighting or angle." };
  return { ok: true };
}

/* ========================================================================
   REP VERIFIER
   Exercise-specific movement state machine:
   TOP -> DESCENDING -> BOTTOM(required depth) -> ASCENDING -> TOP (+1 rep)
   A rep is counted ONLY when required depth was reached, the full cycle
   returned to the top position, the whole cycle took at least minRepMs,
   and visibility held throughout. Anything else resets to TOP uncounted.
   No timer-based or manual increment exists anywhere in this module.
   ======================================================================== */
function createRepVerifier(exerciseKey) {
  const cfg = EXERCISES[exerciseKey];
  let phase = "TOP";
  let smoothed = null;
  let repStart = 0;
  let reachedDepth = false;
  let samples = [];

  function reset() { phase = "TOP"; smoothed = null; reachedDepth = false; samples = []; }

  function update(metrics, now, visible) {
    if (!metrics || !visible) {
      if (phase !== "TOP") {
        reset();
        return { event: "aborted", phase, feedback: "We lost sight of you — reposition to continue.", tone: "warn" };
      }
      return { event: "none", phase, feedback: cfg.viewHint, tone: "neutral" };
    }

    const raw = metrics.primary;
    smoothed = smoothed == null ? raw : smoothed * 0.65 + raw * 0.35;
    const TOP = cfg.topAngle, BOTTOM = cfg.bottomAngle;
    let event = "none";

    if (phase === "TOP") {
      if (smoothed <= TOP - 8) { phase = "DESCENDING"; repStart = now; reachedDepth = false; samples = [metrics]; }
    } else {
      samples.push(metrics);
      if (phase === "DESCENDING") {
        if (smoothed <= BOTTOM) { phase = "BOTTOM"; reachedDepth = true; }
        else if (smoothed >= TOP) { phase = "TOP"; samples = []; }
      } else if (phase === "BOTTOM") {
        if (smoothed >= BOTTOM + 10) phase = "ASCENDING";
      } else if (phase === "ASCENDING") {
        if (smoothed >= TOP) {
          const durationMs = now - repStart;
          const minAngle = Math.min(...samples.map(s => s.primary));
          if (reachedDepth && durationMs >= cfg.minRepMs) {
            const rep = summarizeRep(exerciseKey, samples, minAngle, durationMs);
            reset();
            return { event: "verified", phase, rep, feedback: cfg.feedback("TOP", metrics), tone: "good" };
          }
          reset();
          return { event: "rejected", phase, feedback: "REP NOT COUNTED — Complete the movement", tone: "warn" };
        } else if (smoothed <= BOTTOM) {
          phase = "BOTTOM";
        }
      }
    }
    return { event, phase, feedback: cfg.feedback(phase, metrics), tone: "neutral" };
  }

  return { update, reset };
}

/* ========================================================================
   FORM ANALYZER
   Converts a completed rep's sampled metrics into a 0–100 form score.
   Heuristic and intentionally conservative — this is movement guidance,
   not a clinical or medical-grade biomechanical assessment.
   ======================================================================== */
function summarizeRep(exerciseKey, samples, minAngle, durationMs) {
  const rep = { minAngle, durationMs };
  const avg = (key) => {
    const vals = samples.map(s => s[key]).filter(v => v != null);
    return vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null;
  };
  const max = (key) => {
    const vals = samples.map(s => s[key]).filter(v => v != null);
    return vals.length ? Math.max(...vals) : null;
  };
  rep.avgTorsoLean = avg("torsoLean");
  rep.avgAlignment = avg("alignment");
  rep.maxValgus = max("valgus");
  rep.maxDrift = max("drift");
  const hipXVals = samples.map(s => s.hipX).filter(v => v != null);
  rep.sway = hipXVals.length > 1 ? (Math.max(...hipXVals) - Math.min(...hipXVals)) / 260 : 0;
  rep.formScore = EXERCISES[exerciseKey].score(rep);
  return rep;
}

/* ---------------------------------------------------------------------- */
/* MOCK PROGRAM / NUTRITION DATA (unchanged product logic from Stage 1)    */
/* ---------------------------------------------------------------------- */
function buildWorkoutPlan(profile) {
  const setsCount = profile.level === "Beginner" ? 3 : profile.level === "Intermediate" ? 4 : 5;
  const defs = [
    { key: "squat", reps: 12 },
    { key: "pushup", reps: 10 },
    { key: "bicepcurl", reps: 12 },
    { key: "lunge", reps: 10 },
  ];
  return defs.map(d => ({ id: d.key, key: d.key, name: EXERCISES[d.key].name, sets: setsCount, reps: d.reps }));
}

const LOAD_PER_REP = { squat: 0.9, pushup: 0.64, lunge: 0.5, bicepcurl: 0 };
function estimateLoad(key, reps, bodyweight) {
  if (key === "bicepcurl") return reps * 12;
  return Math.round(reps * bodyweight * LOAD_PER_REP[key]);
}

function buildNutritionTargets(profile) {
  const w = profile.weight || 75;
  let calories, protein;
  if (profile.goal === "Lose Fat") { calories = Math.round(w * 24); protein = Math.round(w * 2.0); }
  else if (profile.goal === "Build Muscle" || profile.goal === "Get Stronger") { calories = Math.round(w * 32); protein = Math.round(w * 2.0); }
  else { calories = Math.round(w * 28); protein = Math.round(w * 1.7); }
  const fat = Math.round((calories * 0.27) / 9);
  const carbs = Math.round((calories - protein * 4 - fat * 9) / 4);
  return { calories, protein, carbs, fat };
}

const MEAL_TEMPLATES = [
  { name: "Greek Yogurt Bowl", cals: 420, protein: 34, carbs: 46, fat: 11, tag: "Breakfast", time: "10 min" },
  { name: "Grilled Chicken & Rice", cals: 640, protein: 52, carbs: 58, fat: 17, tag: "Lunch", time: "20 min" },
  { name: "Salmon & Sweet Potato", cals: 590, protein: 44, carbs: 48, fat: 22, tag: "Dinner", time: "25 min" },
  { name: "Protein Smoothie", cals: 310, protein: 30, carbs: 34, fat: 6, tag: "Snack", time: "5 min" },
  { name: "Turkey Wrap", cals: 480, protein: 38, carbs: 42, fat: 15, tag: "Lunch", time: "10 min" },
  { name: "Tofu Stir-Fry", cals: 520, protein: 30, carbs: 50, fat: 18, tag: "Dinner", time: "20 min" },
];

function buildMealPlan(profile) {
  const avoid = (profile.dislikes || "").toLowerCase();
  const pool = MEAL_TEMPLATES.filter(m => !avoid.includes(m.name.toLowerCase().split(" ")[0]));
  const slots = ["Breakfast", "Lunch", "Dinner", "Snack"];
  return slots.map((slot, i) => {
    const candidates = pool.filter(m => m.tag === slot);
    const meal = candidates[i % Math.max(candidates.length, 1)] || pool[i % pool.length];
    return { ...meal, id: slot + i, tag: slot, logged: false };
  });
}

const WEEKLY_QUESTS = [
  { id: "q1", label: "Complete 4 verified workouts", progress: 2, total: 4, xp: 150 },
  { id: "q2", label: "Hit nutrition targets 5 days", progress: 3, total: 5, xp: 120 },
  { id: "q3", label: "Log 50 verified high-quality reps", progress: 31, total: 50, xp: 100 },
  { id: "q4", label: "Beat one previous performance", progress: 0, total: 1, xp: 80 },
];

const RANKS = ["Rookie", "Starter", "Athlete", "Iron", "Elite", "Master", "Champion"];
function rankForLevel(level) { return RANKS[Math.min(RANKS.length - 1, Math.floor((level - 1) / 5))]; }
const BODY_QUEST_STAGES = ["Starter", "Foundation", "Builder", "Athlete", "Elite"];

/* ---------------------------------------------------------------------- */
/* SHARED UI PRIMITIVES                                                    */
/* ---------------------------------------------------------------------- */
function Card({ children, style, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: `linear-gradient(180deg, ${C.card} 0%, #101619 100%)`,
      border: `1px solid ${C.cardBorder}`, borderRadius: 18, padding: 16, ...style,
    }}>
      {children}
    </div>
  );
}
function ProgressBar({ value, max, color = C.teal, height = 8, bg = "#1A2327" }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div style={{ width: "100%", height, borderRadius: height, background: bg, overflow: "hidden" }}>
      <div style={{ width: `${pct}%`, height: "100%", borderRadius: height, background: color, transition: "width .5s ease" }} />
    </div>
  );
}
function Pill({ children, color = C.teal, bg = null }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 600,
      padding: "4px 9px", borderRadius: 999, color, background: bg || `${color}22`,
      fontFamily: "Inter, sans-serif", letterSpacing: 0.2,
    }}>{children}</span>
  );
}
function ScreenHeader({ title, subtitle, right }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18 }}>
      <div>
        <h1 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 26, fontWeight: 700, margin: 0, color: C.text }}>{title}</h1>
        {subtitle && <p style={{ color: C.sub, fontSize: 13.5, margin: "4px 0 0", fontFamily: "Inter, sans-serif" }}>{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* ONBOARDING                                                              */
/* ---------------------------------------------------------------------- */
function Onboarding({ onComplete }) {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({
    goal: null, age: "", height: "", weight: "", level: null,
    daysPerWeek: null, equipment: null, dislikes: "", allergies: "",
    cookingTime: null, budget: null,
  });
  const steps = ["goal", "level", "stats", "schedule", "equipment", "food", "review"];
  const total = steps.length;
  const set = (k, v) => setData(d => ({ ...d, [k]: v }));
  const canNext = () => {
    switch (steps[step]) {
      case "goal": return !!data.goal;
      case "level": return !!data.level;
      case "stats": return data.age && data.height && data.weight;
      case "schedule": return !!data.daysPerWeek;
      case "equipment": return !!data.equipment;
      case "food": return !!data.cookingTime;
      default: return true;
    }
  };
  const OptionGrid = ({ options, field, cols = 2 }) => (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 10, marginTop: 20 }}>
      {options.map(opt => {
        const active = data[field] === opt;
        return (
          <button key={opt} onClick={() => set(field, opt)} style={{
            padding: "16px 12px", borderRadius: 14, textAlign: "left",
            border: `1.5px solid ${active ? C.teal : C.cardBorder}`,
            background: active ? `${C.teal}14` : C.card,
            color: active ? C.teal : C.text, fontFamily: "Inter, sans-serif",
            fontWeight: 600, fontSize: 14, cursor: "pointer", transition: "all .15s",
          }}>{opt}</button>
        );
      })}
    </div>
  );
  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ padding: "24px 20px 0" }}>
        <div style={{ display: "flex", gap: 6, marginBottom: 22 }}>
          {steps.map((_, i) => <div key={i} style={{ flex: 1, height: 4, borderRadius: 4, background: i <= step ? C.teal : "#1A2327", transition: "background .3s" }} />)}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <div style={{ width: 30, height: 30, borderRadius: 9, background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Zap size={16} color="#0B0F10" strokeWidth={2.5} />
          </div>
          <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 16 }}>FORM</span>
        </div>
      </div>
      <div style={{ flex: 1, padding: "20px 20px 100px", overflowY: "auto" }}>
        {steps[step] === "goal" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>What's your main goal?</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>We'll build your training and nutrition plan around this.</p>
          <OptionGrid field="goal" cols={2} options={["Build Muscle", "Get Stronger", "Lose Fat", "Improve Fitness", "Get Lean/Toned", "Get Healthier"]} />
        </>)}
        {steps[step] === "level" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Training experience</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>This sets your starting intensity and progression speed.</p>
          <OptionGrid field="level" cols={1} options={["Beginner", "Intermediate", "Advanced"]} />
        </>)}
        {steps[step] === "stats" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>A few quick stats</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>Used to calculate your calorie and macro targets.</p>
          {[["age", "Age", "yrs"], ["height", "Height", "cm"], ["weight", "Weight", "kg"]].map(([k, label, unit]) => (
            <div key={k} style={{ marginTop: 16 }}>
              <label style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>{label}</label>
              <div style={{ display: "flex", alignItems: "center", background: C.card, border: `1.5px solid ${C.cardBorder}`, borderRadius: 12, marginTop: 6, padding: "12px 14px" }}>
                <input type="number" value={data[k]} onChange={e => set(k, e.target.value)}
                  style={{ background: "transparent", border: "none", outline: "none", color: C.text, fontSize: 16, fontWeight: 600, width: "100%", fontFamily: "Inter, sans-serif" }} placeholder="0" />
                <span style={{ color: C.faint, fontSize: 13 }}>{unit}</span>
              </div>
            </div>
          ))}
        </>)}
        {steps[step] === "schedule" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Training days per week</h2>
          <p style={{ color: C.sub, fontSize: 14 }}>Be realistic — consistency beats intensity.</p>
          <OptionGrid field="daysPerWeek" cols={4} options={["2", "3", "4", "5", "6", "7"]} />
        </>)}
        {steps[step] === "equipment" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Where do you train?</h2>
          <OptionGrid field="equipment" cols={2} options={["Full Gym", "Home", "Bodyweight Only", "Custom Equipment"]} />
        </>)}
        {steps[step] === "food" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Food preferences</h2>
          <div style={{ marginTop: 16 }}>
            <label style={{ fontSize: 12.5, color: C.sub, fontWeight: 600 }}>Allergies or foods to avoid</label>
            <input value={data.dislikes} onChange={e => set("dislikes", e.target.value)} placeholder="e.g. shellfish, peanuts"
              style={{ width: "100%", marginTop: 6, background: C.card, border: `1.5px solid ${C.cardBorder}`, borderRadius: 12, padding: "12px 14px", color: C.text, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "Inter, sans-serif" }} />
          </div>
          <p style={{ color: C.sub, fontSize: 13, fontWeight: 600, marginTop: 20 }}>Cooking time per meal</p>
          <OptionGrid field="cookingTime" cols={3} options={["<10 min", "10-25 min", "25+ min"]} />
          <p style={{ color: C.sub, fontSize: 13, fontWeight: 600, marginTop: 20 }}>Grocery budget (optional)</p>
          <OptionGrid field="budget" cols={3} options={["Low", "Medium", "Flexible"]} />
        </>)}
        {steps[step] === "review" && (<>
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700 }}>Building your plan</h2>
          <p style={{ color: C.sub, fontSize: 14, marginBottom: 20 }}>Here's what we'll generate based on your answers.</p>
          <Card style={{ marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Goal</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>{data.goal}</span></div></Card>
          <Card style={{ marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Level</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>{data.level}</span></div></Card>
          <Card style={{ marginBottom: 12 }}><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Schedule</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>{data.daysPerWeek} days / week · {data.equipment}</span></div></Card>
          <Card><div style={{ display: "flex", justifyContent: "space-between" }}><span style={{ color: C.sub, fontSize: 13.5 }}>Nutrition</span><span style={{ fontWeight: 600, fontSize: 13.5 }}>Personalized targets + {data.cookingTime} meals</span></div></Card>
        </>)}
      </div>
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, padding: 20, background: `linear-gradient(0deg, ${C.bg} 60%, transparent)`, display: "flex", gap: 10 }}>
        {step > 0 && (<button onClick={() => setStep(s => s - 1)} style={{ width: 50, borderRadius: 14, border: `1.5px solid ${C.cardBorder}`, background: C.card, color: C.text, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}><ChevronLeft size={20} /></button>)}
        <button disabled={!canNext()} onClick={() => step === total - 1 ? onComplete(data) : setStep(s => s + 1)} style={{
          flex: 1, borderRadius: 14, border: "none", padding: "16px", fontWeight: 700, fontSize: 15,
          background: canNext() ? `linear-gradient(135deg, ${C.teal}, #22B8A6)` : "#1A2327",
          color: canNext() ? "#04211D" : C.faint, cursor: canNext() ? "pointer" : "not-allowed",
          fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
        }}>{step === total - 1 ? "Generate My Plan" : "Continue"} <ArrowRight size={17} /></button>
      </div>
    </div>
  );
}

/* ========================================================================
   CAMERA STATUS SCREEN — permission / model-loading / error states
   ======================================================================== */
function CameraStatusScreen({ status, onExit, onRetry }) {
  const content = {
    "cam-requesting": { icon: <Loader2 size={30} className="spin" color={C.teal} />, title: null, body: "Requesting camera access…" },
    "loading-model": { icon: <Loader2 size={30} className="spin" color={C.teal} />, title: "Loading pose model", body: "Downloading the on-device movement-tracking model. This only happens once per session." },
    "cam-denied": { icon: <Camera size={34} color={C.sub} />, title: "Camera access needed", body: "FORM needs your camera to verify reps and form. Enable camera access in your browser settings, then try again." },
    "cam-unavailable": { icon: <AlertTriangle size={34} color={C.amber} />, title: "No camera found", body: "This device doesn't have an accessible camera. Verified rep tracking isn't available right now." },
    "model-error": { icon: <AlertTriangle size={34} color={C.amber} />, title: "Pose model couldn't load", body: "The on-device movement-tracking model failed to download — check your connection and try again. Verified rep counting can't run without it." },
  };
  const c = content[status] || content["cam-requesting"];
  return (
    <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: C.text, gap: 14, padding: 30, textAlign: "center", height: "100%" }}>
      {c.icon}
      {c.title && <h3 style={{ fontFamily: "Space Grotesk, sans-serif", margin: 0 }}>{c.title}</h3>}
      <p style={{ color: C.sub, fontSize: 13.5, maxWidth: 280, margin: 0 }}>{c.body}</p>
      <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
        {(status === "model-error" || status === "cam-denied") && onRetry && (
          <button onClick={onRetry} style={{ background: C.teal, border: "none", color: "#04211D", padding: "12px 20px", borderRadius: 12, fontWeight: 700 }}>Try Again</button>
        )}
        <button onClick={onExit} style={{ background: C.card, border: `1px solid ${C.cardBorder}`, color: C.text, padding: "12px 20px", borderRadius: 12, fontWeight: 600 }}>Go Back</button>
      </div>
      <style>{`.spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

/* ========================================================================
   WORKOUT SESSION SCREEN
   Sequences through today's exercises. Owns one continuous camera stream
   and one MoveNet detector for the whole session (opened once, not
   per-exercise) for a smoother, lower-latency experience. Delegates rep
   logic entirely to the ExerciseAnalyzer + RepVerifier layers above.
   ======================================================================== */
function WorkoutSessionScreen({ exercises, startIndex, personalBests, bodyweight, onFinish, onExit }) {
  const videoRef = useRef(null);
  const [retryKey, setRetryKey] = useState(0);
  const [exIdx, setExIdx] = useState(startIndex || 0);
  const [setNum, setSetNum] = useState(1);
  const [subPhase, setSubPhase] = useState("positioning"); // positioning|active|paused|resting|exerciseDone|sessionDone
  const [reps, setReps] = useState(0);
  const [uiState, setUiState] = useState({ feedback: "Position yourself for this exercise", tone: "neutral" });
  const [lastRepScore, setLastRepScore] = useState(null);
  const [restSeconds, setRestSeconds] = useState(45);
  const [results, setResults] = useState({}); // { [exerciseKey]: { totalReps, avgForm, sets:[{reps,avgForm}], isPR } }
  const [flash, setFlash] = useState(false);

  const verifierRef = useRef(null);
  const repScoresRef = useRef([]);
  const positioningOkSinceRef = useRef(null);
  const stickyUntilRef = useRef(0);
  const lastUiUpdateRef = useRef(0);
  const poseRef = useRef(null);
  const canvasRef = useRef(null);
  const badFlagRef = useRef(false);

  const currentExercise = exercises[exIdx];
  const cfg = currentExercise ? EXERCISES[currentExercise.key] : null;

  const resetForNewSet = useCallback(() => {
    verifierRef.current = currentExercise ? createRepVerifier(currentExercise.key) : null;
    repScoresRef.current = [];
    setReps(0);
    setLastRepScore(null);
    positioningOkSinceRef.current = null;
    setSubPhase("positioning");
    setUiState({ feedback: cfg ? cfg.viewHint : "", tone: "neutral" });
  }, [currentExercise, cfg]);

  useEffect(() => { resetForNewSet(); }, [exIdx]); // eslint-disable-line

  function drawSkeleton(poseData) {
    const canvas = canvasRef.current;
    if (!canvas || !canvas.parentElement) return;
    const w = canvas.parentElement.clientWidth, h = canvas.parentElement.clientHeight;
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, w, h);
    try {
      if (!poseData || !poseData.keypoints || !poseData.keypoints.length) return;
      const vw = poseData.videoWidth, vh = poseData.videoHeight;
      // Guard against a 0-size container (e.g. during the very first
      // layout pass) or a video with no metadata yet — dividing by zero
      // here previously produced Infinity/NaN-scaled coordinates that
      // rendered as a giant distorted shape instead of just skipping the
      // frame.
      if (!w || !h || !vw || !vh) return;
      const scale = Math.max(w / vw, h / vh);
      if (!isFinite(scale) || scale <= 0) return;
      const dw = vw * scale, dh = vh * scale;
      const ox = (dw - w) / 2, oy = (dh - h) / 2;
      const map = (pt) => { const sx = pt.x * scale - ox; const sy = pt.y * scale - oy; return { x: w - sx, y: sy }; };
      const byName = {}; poseData.keypoints.forEach(k => byName[k.name] = k);
      const color = badFlagRef.current ? C.red : C.teal;
      ctx.strokeStyle = color; ctx.lineWidth = 3; ctx.lineCap = "round";
      SKELETON_EDGES.forEach(([a, b]) => {
        const A = byName[a], B = byName[b];
        if (A && B && A.score > 0.3 && B.score > 0.3) {
          const pa = map(A), pb = map(B);
          ctx.beginPath(); ctx.moveTo(pa.x, pa.y); ctx.lineTo(pb.x, pb.y); ctx.stroke();
        }
      });
      ctx.fillStyle = color;
      poseData.keypoints.forEach(k => {
        if (k.score > 0.3) { const p = map(k); ctx.beginPath(); ctx.arc(p.x, p.y, 4, 0, Math.PI * 2); ctx.fill(); }
      });
    } catch (e) {
      // Never let a single bad frame leave a stuck/garbled overlay —
      // the clearRect above already ran, so worst case is a blank frame.
      console.warn("drawSkeleton frame skipped:", e);
    }
  }

  function maybeUpdateUi(text, tone, now, force) {
    if (!force && now < stickyUntilRef.current) return;
    if (!force && now - lastUiUpdateRef.current < 150) return;
    lastUiUpdateRef.current = now;
    setUiState(u => (u.feedback === text && u.tone === tone) ? u : { feedback: text, tone });
  }

  const handleFrame = useCallback((poseData) => {
    poseRef.current = poseData;
    const now = poseData.t || performance.now();

    if (!currentExercise) return;
    const vis = checkVisibility(poseData, currentExercise.key);
    badFlagRef.current = !vis.ok;
    drawSkeleton(poseData);

    if (subPhase === "paused" || subPhase === "resting" || subPhase === "exerciseDone" || subPhase === "sessionDone") return;

    if (subPhase === "positioning") {
      if (vis.ok) {
        if (!positioningOkSinceRef.current) positioningOkSinceRef.current = now;
        if (now - positioningOkSinceRef.current > 700) {
          verifierRef.current = createRepVerifier(currentExercise.key);
          setSubPhase("active");
          setUiState({ feedback: "Begin when ready", tone: "good" });
          stickyUntilRef.current = now + 700;
        } else {
          maybeUpdateUi("Hold still — locking on", "good", now, true);
        }
      } else {
        positioningOkSinceRef.current = null;
        maybeUpdateUi(vis.message, "warn", now, true);
      }
      return;
    }

    // subPhase === 'active'
    if (!verifierRef.current) return;
    if (!vis.ok) {
      const res = verifierRef.current.update(null, now, false);
      maybeUpdateUi(res.feedback, res.tone, now, res.event === "aborted");
      return;
    }
    const metrics = cfg.getMetrics(poseData);
    const res = verifierRef.current.update(metrics, now, true);
    if (res.event === "verified") {
      repScoresRef.current.push(res.rep.formScore);
      stickyUntilRef.current = now + 1100;
      setLastRepScore(res.rep.formScore);
      setUiState({ feedback: "Good rep", tone: "good" });
      setFlash(true); setTimeout(() => setFlash(false), 260);
      setReps(r => r + 1);
    } else if (res.event === "rejected" || res.event === "aborted") {
      stickyUntilRef.current = now + 1300;
      setUiState({ feedback: res.feedback, tone: "warn" });
    } else {
      maybeUpdateUi(res.feedback, res.tone, now);
    }
  }, [currentExercise, cfg, subPhase]);

  const { status } = usePoseProvider(videoRef, true, handleFrame, retryKey);

  // advance set / exercise when target reps reached
  useEffect(() => {
    if (subPhase !== "active" || !currentExercise) return;
    if (reps >= currentExercise.reps) {
      const setAvg = repScoresRef.current.length ? Math.round(repScoresRef.current.reduce((a, b) => a + b, 0) / repScoresRef.current.length) : 0;
      setResults(prev => {
        const key = currentExercise.key;
        const existing = prev[key] || { totalReps: 0, sets: [], avgForm: 0 };
        const sets = [...existing.sets, { reps, avgForm: setAvg }];
        const totalReps = existing.totalReps + reps;
        const avgForm = Math.round(sets.reduce((a, s) => a + s.avgForm, 0) / sets.length);
        return { ...prev, [key]: { totalReps, sets, avgForm } };
      });
      if (setNum >= currentExercise.sets) {
        setSubPhase("exerciseDone");
      } else {
        setSubPhase("resting");
        setRestSeconds(45);
      }
    }
  }, [reps]); // eslint-disable-line

  // rest countdown
  useEffect(() => {
    if (subPhase !== "resting") return;
    if (restSeconds <= 0) { setSetNum(n => n + 1); resetForNewSet(); return; }
    const t = setTimeout(() => setRestSeconds(s => s - 1), 1000);
    return () => clearTimeout(t);
  }, [subPhase, restSeconds]); // eslint-disable-line

  function goNextExercise() {
    if (exIdx >= exercises.length - 1) {
      setSubPhase("sessionDone");
    } else {
      setExIdx(i => i + 1);
      setSetNum(1);
    }
  }

  function finishSession() {
    const perExercise = { ...results };
    let totalXp = 150; // workout complete base
    let totalReps = 0, totalFormWeighted = 0, prCount = 0, estLoad = 0;
    Object.entries(perExercise).forEach(([key, r]) => {
      totalReps += r.totalReps;
      totalFormWeighted += r.avgForm * r.totalReps;
      estLoad += estimateLoad(key, r.totalReps, bodyweight);
      const prevBest = personalBests[key]?.reps || 0;
      const isPR = r.totalReps > prevBest;
      perExercise[key] = { ...r, isPR };
      if (isPR) prCount++;
    });
    const avgForm = totalReps ? Math.round(totalFormWeighted / totalReps) : 0;
    totalXp += totalReps * 2;
    if (avgForm >= 85) totalXp += 60;
    totalXp += prCount * 50;
    onFinish({ perExercise, totalReps, avgForm, totalXp, prCount, estLoad });
  }

  if (!currentExercise) return null;

  if (subPhase === "sessionDone") {
    const perExercise = { ...results };
    let totalReps = 0, totalFormWeighted = 0, prCount = 0, estLoad = 0;
    Object.entries(perExercise).forEach(([key, r]) => {
      totalReps += r.totalReps; totalFormWeighted += r.avgForm * r.totalReps;
      estLoad += estimateLoad(key, r.totalReps, bodyweight);
      if (r.totalReps > (personalBests[key]?.reps || 0)) prCount++;
    });
    const avgForm = totalReps ? Math.round(totalFormWeighted / totalReps) : 0;
    return (
      <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text }}>
        <style>{FONT_IMPORT}</style>
        <div style={{ flex: 1, overflowY: "auto", padding: "40px 22px 20px", textAlign: "center" }}>
          <Trophy size={40} color={C.amber} style={{ margin: "0 auto 10px" }} />
          <h1 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 24, fontWeight: 700, margin: "0 0 4px" }}>WORKOUT COMPLETE</h1>
          <p style={{ color: C.sub, fontSize: 13.5, marginBottom: 24 }}>Every rep below was camera-verified.</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>VERIFIED REPS</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 26, fontWeight: 700, color: C.teal }}>{totalReps}</div></Card>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>AVG FORM</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 26, fontWeight: 700, color: C.green }}>{avgForm}</div></Card>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>EST. LOAD MOVED</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 22, fontWeight: 700 }}>{estLoad} kg</div></Card>
            <Card><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>PERSONAL RECORDS</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 22, fontWeight: 700, color: C.amber }}>{prCount}</div></Card>
          </div>
          <p style={{ fontSize: 10.5, color: C.faint, marginBottom: 18 }}>Estimated load is derived from bodyweight and reps — not a scale measurement.</p>
          {Object.entries(perExercise).map(([key, r]) => (
            <Card key={key} style={{ marginBottom: 10, textAlign: "left" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14 }}>{EXERCISES[key].name}</div>
                {r.totalReps > (personalBests[key]?.reps || 0) && <Pill color={C.amber}><Trophy size={11} /> NEW PR</Pill>}
              </div>
              <div style={{ fontSize: 12.5, color: C.sub, marginTop: 3 }}>{r.totalReps} verified reps · {r.avgForm} avg form</div>
            </Card>
          ))}
          <button onClick={finishSession} style={{
            width: "100%", marginTop: 12, padding: 16, borderRadius: 14, border: "none",
            background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontSize: 15,
            fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}>Continue <ArrowRight size={17} /></button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ position: "absolute", inset: 0, background: "#050707" }}>
        {/* The <video> tag is always mounted (visibility is opacity-based,
            not conditional rendering). Previously it only mounted once
            status==="ready", but the camera stream gets attached to the
            ref earlier, while status is still "cam-requesting" — at that
            point the tag didn't exist yet, so the stream had nowhere to
            attach. The element was then mounted later with no source,
            and the browser rendered its default "no video" placeholder
            icon instead of the live feed. Keeping it always-mounted fixes
            that race condition. The mirror flip stays on this wrapper,
            not the <video> itself — a transform directly on a live
            camera <video> is a known trigger for corrupted/frozen
            preview frames on some Android WebView + GPU combinations. */}
        <div style={{ position: "absolute", inset: 0, transform: "scaleX(-1)" }}>
          <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover", opacity: status === "ready" ? 0.92 : 0, display: "block", transition: "opacity .25s ease" }} />
        </div>
      </div>
      {status === "ready" && <canvas ref={canvasRef} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }} />}
      {flash && <div style={{ position: "absolute", inset: 0, background: `${C.green}22`, pointerEvents: "none" }} />}

      <div style={{ position: "relative", zIndex: 2, display: "flex", justifyContent: "space-between", alignItems: "center", padding: "18px 16px 0" }}>
        <button onClick={onExit} style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <X size={18} color={C.text} />
        </button>
        <div style={{ background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "8px 14px", textAlign: "center" }}>
          <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 14, color: C.text }}>{currentExercise.name}</div>
          <div style={{ fontSize: 11, color: C.sub }}>Set {setNum} / {currentExercise.sets} · Exercise {exIdx + 1}/{exercises.length}</div>
        </div>
        {status === "ready" && subPhase === "active" ? (
          <button onClick={() => setSubPhase("paused")} style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Pause size={16} color={C.text} />
          </button>
        ) : <div style={{ width: 38 }} />}
      </div>

      {status !== "ready" && <CameraStatusScreen status={status} onExit={onExit} onRetry={() => setRetryKey(k => k + 1)} />}

      {status === "ready" && subPhase === "positioning" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, padding: 30, textAlign: "center" }}>
          <div style={{ background: "rgba(10,14,15,0.85)", border: `1px solid ${C.cardBorder}`, borderRadius: 16, padding: "20px 24px" }}>
            <ScanLine size={26} color={uiState.tone === "good" ? C.green : C.amber} style={{ marginBottom: 8 }} />
            <p style={{ color: C.text, fontWeight: 600, fontSize: 14, margin: 0 }}>{uiState.feedback}</p>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "paused" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 16 }}>
          <h3 style={{ color: C.text, fontFamily: "Space Grotesk, sans-serif" }}>Paused</h3>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setSubPhase("active")} style={{ background: C.teal, border: "none", color: "#04211D", padding: "12px 22px", borderRadius: 12, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}><Play size={15} fill="#04211D" /> Resume</button>
            <button onClick={onExit} style={{ background: "rgba(248,113,113,0.15)", border: `1px solid ${C.red}`, color: C.red, padding: "12px 22px", borderRadius: 12, fontWeight: 700, display: "flex", alignItems: "center", gap: 6 }}><Square size={14} /> End Workout</button>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "resting" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14 }}>
          <div style={{ background: "rgba(10,14,15,0.9)", border: `1px solid ${C.cardBorder}`, borderRadius: 20, padding: "26px 30px", textAlign: "center" }}>
            <Timer size={24} color={C.purple} style={{ marginBottom: 8 }} />
            <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 40, fontWeight: 700, color: C.text }}>{restSeconds}s</div>
            <div style={{ color: C.sub, fontSize: 12.5, marginTop: 4 }}>Rest — Set {setNum + 1} of {currentExercise.sets} next</div>
            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
              <button onClick={() => setRestSeconds(s => Math.max(0, s - 15))} style={{ background: "#1A2327", border: "none", color: C.text, padding: "8px 14px", borderRadius: 10, fontWeight: 600 }}>-15s</button>
              <button onClick={() => setRestSeconds(s => s + 15)} style={{ background: "#1A2327", border: "none", color: C.text, padding: "8px 14px", borderRadius: 10, fontWeight: 600 }}>+15s</button>
              <button onClick={() => setRestSeconds(0)} style={{ background: C.teal, border: "none", color: "#04211D", padding: "8px 16px", borderRadius: 10, fontWeight: 700 }}>Skip</button>
            </div>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "exerciseDone" && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, padding: 24 }}>
          <div style={{ background: "rgba(10,14,15,0.92)", border: `1px solid ${C.cardBorder}`, borderRadius: 20, padding: "26px 26px", textAlign: "center", width: "100%", maxWidth: 340 }}>
            <Check size={28} color={C.green} style={{ marginBottom: 8 }} />
            <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 18, color: C.text }}>{currentExercise.name} complete</div>
            <div style={{ color: C.sub, fontSize: 13, marginTop: 6 }}>{results[currentExercise.key]?.totalReps || 0} verified reps · {results[currentExercise.key]?.avgForm || 0} avg form</div>
            {(results[currentExercise.key]?.totalReps || 0) > (personalBests[currentExercise.key]?.reps || 0) && (
              <div style={{ marginTop: 10 }}><Pill color={C.amber}><Trophy size={11} /> NEW PERSONAL RECORD</Pill></div>
            )}
            <button onClick={goNextExercise} style={{
              marginTop: 18, width: "100%", padding: 14, borderRadius: 13, border: "none",
              background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontSize: 14.5,
              fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            }}>{exIdx >= exercises.length - 1 ? "Finish Workout" : "Next Exercise"} <ArrowRight size={16} /></button>
          </div>
        </div>
      )}

      {status === "ready" && subPhase === "active" && (
        <>
          <div style={{ position: "relative", zIndex: 2, flex: 1 }} />
          <div style={{ position: "relative", zIndex: 2, padding: "0 16px 8px", display: "flex", justifyContent: "center" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8, padding: "8px 16px", borderRadius: 999,
              background: uiState.tone === "good" ? `${C.green}22` : uiState.tone === "warn" ? `${C.red}22` : "rgba(10,14,15,0.75)",
              border: `1px solid ${uiState.tone === "good" ? C.green : uiState.tone === "warn" ? C.red : C.cardBorder}`,
              transition: "all .2s", maxWidth: "88%",
            }}>
              {uiState.tone === "good" ? <Check size={15} color={C.green} /> : uiState.tone === "warn" ? <AlertTriangle size={15} color={C.red} /> : <Info size={15} color={C.sub} />}
              <span style={{ fontSize: 12.5, fontWeight: 600, color: uiState.tone === "good" ? C.green : uiState.tone === "warn" ? C.red : C.text, textAlign: "center" }}>{uiState.feedback}</span>
            </div>
          </div>
          <div style={{ position: "relative", zIndex: 2, background: "rgba(8,11,12,0.88)", backdropFilter: "blur(10px)", borderTop: `1px solid ${C.cardBorder}`, padding: "18px 20px 28px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div>
                <div style={{ fontSize: 11, color: C.sub, fontWeight: 600, letterSpacing: 0.3 }}>VERIFIED REPS</div>
                <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 40, fontWeight: 700, color: C.text, lineHeight: 1 }}>
                  {reps}<span style={{ fontSize: 20, color: C.faint }}> / {currentExercise.reps}</span>
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 11, color: C.sub, fontWeight: 600, letterSpacing: 0.3 }}>FORM</div>
                <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 28, fontWeight: 700, color: lastRepScore == null ? C.faint : (lastRepScore >= 85 ? C.green : lastRepScore >= 70 ? C.amber : C.red) }}>{lastRepScore ?? "—"}</div>
              </div>
            </div>
            <ProgressBar value={reps} max={currentExercise.reps} color={C.teal} height={10} />
            <p style={{ textAlign: "center", color: C.faint, fontSize: 10.5, marginTop: 14 }}>
              On-device pose tracking (TensorFlow.js MoveNet) — guidance, not a medical assessment.
            </p>
          </div>
        </>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* FOOD SCANNER (Stage 1 — unchanged: estimated camera recognition)        */
/* ---------------------------------------------------------------------- */
const MOCK_SCAN_RESULTS = [
  [{ name: "Grilled Chicken Breast", cals: 231, protein: 43, carbs: 0, fat: 5 }, { name: "White Rice", cals: 205, protein: 4, carbs: 45, fat: 0 }, { name: "Broccoli", cals: 55, protein: 4, carbs: 11, fat: 1 }],
  [{ name: "Scrambled Eggs", cals: 220, protein: 18, carbs: 2, fat: 16 }, { name: "Sourdough Toast", cals: 160, protein: 6, carbs: 30, fat: 1 }, { name: "Avocado", cals: 120, protein: 1, carbs: 6, fat: 11 }],
  [{ name: "Salmon Fillet", cals: 367, protein: 39, carbs: 0, fat: 22 }, { name: "Quinoa", cals: 180, protein: 7, carbs: 32, fat: 3 }, { name: "Asparagus", cals: 27, protein: 3, carbs: 5, fat: 0 }],
];

function FoodScanner({ onClose, onLog }) {
  const videoRef = useRef(null);
  const [camState, setCamState] = useState("requesting");
  const [phase, setPhase] = useState("scanning");
  const [result, setResult] = useState(null);
  const [streamRef, setStreamRef] = useState(null);

  useEffect(() => {
    let cancelled = false;
    async function go() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        setStreamRef(stream);
        if (videoRef.current) {
          const v = videoRef.current;
          v.muted = true;
          v.playsInline = true;
          v.srcObject = stream;
          v.play().catch(() => {});
        }
        setCamState("granted");
        setTimeout(() => {
          if (cancelled) return;
          const pick = MOCK_SCAN_RESULTS[Math.floor(Math.random() * MOCK_SCAN_RESULTS.length)];
          setResult(pick); setPhase("result");
        }, 2200);
      } catch (err) {
        if (!cancelled) setCamState(err?.name === "NotFoundError" ? "unavailable" : "denied");
      }
    }
    go();
    return () => { cancelled = true; if (streamRef) streamRef.getTracks().forEach(t => t.stop()); };
    // eslint-disable-next-line
  }, []);

  const totals = useMemo(() => {
    if (!result) return null;
    return result.reduce((a, f) => ({ cals: a.cals + f.cals, protein: a.protein + f.protein, carbs: a.carbs + f.carbs, fat: a.fat + f.fat }), { cals: 0, protein: 0, carbs: 0, fat: 0 });
  }, [result]);

  return (
    <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif" }}>
      <div style={{ position: "absolute", inset: 0 }}>
        <video ref={videoRef} autoPlay playsInline muted style={{ width: "100%", height: "100%", objectFit: "cover", opacity: camState === "granted" ? (phase === "result" ? 0.35 : 0.85) : 0, transition: "opacity .2s ease" }} />
      </div>
      <div style={{ position: "relative", zIndex: 2, display: "flex", justifyContent: "space-between", padding: "18px 16px" }}>
        <button onClick={onClose} style={{ width: 38, height: 38, borderRadius: 12, background: "rgba(10,14,15,0.7)", border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={18} color="#fff" /></button>
        <Pill color={C.amber} bg="rgba(10,14,15,0.75)">ESTIMATED — camera scan</Pill>
      </div>
      {camState === "requesting" && (<div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", gap: 14 }}><Loader2 size={30} className="spin" color={C.teal} /><p style={{ color: C.sub }}>Requesting camera access…</p></div>)}
      {camState === "denied" && (<div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", gap: 14, padding: 30, textAlign: "center" }}><Camera size={34} color={C.sub} /><h3 style={{ fontFamily: "Space Grotesk, sans-serif" }}>Camera access needed</h3><p style={{ color: C.sub, fontSize: 13.5 }}>Enable camera access to scan your food.</p><button onClick={onClose} style={{ marginTop: 8, background: C.card, border: `1px solid ${C.cardBorder}`, color: "#fff", padding: "12px 20px", borderRadius: 12, fontWeight: 600 }}>Go Back</button></div>)}
      {camState === "unavailable" && (<div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#fff", gap: 14, padding: 30, textAlign: "center" }}><AlertTriangle size={34} color={C.amber} /><h3 style={{ fontFamily: "Space Grotesk, sans-serif" }}>No camera found</h3><button onClick={onClose} style={{ marginTop: 8, background: C.card, border: `1px solid ${C.cardBorder}`, color: "#fff", padding: "12px 20px", borderRadius: 12, fontWeight: 600 }}>Go Back</button></div>)}
      {camState === "granted" && phase === "scanning" && (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
          <div style={{ width: 240, height: 240, border: `2px solid ${C.teal}`, borderRadius: 20, position: "relative", overflow: "hidden" }}>
            <div className="scanline" style={{ position: "absolute", left: 0, right: 0, height: 2, background: C.teal, boxShadow: `0 0 12px ${C.teal}` }} />
          </div>
          <p style={{ color: "#fff", marginTop: 20, fontWeight: 600 }}>Analyzing food…</p>
          <style>{`.scanline{animation:scan 1.8s ease-in-out infinite;} @keyframes scan{0%{top:0}50%{top:238px}100%{top:0}} .spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </div>
      )}
      {phase === "result" && result && (
        <div style={{ position: "relative", zIndex: 2, flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
          <div style={{ background: C.bg2, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: "22px 20px 26px", border: `1px solid ${C.cardBorder}` }}>
            <h3 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, color: C.text, margin: "0 0 4px" }}>Detected foods</h3>
            <p style={{ color: C.sub, fontSize: 12.5, marginBottom: 14 }}>Estimates from image only — actual values vary with portion size. Use Scale Mode for precise tracking.</p>
            {result.map((f, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: i < result.length - 1 ? `1px solid ${C.cardBorder}` : "none" }}>
                <div><div style={{ fontWeight: 600, fontSize: 14, color: C.text }}>{f.name}</div><div style={{ fontSize: 12, color: C.sub }}>{f.protein}g protein · {f.carbs}g carbs · {f.fat}g fat</div></div>
                <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: C.teal }}>{f.cals}</div>
              </div>
            ))}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16, padding: 14, borderRadius: 14, background: `${C.teal}12`, border: `1px solid ${C.tealDim}` }}>
              <span style={{ fontWeight: 700, color: C.text, fontSize: 14 }}>Total (estimated)</span>
              <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: C.teal, fontSize: 16 }}>{totals.cals} kcal</span>
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button onClick={onClose} style={{ flex: 1, padding: 14, borderRadius: 12, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600 }}>Discard</button>
              <button onClick={() => onLog({ name: result.map(f => f.name).join(", "), cals: totals.cals, protein: totals.protein, carbs: totals.carbs, fat: totals.fat, source: "scan" })} style={{ flex: 2, padding: 14, borderRadius: 12, border: "none", background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700 }}>Log This Meal</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* SCALE MODE (Stage 1 — unchanged)                                        */
/* ---------------------------------------------------------------------- */
const SCALE_ITEMS = [
  { name: "Chicken Breast", per100: { cals: 165, protein: 31, carbs: 0, fat: 4 } },
  { name: "White Rice (cooked)", per100: { cals: 130, protein: 2.7, carbs: 28, fat: 0.3 } },
  { name: "Broccoli", per100: { cals: 34, protein: 2.8, carbs: 7, fat: 0.4 } },
  { name: "Salmon", per100: { cals: 208, protein: 20, carbs: 0, fat: 13 } },
  { name: "Sweet Potato", per100: { cals: 86, protein: 1.6, carbs: 20, fat: 0.1 } },
  { name: "Greek Yogurt", per100: { cals: 59, protein: 10, carbs: 3.6, fat: 0.4 } },
];

function ScaleMode({ onClose, onLog }) {
  const [items, setItems] = useState([{ item: SCALE_ITEMS[0].name, grams: 186 }, { item: SCALE_ITEMS[1].name, grams: 210 }, { item: SCALE_ITEMS[2].name, grams: 95 }]);
  const calc = (item, grams) => {
    const ref = SCALE_ITEMS.find(i => i.name === item)?.per100 || { cals: 0, protein: 0, carbs: 0, fat: 0 };
    const f = grams / 100;
    return { cals: ref.cals * f, protein: ref.protein * f, carbs: ref.carbs * f, fat: ref.fat * f };
  };
  const totals = items.reduce((a, it) => { const c = calc(it.item, it.grams); return { cals: a.cals + c.cals, protein: a.protein + c.protein, carbs: a.carbs + c.carbs, fat: a.fat + c.fat }; }, { cals: 0, protein: 0, carbs: 0, fat: 0 });
  const updateGrams = (i, delta) => setItems(items.map((it, idx) => idx === i ? { ...it, grams: Math.max(0, it.grams + delta) } : it));
  const updateItem = (i, name) => setItems(items.map((it, idx) => idx === i ? { ...it, item: name } : it));
  const removeItem = i => setItems(items.filter((_, idx) => idx !== i));
  const addItem = () => setItems([...items, { item: SCALE_ITEMS[0].name, grams: 100 }]);
  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 50, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}><Scale size={19} color={C.teal} /><h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Scale Mode</h2></div>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}><X size={17} color={C.text} /></button>
      </div>
      <p style={{ color: C.sub, fontSize: 12.5, padding: "0 18px 14px" }}>Connect a compatible smart scale, or enter grams manually for precise nutrition.</p>
      <div style={{ flex: 1, overflowY: "auto", padding: "0 18px" }}>
        <Card style={{ marginBottom: 14, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: `${C.faint}22`, display: "flex", alignItems: "center", justifyContent: "center" }}><Scale size={16} color={C.faint} /></div>
            <div><div style={{ fontWeight: 600, fontSize: 13.5 }}>Smart scale</div><div style={{ fontSize: 11.5, color: C.sub }}>No compatible scale paired</div></div>
          </div>
          <button style={{ fontSize: 12.5, fontWeight: 600, color: C.teal, background: "transparent", border: `1px solid ${C.tealDim}`, borderRadius: 9, padding: "7px 12px" }}>Pair Device</button>
        </Card>
        {items.map((it, i) => {
          const c = calc(it.item, it.grams);
          return (
            <Card key={i} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <select value={it.item} onChange={e => updateItem(i, e.target.value)} style={{ background: "transparent", border: "none", color: C.text, fontWeight: 700, fontSize: 14.5, fontFamily: "Inter, sans-serif", outline: "none" }}>
                  {SCALE_ITEMS.map(s => <option key={s.name} value={s.name} style={{ background: C.card }}>{s.name}</option>)}
                </select>
                <button onClick={() => removeItem(i)} style={{ background: "none", border: "none", color: C.faint }}><X size={16} /></button>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                <button onClick={() => updateGrams(i, -5)} style={{ width: 32, height: 32, borderRadius: 9, background: "#1A2327", border: "none", color: C.text, display: "flex", alignItems: "center", justifyContent: "center" }}><Minus size={15} /></button>
                <div style={{ flex: 1, textAlign: "center" }}><span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{it.grams}</span><span style={{ color: C.sub, fontSize: 13 }}> g</span></div>
                <button onClick={() => updateGrams(i, 5)} style={{ width: 32, height: 32, borderRadius: 9, background: "#1A2327", border: "none", color: C.text, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={15} /></button>
              </div>
              <div style={{ fontSize: 12, color: C.sub }}>{Math.round(c.cals)} kcal · {c.protein.toFixed(1)}g P · {c.carbs.toFixed(1)}g C · {c.fat.toFixed(1)}g F</div>
            </Card>
          );
        })}
        <button onClick={addItem} style={{ width: "100%", padding: 13, borderRadius: 12, border: `1.5px dashed ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, marginBottom: 20 }}><Plus size={15} /> Add Ingredient</button>
      </div>
      <div style={{ padding: 18, borderTop: `1px solid ${C.cardBorder}`, background: C.bg2 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ fontWeight: 700, fontSize: 15 }}>{Math.round(totals.cals)} kcal</span>
          <span style={{ fontSize: 13, color: C.sub }}>{Math.round(totals.protein)}g Protein · {Math.round(totals.carbs)}g Carbs · {Math.round(totals.fat)}g Fat</span>
        </div>
        <button onClick={() => onLog({ name: items.map(i => i.item).join(", "), cals: Math.round(totals.cals), protein: Math.round(totals.protein), carbs: Math.round(totals.carbs), fat: Math.round(totals.fat), source: "scale" })} style={{ width: "100%", padding: 15, borderRadius: 14, border: "none", background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontSize: 15, fontFamily: "Space Grotesk, sans-serif" }}>Log Measured Meal</button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* DAILY SUMMARY MODAL                                                     */
/* ---------------------------------------------------------------------- */
function DailySummary({ onClose, pct, xp, workoutDone, reps, formScore, nutritionPct }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(4,6,7,0.75)", zIndex: 60, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div style={{ width: "100%", maxWidth: 480, background: C.bg2, borderTopLeftRadius: 26, borderTopRightRadius: 26, border: `1px solid ${C.cardBorder}`, padding: "28px 22px 30px", fontFamily: "Inter, sans-serif" }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: C.sub, fontWeight: 700, letterSpacing: 1 }}>DAY COMPLETE</div>
          <div style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 44, fontWeight: 700, color: C.teal, margin: "6px 0" }}>{pct}%</div>
          <Pill color={C.purple}>+{xp} XP</Pill>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>WORKOUT</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{workoutDone ? "Completed" : "Not done"}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>VERIFIED REPS</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{reps}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>FORM SCORE</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{formScore}</div></Card>
          <Card style={{ padding: 14 }}><div style={{ fontSize: 11, color: C.sub, fontWeight: 600 }}>NUTRITION</div><div style={{ fontWeight: 700, fontSize: 15, marginTop: 3 }}>{nutritionPct}%</div></Card>
        </div>
        <button onClick={onClose} style={{ width: "100%", marginTop: 20, padding: 15, borderRadius: 14, border: "none", background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontFamily: "Space Grotesk, sans-serif" }}>Done</button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* HOME                                                                     */
/* ---------------------------------------------------------------------- */
function HomeScreen({ profile, game, workoutPlan, todayResults, nutrition, meals, hydration, setHydration, onStartWorkout, onOpenSummary }) {
  const xpForLevel = 1000;
  const xpPct = (game.xp % xpForLevel) / xpForLevel * 100;
  const completedExercises = Object.keys(todayResults).length;
  const caloriesLogged = meals.filter(m => m.logged).reduce((a, m) => a + m.cals, 0);
  const proteinLogged = meals.filter(m => m.logged).reduce((a, m) => a + m.protein, 0);

  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
        <div><p style={{ color: C.sub, fontSize: 13, margin: 0 }}>Welcome back</p><h1 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 22, fontWeight: 700, margin: "2px 0 0" }}>{profile.name || "Athlete"}</h1></div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: "8px 12px" }}><Flame size={16} color={C.amber} /><span style={{ fontWeight: 700, fontSize: 14 }}>{game.streak}</span></div>
      </div>

      <Card style={{ marginBottom: 14, background: `linear-gradient(135deg, ${C.tealDim}55, ${C.purpleDim}55)`, border: `1px solid ${C.tealDim}` }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 19, color: C.text }}>Level {game.level} — {rankForLevel(game.level).toUpperCase()}</div><div style={{ fontSize: 12, color: C.sub }}>{game.xp % xpForLevel} / {xpForLevel} XP to next level</div></div>
          <Trophy size={26} color={C.amber} />
        </div>
        <ProgressBar value={xpPct} max={100} color={C.teal} height={8} />
      </Card>

      <div onClick={onStartWorkout} style={{ cursor: "pointer" }}>
        <Card style={{ marginBottom: 14, border: `1px solid ${C.tealDim}` }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <Pill color={C.teal}>TODAY'S WORKOUT</Pill>
              <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 17, marginTop: 8 }}>{workoutPlan.length} exercises · {completedExercises}/{workoutPlan.length} done</div>
              <div style={{ fontSize: 12.5, color: C.sub, marginTop: 3 }}>{workoutPlan.map(e => e.name).join(" · ")}</div>
            </div>
            <Dumbbell size={22} color={C.teal} />
          </div>
          <button style={{ marginTop: 14, width: "100%", padding: 14, borderRadius: 13, border: "none", background: `linear-gradient(135deg, ${C.teal}, #22B8A6)`, color: "#04211D", fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <Play size={16} fill="#04211D" /> START TODAY'S WORKOUT
          </button>
        </Card>
      </div>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Nutrition Today</span><UtensilsCrossed size={17} color={C.purple} /></div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><span style={{ fontSize: 13, color: C.sub }}>Calories</span><span style={{ fontSize: 13, fontWeight: 600 }}>{caloriesLogged} / {nutrition.calories} kcal</span></div>
        <ProgressBar value={caloriesLogged} max={nutrition.calories} color={C.purple} />
        <div style={{ display: "flex", justifyContent: "space-between", margin: "10px 0 6px" }}><span style={{ fontSize: 13, color: C.sub }}>Protein</span><span style={{ fontSize: 13, fontWeight: 600 }}>{proteinLogged} / {nutrition.protein} g</span></div>
        <ProgressBar value={proteinLogged} max={nutrition.protein} color={C.teal} />
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Today's Meals</span>
        {meals.map(m => (
          <div key={m.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderTop: `1px solid ${C.cardBorder}`, marginTop: 10 }}>
            <div><div style={{ fontSize: 13.5, fontWeight: 600, color: m.logged ? C.sub : C.text, textDecoration: m.logged ? "line-through" : "none" }}>{m.name}</div><div style={{ fontSize: 11.5, color: C.faint }}>{m.tag} · {m.cals} kcal</div></div>
            {m.logged ? <Check size={16} color={C.green} /> : <Pill color={C.sub}>Planned</Pill>}
          </div>
        ))}
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}><Droplets size={18} color="#5EEAD4" /><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Hydration</span></div>
          <span style={{ fontSize: 13, fontWeight: 600 }}>{hydration} / 8 cups</span>
        </div>
        <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
          {Array.from({ length: 8 }).map((_, i) => (<div key={i} onClick={() => setHydration(i + 1 === hydration ? i : i + 1)} style={{ flex: 1, height: 26, borderRadius: 7, cursor: "pointer", background: i < hydration ? "linear-gradient(180deg,#5EEAD4,#2DD4BF)" : "#1A2327", border: `1px solid ${i < hydration ? "#2DD4BF" : C.cardBorder}` }} />))}
        </div>
      </Card>

      <Card style={{ marginBottom: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}><span style={{ fontWeight: 700, fontSize: 14.5, fontFamily: "Space Grotesk, sans-serif" }}>Weekly Quests</span><Target size={17} color={C.purple} /></div>
        {WEEKLY_QUESTS.slice(0, 2).map(q => (
          <div key={q.id} style={{ marginBottom: 10 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5 }}><span style={{ color: C.text }}>{q.label}</span><span style={{ color: C.purple, fontWeight: 600 }}>{q.progress}/{q.total}</span></div>
            <div style={{ marginTop: 5 }}><ProgressBar value={q.progress} max={q.total} color={C.purple} height={6} /></div>
          </div>
        ))}
      </Card>

      <button onClick={onOpenSummary} style={{ width: "100%", padding: 13, borderRadius: 13, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontWeight: 600, fontSize: 13 }}>View Daily Summary</button>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* TRAIN                                                                    */
/* ---------------------------------------------------------------------- */
function TrainScreen({ workoutPlan, todayResults, lastSession, onStart }) {
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Train" subtitle="Camera-verified sets — no manual logging." />
      {workoutPlan.map((ex, i) => {
        const today = todayResults[ex.key];
        const last = lastSession[ex.key];
        return (
          <Card key={ex.id} style={{ marginBottom: 12, opacity: today ? 0.8 : 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: today ? `${C.green}22` : `${C.teal}18`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: today ? C.green : C.teal }}>
                  {today ? <Check size={18} /> : i + 1}
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, fontFamily: "Space Grotesk, sans-serif" }}>{ex.name}</div>
                  <div style={{ fontSize: 12.5, color: C.sub }}>{ex.sets} sets × {ex.reps} reps{last ? ` · last: ${last.totalReps} reps, ${last.avgForm} form` : ""}</div>
                </div>
              </div>
              {!today && (<button onClick={() => onStart(i)} style={{ background: C.teal, border: "none", borderRadius: 10, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center" }}><Play size={16} color="#04211D" fill="#04211D" /></button>)}
            </div>
            {today?.isPR && (<div style={{ marginTop: 10, display: "flex", alignItems: "center", gap: 6 }}><Trophy size={14} color={C.amber} /><span style={{ fontSize: 12, fontWeight: 700, color: C.amber }}>NEW PERSONAL RECORD</span></div>)}
          </Card>
        );
      })}
      <Card style={{ marginTop: 6, background: "transparent", border: `1px dashed ${C.cardBorder}` }}>
        <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
          <ShieldCheck size={16} color={C.sub} style={{ marginTop: 2, flexShrink: 0 }} />
          <p style={{ fontSize: 12, color: C.sub, margin: 0 }}>Reps are verified on-device with real pose tracking (TensorFlow.js MoveNet) — a full extend-flex-extend cycle must be completed to count. Guidance only, not a medical-grade assessment.</p>
        </div>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* EAT (Stage 1 — unchanged)                                                */
/* ---------------------------------------------------------------------- */
function EatScreen({ nutrition, meals, setMeals, onOpenScanner, onOpenScale, loggedMealsList }) {
  const totals = meals.filter(m => m.logged).reduce((a, m) => ({ cals: a.cals + m.cals, protein: a.protein + m.protein, carbs: a.carbs + m.carbs, fat: a.fat + m.fat }), { cals: 0, protein: 0, carbs: 0, fat: 0 });
  const remaining = { cals: Math.max(0, nutrition.calories - totals.cals), protein: Math.max(0, nutrition.protein - totals.protein) };
  const toggleLog = id => setMeals(meals.map(m => m.id === id ? { ...m, logged: !m.logged } : m));
  const replaceMeal = id => setMeals(meals.map(m => { if (m.id !== id) return m; const alt = MEAL_TEMPLATES[Math.floor(Math.random() * MEAL_TEMPLATES.length)]; return { ...alt, id, tag: m.tag, logged: false }; }));
  const grocery = useMemo(() => ["Chicken breast", "Rice", "Broccoli", "Greek yogurt", "Eggs", "Sourdough bread", "Salmon", "Sweet potato", "Spinach", "Olive oil"], [meals]);
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Eat" subtitle="Scan, weigh, and track with confidence." />
      <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
        <button onClick={onOpenScanner} style={{ flex: 1, padding: "16px 10px", borderRadius: 16, border: `1px solid ${C.tealDim}`, background: `${C.teal}10`, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, color: C.teal, cursor: "pointer" }}><Camera size={22} /><span style={{ fontWeight: 700, fontSize: 13, fontFamily: "Space Grotesk, sans-serif" }}>SCAN FOOD</span></button>
        <button onClick={onOpenScale} style={{ flex: 1, padding: "16px 10px", borderRadius: 16, border: `1px solid ${C.purpleDim}`, background: `${C.purple}10`, display: "flex", flexDirection: "column", alignItems: "center", gap: 6, color: C.purple, cursor: "pointer" }}><Scale size={22} /><span style={{ fontWeight: 700, fontSize: 13, fontFamily: "Space Grotesk, sans-serif" }}>USE SCALE</span></button>
      </div>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}><span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif" }}>Remaining Today</span></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <div><div style={{ fontSize: 11, color: C.sub }}>CALORIES</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{remaining.cals}</div></div>
          <div><div style={{ fontSize: 11, color: C.sub }}>PROTEIN</div><div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 20 }}>{remaining.protein}g</div></div>
        </div>
      </Card>
      {loggedMealsList.length > 0 && (
        <Card style={{ marginBottom: 16 }}>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14 }}>Logged Today</span>
          {loggedMealsList.map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderTop: `1px solid ${C.cardBorder}`, marginTop: 9 }}>
              <div><div style={{ fontSize: 13, fontWeight: 600 }}>{m.name}</div><Pill color={m.source === "scale" ? C.purple : C.amber}>{m.source === "scale" ? "Measured" : "Estimated"}</Pill></div>
              <span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, color: C.teal }}>{m.cals} kcal</span>
            </div>
          ))}
        </Card>
      )}
      <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 15 }}>Today's Meal Plan</span>
      {meals.map(m => (
        <Card key={m.id} style={{ marginTop: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div><Pill color={C.sub}>{m.tag}</Pill><div style={{ fontWeight: 700, fontSize: 15, marginTop: 6, fontFamily: "Space Grotesk, sans-serif" }}>{m.name}</div><div style={{ fontSize: 12, color: C.sub, marginTop: 2 }}>{m.cals} kcal · {m.protein}g P · {m.time}</div></div>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button onClick={() => replaceMeal(m.id)} style={{ flex: 1, padding: 10, borderRadius: 10, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontSize: 12.5, fontWeight: 600 }}>Replace</button>
            <button style={{ flex: 1, padding: 10, borderRadius: 10, border: `1px solid ${C.cardBorder}`, background: "transparent", color: C.sub, fontSize: 12.5, fontWeight: 600 }}>View Recipe</button>
            <button onClick={() => toggleLog(m.id)} style={{ flex: 1, padding: 10, borderRadius: 10, border: "none", background: m.logged ? `${C.green}22` : C.teal, color: m.logged ? C.green : "#04211D", fontSize: 12.5, fontWeight: 700 }}>{m.logged ? "Logged ✓" : "Log Meal"}</button>
          </div>
        </Card>
      ))}
      <Card style={{ marginTop: 16 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Grocery List</span>
        <p style={{ fontSize: 12, color: C.sub, margin: "4px 0 10px" }}>Auto-generated from this week's meal plan.</p>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{grocery.map(g => <Pill key={g} color={C.sub} bg="#1A2327">{g}</Pill>)}</div>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* PROGRESS                                                                 */
/* ---------------------------------------------------------------------- */
const WEIGHT_TREND = [{ d: "W1", v: 82.1 }, { d: "W2", v: 81.7 }, { d: "W3", v: 81.4 }, { d: "W4", v: 80.9 }, { d: "W5", v: 80.6 }, { d: "W6", v: 80.1 }, { d: "W7", v: 79.8 }];
const STRENGTH_TREND = [{ d: "W1", v: 60 }, { d: "W2", v: 62.5 }, { d: "W3", v: 65 }, { d: "W4", v: 65 }, { d: "W5", v: 67.5 }, { d: "W6", v: 70 }, { d: "W7", v: 72.5 }];

function ProgressScreen({ game, formHistory }) {
  const radarData = [
    { stat: "Strength", v: game.stats.strength }, { stat: "Muscle", v: game.stats.muscle },
    { stat: "Endurance", v: game.stats.endurance }, { stat: "Mobility", v: game.stats.mobility },
    { stat: "Form", v: game.stats.form }, { stat: "Consistency", v: game.stats.consistency },
  ];
  const formTrend = formHistory.length ? formHistory : [{ d: "—", v: game.stats.form }];
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Progress" subtitle="You vs. you — tracked over time." />
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Attributes</span>
        <div style={{ height: 220 }}>
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={radarData} outerRadius="70%">
              <PolarGrid stroke={C.cardBorder} />
              <PolarAngleAxis dataKey="stat" tick={{ fill: C.sub, fontSize: 11 }} />
              <Radar dataKey="v" stroke={C.teal} fill={C.teal} fillOpacity={0.35} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Weight Trend</span>
        <div style={{ height: 160, marginTop: 6 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={WEIGHT_TREND}>
              <CartesianGrid stroke={C.cardBorder} vertical={false} />
              <XAxis dataKey="d" stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} domain={["dataMin - 1", "dataMax + 1"]} />
              <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, fontSize: 12 }} />
              <Line type="monotone" dataKey="v" stroke={C.teal} strokeWidth={2.5} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Strength Trend — Est. Squat Load</span>
        <div style={{ height: 160, marginTop: 6 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={STRENGTH_TREND}>
              <CartesianGrid stroke={C.cardBorder} vertical={false} />
              <XAxis dataKey="d" stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, fontSize: 12 }} />
              <Bar dataKey="v" fill={C.purple} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
      <Card style={{ marginBottom: 14 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Verified Form Score — Recent Sessions</span>
        <div style={{ height: 140, marginTop: 6 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={formTrend}>
              <CartesianGrid stroke={C.cardBorder} vertical={false} />
              <XAxis dataKey="d" stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke={C.faint} fontSize={11} tickLine={false} axisLine={false} domain={[50, 100]} />
              <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, fontSize: 12 }} />
              <Line type="monotone" dataKey="v" stroke={C.green} strokeWidth={2.5} dot={{ r: 3, fill: C.green }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* PROFILE + AI COACH + BODY QUEST                                         */
/* ---------------------------------------------------------------------- */
function CoachPanel({ game, profile, lastSession }) {
  const keys = Object.keys(lastSession);
  const fallbackMsg = keys.length
    ? `Your last session verified ${keys.map(k => `${lastSession[k].totalReps} ${EXERCISES[k].name.toLowerCase()} reps`).join(", ")} with an average form score of ${Math.round(keys.reduce((a, k) => a + lastSession[k].avgForm, 0) / keys.length)}. Based on your ${profile.daysPerWeek}-day schedule, keep the current program and follow the scheduled progression next session.`
    : `Complete your first camera-verified workout and I'll start giving you recommendations based on your real form and progression data.`;

  // The panel always renders instantly with the local fallback message
  // (computed from real on-device data), then quietly upgrades to a
  // backend-generated message if the secure coach API is reachable.
  // Nothing here changes if VITE_COACH_API_URL is unset or the network
  // request fails — the UI is identical to the Stage 1/2 behavior.
  const [msg, setMsg] = useState(fallbackMsg);
  useEffect(() => {
    setMsg(fallbackMsg);
    let cancelled = false;
    fetchCoachMessage({ profile, lastSession, level: game.level, stats: game.stats }).then(remote => {
      if (!cancelled && remote) setMsg(remote);
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line
  }, [JSON.stringify(lastSession)]);

  return (
    <Card style={{ marginBottom: 16, border: `1px solid ${C.purpleDim}`, background: `${C.purple}0A` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}><Sparkles size={17} color={C.purple} /><span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>AI Coach</span></div>
      <p style={{ fontSize: 13.5, color: C.text, lineHeight: 1.5, margin: 0 }}>{msg}</p>
    </Card>
  );
}

/* ========================================================================
   SETTINGS — camera permission status/controls, plus basic app info.
   Two ways of checking are combined because WebView support for the
   Permissions API varies by device: `navigator.permissions.query` gives a
   non-invasive read (no prompt) when supported, while "Check Camera
   Access" does a real getUserMedia probe (stops the stream immediately)
   for a ground-truth answer, which also happens to be the path that
   actually triggers Android's permission dialog the first time.
   ======================================================================== */
async function queryCameraPermission() {
  try {
    if (navigator.permissions && navigator.permissions.query) {
      const result = await navigator.permissions.query({ name: "camera" });
      return result.state; // 'granted' | 'denied' | 'prompt'
    }
  } catch (e) { /* some WebViews don't support querying 'camera' — fall through */ }
  return "unknown";
}

async function probeCameraAccess() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    stream.getTracks().forEach(t => t.stop());
    return "granted";
  } catch (err) {
    if (err && err.name === "NotFoundError") return "no-camera";
    return "denied";
  }
}

function SettingsScreen({ onClose }) {
  const [status, setStatus] = useState("checking");
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    let cancelled = false;
    queryCameraPermission().then(s => { if (!cancelled) setStatus(s); });
    return () => { cancelled = true; };
  }, []);

  async function handleCheck() {
    setChecking(true);
    const result = await probeCameraAccess();
    setStatus(result);
    setChecking(false);
  }

  function handleOpenAppSettings() {
    try {
      NativeSettings.open({ optionAndroid: AndroidSettings.ApplicationDetails });
    } catch (e) {
      // Running in a plain browser (no native bridge) — nothing to open.
    }
  }

  const statusMeta = {
    checking: { label: "Checking…", color: C.sub, desc: "Looking up your current camera permission." },
    unknown: { label: "Unknown", color: C.amber, desc: "This device can't report camera status without asking. Tap \"Check Camera Access\" below to find out for sure." },
    prompt: { label: "Not decided yet", color: C.amber, desc: "Android hasn't asked you yet. Tap \"Check Camera Access\" to trigger the permission prompt." },
    granted: { label: "Camera access is ON", color: C.green, desc: "Train and Eat can use your camera for verified reps and food scanning." },
    denied: { label: "Camera access is OFF", color: C.red, desc: "Verified reps and food scanning won't work until you turn this on in Android's app settings." },
    "no-camera": { label: "No camera found", color: C.amber, desc: "This device doesn't appear to have an accessible camera." },
  };
  const meta = statusMeta[status] || statusMeta.unknown;

  return (
    <div style={{ position: "fixed", inset: 0, background: C.bg, zIndex: 55, display: "flex", flexDirection: "column", fontFamily: "Inter, sans-serif", color: C.text, paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 18px 4px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <SettingsIcon size={19} color={C.teal} />
          <h2 style={{ fontFamily: "Space Grotesk, sans-serif", fontSize: 19, fontWeight: 700, margin: 0 }}>Settings</h2>
        </div>
        <button onClick={onClose} style={{ width: 36, height: 36, borderRadius: 11, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <X size={17} color={C.text} />
        </button>
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "14px 18px 40px" }}>
        <Card style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Camera size={17} color={meta.color} />
              <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Camera Access</span>
            </div>
            <Pill color={meta.color}>{meta.label}</Pill>
          </div>
          <p style={{ fontSize: 13, color: C.sub, lineHeight: 1.5, margin: "0 0 16px" }}>{meta.desc}</p>

          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={handleCheck} disabled={checking} style={{
              flex: 1, padding: 13, borderRadius: 12, border: "none",
              background: checking ? "#1A2327" : `linear-gradient(135deg, ${C.teal}, #22B8A6)`,
              color: checking ? C.faint : "#04211D", fontWeight: 700, fontSize: 13,
              display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
            }}>
              <RefreshCw size={14} className={checking ? "spin" : ""} /> {checking ? "Checking…" : "Check Camera Access"}
            </button>
            {(status === "denied" || status === "granted" || status === "no-camera") && (
              <button onClick={handleOpenAppSettings} style={{
                flex: 1, padding: 13, borderRadius: 12, border: `1px solid ${C.cardBorder}`, background: "transparent",
                color: C.text, fontWeight: 700, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
              }}>
                <ExternalLink size={14} /> Open App Settings
              </button>
            )}
          </div>
          <style>{`.spin{animation:spin 1s linear infinite;} @keyframes spin{to{transform:rotate(360deg)}}`}</style>
        </Card>

        <Card style={{ marginBottom: 16, background: "transparent", border: `1px dashed ${C.cardBorder}` }}>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
            <ShieldCheck size={16} color={C.sub} style={{ marginTop: 2, flexShrink: 0 }} />
            <p style={{ fontSize: 12, color: C.sub, margin: 0 }}>
              If camera access shows as OFF, tap "Open App Settings", choose <strong>Permissions → Camera</strong>, and
              set it to Allow. Come back here and tap "Check Camera Access" to confirm it worked.
            </p>
          </div>
        </Card>

        <Card>
          <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>About</span>
          <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
            <span style={{ color: C.sub }}>Version</span><span style={{ fontWeight: 600 }}>1.0.0</span>
          </div>
          <div style={{ marginTop: 8, display: "flex", justifyContent: "space-between", fontSize: 13 }}>
            <span style={{ color: C.sub }}>Pose tracking</span><span style={{ fontWeight: 600 }}>On-device (TensorFlow.js)</span>
          </div>
        </Card>
      </div>
    </div>
  );
}


function ProfileScreen({ profile, game, lastSession, onOpenSettings }) {
  const stageIdx = Math.min(BODY_QUEST_STAGES.length - 1, Math.floor(game.level / 8));
  return (
    <div style={{ padding: "22px 18px 100px" }}>
      <ScreenHeader title="Profile" subtitle={`${rankForLevel(game.level)} · Level ${game.level}`}
        right={(
          <button onClick={onOpenSettings} style={{ width: 38, height: 38, borderRadius: 12, background: C.card, border: `1px solid ${C.cardBorder}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <SettingsIcon size={17} color={C.sub} />
          </button>
        )} />
      <Card style={{ marginBottom: 16, textAlign: "center" }}>
        <div style={{ width: 68, height: 68, borderRadius: "50%", margin: "0 auto 10px", background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 24, color: "#0B0F10" }}>{(profile.name || "A")[0]}</span></div>
        <div style={{ fontFamily: "Space Grotesk, sans-serif", fontWeight: 700, fontSize: 17 }}>{profile.name || "Athlete"}</div>
        <div style={{ color: C.sub, fontSize: 12.5, marginTop: 2 }}>{profile.goal} · {profile.level}</div>
      </Card>
      <CoachPanel game={game} profile={profile} lastSession={lastSession} />
      <Card style={{ marginBottom: 16 }}>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Character Stats</span>
        <div style={{ marginTop: 12 }}>
          {Object.entries(game.stats).map(([k, v]) => (
            <div key={k} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}><span style={{ textTransform: "capitalize", color: C.text }}>{k}</span><span style={{ color: C.teal, fontWeight: 700 }}>{v}</span></div>
              <ProgressBar value={v} max={100} color={k === "form" ? C.green : k === "consistency" ? C.purple : C.teal} height={6} />
            </div>
          ))}
        </div>
      </Card>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}><span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Body Quest</span><Award size={17} color={C.amber} /></div>
        <div style={{ display: "flex", alignItems: "center" }}>
          {BODY_QUEST_STAGES.map((s, i) => (
            <React.Fragment key={s}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}>
                <div style={{ width: 34, height: 34, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: i <= stageIdx ? `linear-gradient(135deg, ${C.teal}, ${C.purple})` : "#1A2327", border: `1px solid ${i <= stageIdx ? C.teal : C.cardBorder}` }}>
                  {i <= stageIdx ? <Check size={15} color="#04211D" /> : <Lock size={13} color={C.faint} />}
                </div>
                <span style={{ fontSize: 9.5, color: i <= stageIdx ? C.text : C.faint, marginTop: 5, textAlign: "center" }}>{s}</span>
              </div>
              {i < BODY_QUEST_STAGES.length - 1 && <div style={{ flex: 0.6, height: 2, background: i < stageIdx ? C.teal : C.cardBorder, marginBottom: 16 }} />}
            </React.Fragment>
          ))}
        </div>
      </Card>
      <Card>
        <span style={{ fontWeight: 700, fontFamily: "Space Grotesk, sans-serif", fontSize: 14.5 }}>Weekly Quests</span>
        {WEEKLY_QUESTS.map(q => (
          <div key={q.id} style={{ marginTop: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 5 }}><span>{q.label}</span><span style={{ color: C.purple, fontWeight: 700 }}>+{q.xp} XP</span></div>
            <ProgressBar value={q.progress} max={q.total} color={q.progress >= q.total ? C.green : C.purple} height={6} />
          </div>
        ))}
      </Card>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* NAV                                                                      */
/* ---------------------------------------------------------------------- */
function BottomNav({ tab, setTab }) {
  const items = [
    { id: "home", label: "Home", icon: HomeIcon }, { id: "train", label: "Train", icon: Dumbbell },
    { id: "eat", label: "Eat", icon: UtensilsCrossed }, { id: "progress", label: "Progress", icon: TrendingUp },
    { id: "profile", label: "Profile", icon: User },
  ];
  return (
    <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, maxWidth: 480, margin: "0 auto", background: "rgba(11,15,16,0.92)", backdropFilter: "blur(12px)", borderTop: `1px solid ${C.cardBorder}`, display: "flex", padding: "10px 6px calc(env(safe-area-inset-bottom,0px) + 10px)", zIndex: 20 }}>
      {items.map(({ id, label, icon: Icon }) => {
        const active = tab === id;
        return (
          <button key={id} onClick={() => setTab(id)} style={{ flex: 1, background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "6px 0", cursor: "pointer" }}>
            <Icon size={20} color={active ? C.teal : C.faint} strokeWidth={active ? 2.4 : 2} />
            <span style={{ fontSize: 10.5, color: active ? C.teal : C.faint, fontWeight: active ? 700 : 500, fontFamily: "Inter, sans-serif" }}>{label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* ROOT APP                                                                 */
/* ---------------------------------------------------------------------- */
function FormApp() {
  const [profile, setProfile] = useState(null);
  const [tab, setTab] = useState("home");
  const [workoutPlan, setWorkoutPlan] = useState([]);
  const [nutrition, setNutrition] = useState(null);
  const [meals, setMeals] = useState([]);
  const [hydration, setHydration] = useState(3);
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionStartIndex, setSessionStartIndex] = useState(0);
  const [todayResults, setTodayResults] = useState({});
  const [lastSession, setLastSession] = useState({});
  const [formHistory, setFormHistory] = useState([]);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scaleOpen, setScaleOpen] = useState(false);
  const [summaryOpen, setSummaryOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [loggedMealsList, setLoggedMealsList] = useState([]);
  const [xpToast, setXpToast] = useState(null);
  const [personalBests, setPersonalBests] = useState({
    squat: { reps: 40 }, pushup: { reps: 32 }, bicepcurl: { reps: 38 }, lunge: { reps: 30 },
  });
  const [game, setGame] = useState({
    level: 18, xp: 640, streak: 6,
    stats: { strength: 78, muscle: 71, endurance: 64, mobility: 69, form: 94, consistency: 91 },
  });

  useEffect(() => {
    (async () => {
      try {
        const saved = await storage.get("form:profile");
        if (saved?.value) {
          const p = JSON.parse(saved.value);
          setProfile(p);
          setWorkoutPlan(buildWorkoutPlan(p));
          setNutrition(buildNutritionTargets(p));
          setMeals(buildMealPlan(p));
        }
      } catch (e) { /* no saved profile yet */ }
    })();
  }, []);

  // Android hardware back button: close whatever's on top (camera session,
  // scanner, scale, daily summary) before falling back to tab navigation,
  // and only exit the app from the Home tab with nothing open.
  useEffect(() => {
    if (!CapApp) return;
    let handle;
    const onBack = () => {
      if (sessionActive) { setSessionActive(false); return; }
      if (scannerOpen) { setScannerOpen(false); return; }
      if (scaleOpen) { setScaleOpen(false); return; }
      if (summaryOpen) { setSummaryOpen(false); return; }
      if (settingsOpen) { setSettingsOpen(false); return; }
      if (tab !== "home") { setTab("home"); return; }
      CapApp.exitApp();
    };
    CapApp.addListener("backButton", onBack).then(h => { handle = h; });
    return () => { if (handle) handle.remove(); };
  }, [sessionActive, scannerOpen, scaleOpen, summaryOpen, settingsOpen, tab]);

  const completeOnboarding = async (data) => {
    const p = { ...data, name: "Athlete", age: Number(data.age), height: Number(data.height), weight: Number(data.weight) };
    setProfile(p);
    setWorkoutPlan(buildWorkoutPlan(p));
    setNutrition(buildNutritionTargets(p));
    setMeals(buildMealPlan(p));
    try { await storage.set("form:profile", JSON.stringify(p)); } catch (e) {}
  };

  const showXp = (amount) => { setXpToast(amount); setGame(g => ({ ...g, xp: g.xp + amount })); setTimeout(() => setXpToast(null), 2200); };

  const handleSessionFinish = (summary) => {
    setTodayResults(prev => ({ ...prev, ...summary.perExercise }));
    setLastSession(summary.perExercise);
    setPersonalBests(prev => {
      const next = { ...prev };
      Object.entries(summary.perExercise).forEach(([k, r]) => { if (r.isPR) next[k] = { reps: r.totalReps }; });
      return next;
    });
    setFormHistory(h => [...h.slice(-6), { d: `S${h.length + 1}`, v: summary.avgForm }]);
    setGame(g => ({
      ...g, xp: g.xp + summary.totalXp, streak: g.streak,
      stats: { ...g.stats, form: Math.round(g.stats.form * 0.7 + summary.avgForm * 0.3) },
    }));
    setSessionActive(false);
    setTab("home");
  };

  const logMeal = (meal) => { setLoggedMealsList(l => [...l, meal]); setScannerOpen(false); setScaleOpen(false); showXp(30); };

  if (!profile) return <Onboarding onComplete={completeOnboarding} />;

  const totalVerifiedReps = Object.values(todayResults).reduce((a, r) => a + r.totalReps, 0);
  const avgFormToday = Object.values(todayResults).length ? Math.round(Object.values(todayResults).reduce((a, r) => a + r.avgForm, 0) / Object.values(todayResults).length) : 0;
  const nutritionLoggedPct = Math.round((meals.filter(m => m.logged).length / Math.max(meals.length, 1)) * 100);
  const dayPct = Math.round((Object.keys(todayResults).length / Math.max(workoutPlan.length, 1)) * 60 + nutritionLoggedPct * 0.4);

  return (
    <div style={{ minHeight: "100vh", background: C.bg, maxWidth: 480, margin: "0 auto", position: "relative", fontFamily: "Inter, sans-serif", paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <style>{FONT_IMPORT}</style>
      <OfflineBanner />

      {xpToast !== null && (
        <div style={{ position: "fixed", top: 18, left: "50%", transform: "translateX(-50%)", zIndex: 70, background: `linear-gradient(135deg, ${C.teal}, ${C.purple})`, color: "#04211D", fontWeight: 700, padding: "10px 18px", borderRadius: 999, fontFamily: "Space Grotesk, sans-serif", fontSize: 14, boxShadow: "0 8px 24px rgba(45,212,191,0.35)", display: "flex", alignItems: "center", gap: 6 }}>
          <Zap size={15} /> +{xpToast} XP
        </div>
      )}

      {tab === "home" && (
        <HomeScreen profile={profile} game={game} workoutPlan={workoutPlan} todayResults={todayResults} nutrition={nutrition} meals={meals} hydration={hydration} setHydration={setHydration}
          onStartWorkout={() => { setSessionStartIndex(0); setSessionActive(true); }} onOpenSummary={() => setSummaryOpen(true)} />
      )}
      {tab === "train" && (
        <TrainScreen workoutPlan={workoutPlan} todayResults={todayResults} lastSession={lastSession}
          onStart={(idx) => { setSessionStartIndex(idx); setSessionActive(true); }} />
      )}
      {tab === "eat" && (<EatScreen nutrition={nutrition} meals={meals} setMeals={setMeals} onOpenScanner={() => setScannerOpen(true)} onOpenScale={() => setScaleOpen(true)} loggedMealsList={loggedMealsList} />)}
      {tab === "progress" && <ProgressScreen game={game} formHistory={formHistory} />}
      {tab === "profile" && <ProfileScreen profile={profile} game={game} lastSession={lastSession} onOpenSettings={() => setSettingsOpen(true)} />}

      <BottomNav tab={tab} setTab={setTab} />

      {sessionActive && (
        <WorkoutSessionScreen exercises={workoutPlan} startIndex={sessionStartIndex} personalBests={personalBests} bodyweight={profile.weight || 75}
          onFinish={handleSessionFinish} onExit={() => setSessionActive(false)} />
      )}
      {scannerOpen && <FoodScanner onClose={() => setScannerOpen(false)} onLog={logMeal} />}
      {scaleOpen && <ScaleMode onClose={() => setScaleOpen(false)} onLog={logMeal} />}
      {summaryOpen && (
        <DailySummary onClose={() => setSummaryOpen(false)} pct={Math.min(100, dayPct)} xp={game.xp % 1000}
          workoutDone={Object.keys(todayResults).length === workoutPlan.length && workoutPlan.length > 0}
          reps={totalVerifiedReps} formScore={avgFormToday || game.stats.form} nutritionPct={nutritionLoggedPct} />
      )}
      {settingsOpen && <SettingsScreen onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <FormApp />
    </ErrorBoundary>
  );
}
