// SCALE PROVIDER
//
// Abstraction over "how do we get a weight reading", so a real Bluetooth
// scale integration can be dropped in later without touching ScaleMode's
// UI. Right now only ManualScaleProvider is real — the user types the
// number. BluetoothScaleProvider exists as a correctly-shaped interface,
// but its connect() honestly reports that hardware support isn't built
// yet rather than simulating a fake pairing animation. Do not change
// that without actually wiring up a BLE plugin (e.g.
// @capacitor-community/bluetooth-le) end to end on a real device first.

export const SCALE_STATES = {
  NOT_CONNECTED: "not-connected",
  CONNECTING: "connecting",
  CONNECTED: "connected",
  READING: "reading",
  STABLE: "stable",
  ERROR: "error",
};

export class ManualScaleProvider {
  constructor() {
    this.state = SCALE_STATES.NOT_CONNECTED;
  }
  isHardware() {
    return false;
  }
  async connect() {
    // There is nothing to "connect" to for manual entry — this exists so
    // calling code has one consistent interface regardless of provider.
    return { ok: false, reason: "manual-only", message: "Manual entry doesn't require pairing — just type the weight." };
  }
}

export class BluetoothScaleProvider {
  constructor() {
    this.state = SCALE_STATES.NOT_CONNECTED;
  }
  isHardware() {
    return true;
  }
  async connect() {
    this.state = SCALE_STATES.ERROR;
    return {
      ok: false,
      reason: "not-implemented",
      message: "Bluetooth scale support isn't built into this version of FORM yet — use manual entry below.",
    };
  }
}

export function createScaleProvider() {
  return new ManualScaleProvider();
}
