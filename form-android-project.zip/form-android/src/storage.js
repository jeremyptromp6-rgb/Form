// The original build (a Claude Artifact) used `window.storage`, an API
// that only exists inside Claude's artifact runtime. It does not exist in
// a real browser or an Android WebView, so this module replaces it with
// plain localStorage, which Capacitor's Android WebView supports natively
// (persisted to the app's private storage on-device).
//
// Same shape as the artifact API (get/set/delete) so App.jsx needed only a
// one-line import change, per the "preserve functionality exactly" brief.

export const storage = {
  async get(key) {
    try {
      const value = window.localStorage.getItem(key);
      return value == null ? null : { key, value };
    } catch (e) {
      return null;
    }
  },
  async set(key, value) {
    try {
      window.localStorage.setItem(key, value);
      return { key, value };
    } catch (e) {
      return null;
    }
  },
  async delete(key) {
    try {
      window.localStorage.removeItem(key);
      return { key, deleted: true };
    } catch (e) {
      return null;
    }
  },
};
