// FORM — AI Coach backend
//
// This is the ONLY place the Anthropic API key exists. The Android app
// never sees it (see src/coach-api.js on the client). Deploy this
// somewhere with HTTPS (Render, Fly.io, Railway, a small VPS, etc.),
// put ANTHROPIC_API_KEY in that host's environment/secret manager (never
// commit it), and point the app's VITE_COACH_API_URL at this server's
// public /api/coach URL.
//
// If you don't want a real AI-generated coach message at all, you can
// simply not deploy this — the app already works fully offline with a
// locally-computed coach summary (see CoachPanel in src/App.jsx).

import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import "dotenv/config";

const app = express();
app.use(express.json({ limit: "20kb" }));

// Lock this down to your actual app origin(s) in production. For a
// packaged Android app there is no browser "origin" header on native
// requests, so this mainly matters if you also serve a web build.
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || "*" }));

// Basic abuse protection — tune to your expected traffic.
app.use(
  "/api/coach",
  rateLimit({ windowMs: 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false })
);

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
// Check https://docs.claude.com for current model names/pricing before
// deploying — this is a fast, low-cost model appropriate for a short tip.
const MODEL = process.env.ANTHROPIC_MODEL || "claude-haiku-4-5-20251001";

app.get("/healthz", (_req, res) => res.json({ ok: true }));

app.post("/api/coach", async (req, res) => {
  if (!ANTHROPIC_API_KEY) {
    return res.status(503).json({ error: "coach-not-configured" });
  }
  try {
    const { profile = {}, lastSession = {}, level, stats } = req.body || {};
    const prompt = buildPrompt(profile, lastSession, level, stats);

    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 180,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!upstream.ok) {
      console.error("Anthropic API error:", upstream.status, await upstream.text().catch(() => ""));
      return res.status(502).json({ error: "upstream-error" });
    }

    const data = await upstream.json();
    const message = (data.content || [])
      .map((block) => (block.type === "text" ? block.text : ""))
      .join(" ")
      .trim();

    res.json({ message: message || null });
  } catch (err) {
    console.error("Coach endpoint error:", err);
    res.status(500).json({ error: "server-error" });
  }
});

function buildPrompt(profile, lastSession, level, stats) {
  const keys = Object.keys(lastSession || {});
  const sessionLine = keys.length
    ? keys.map((k) => `${lastSession[k].totalReps} verified ${k} reps at ${lastSession[k].avgForm} avg form`).join("; ")
    : "no verified session yet";
  return [
    "You are a concise, encouraging fitness coach inside a mobile app called FORM.",
    `Athlete goal: ${profile.goal || "unspecified"}. Level: ${profile.level || "unspecified"}. Trains ${profile.daysPerWeek || "?"} days/week.`,
    `Most recent camera-verified session: ${sessionLine}.`,
    `Current in-app level: ${level ?? "?"}. Form attribute: ${stats?.form ?? "?"}/100.`,
    "In 2-3 short sentences, give one practical, specific recommendation for their next session. Do not diagnose injuries or give medical advice. Keep it encouraging and concrete.",
  ].join("\n");
}

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => {
  console.log(`FORM coach backend listening on :${PORT}`);
  if (!ANTHROPIC_API_KEY) {
    console.warn("ANTHROPIC_API_KEY is not set — /api/coach will return 503 until it is.");
  }
});
