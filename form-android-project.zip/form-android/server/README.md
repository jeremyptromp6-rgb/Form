# FORM AI Coach backend (optional)

This tiny Express server is the **only** place the Anthropic API key
should ever exist. The Android app calls this server; this server calls
Anthropic. The key never ships inside the APK.

**The app works fully without this.** If you don't deploy it, the AI Coach
panel simply keeps showing its local, on-device summary (computed from
real workout data) exactly as it did before — no crash, no broken UI.

## Run locally

```bash
cd server
npm install
cp .env.example .env   # then paste your real ANTHROPIC_API_KEY into .env
npm start
```

Server listens on `http://localhost:8787` by default. Test it:

```bash
curl http://localhost:8787/healthz
```

## Deploy

Any Node host works (Render, Railway, Fly.io, a small VPS + pm2, etc.).
Steps are the same everywhere:

1. Push the `server/` folder (or this whole repo) to your host.
2. Set the `ANTHROPIC_API_KEY` environment variable in the host's
   dashboard/secret manager — **not** in a committed file.
3. Optionally set `ALLOWED_ORIGIN` to lock down CORS, and `ANTHROPIC_MODEL`
   if you want a different model than the default.
4. Make sure the deployed URL is HTTPS (required — Android will block
   plaintext HTTP calls by default via Network Security Config).
5. Point the app's build at it:

   ```bash
   # from the project root, before `npm run build`
   VITE_COACH_API_URL=https://your-backend.example.com/api/coach npm run build
   ```

6. Rebuild/resync the Android app (`npx cap sync android`) so the new env
   var is baked into the bundled web assets.

## Security notes

- Rate limiting is on by default (20 req/min/IP) — tune `index.js` to your
  expected traffic.
- No user data is stored server-side; each request is stateless.
- The prompt sent to Claude explicitly asks it not to give medical advice.
- Consider adding an API key or Capacitor App Attestation check on this
  endpoint before shipping to production, so only your app can call it.
