# FORM secure backend (AI Coach + Food Recognition)

This tiny Express server is the **only** place the Anthropic API key
should ever exist. The Android app calls this server; this server calls
Anthropic. The key never ships inside the APK.

**The app works fully without this.** Without it deployed:
- The **AI Coach** panel shows a locally-computed summary (from real
  on-device training + nutrition data) instead of an AI-generated one.
- **Scan Food** uses a clearly-labeled dev mock recognizer instead of a
  real vision model — it never pretends to be real recognition.

Two endpoints, both optional independently:

| Endpoint | Used by | Client env var |
|---|---|---|
| `POST /api/coach` | AI Coach panel (Profile tab) | `VITE_COACH_API_URL` |
| `POST /api/food-recognition` | Scan Food (Eat tab) | `VITE_FOOD_RECOGNITION_API_URL` |

## Run locally

```bash
cd server
npm install
cp .env.example .env   # then paste your real ANTHROPIC_API_KEY into .env
npm start
```

Server listens on `http://localhost:8787` by default. Test it:

```bash
curl http://localhost:8787/healthz
```

## Deploy

Any Node host works (Render, Railway, Fly.io, a small VPS + pm2, etc.).
Steps are the same everywhere:

1. Push the `server/` folder (or this whole repo) to your host.
2. Set the `ANTHROPIC_API_KEY` environment variable in the host's
   dashboard/secret manager — **not** in a committed file.
3. Optionally set `ALLOWED_ORIGIN` to lock down CORS, and `ANTHROPIC_MODEL`
   if you want a different model than the default. `/api/food-recognition`
   needs a model with vision (image) support — check
   [docs.claude.com](https://docs.claude.com) for which current models
   support image input before picking one.
4. Make sure the deployed URL is HTTPS (required — Android will block
   plaintext HTTP calls by default via Network Security Config).
5. Point the app's build at whichever endpoint(s) you deployed:

   ```bash
   # from the project root, before `npm run build` — set either or both
   VITE_COACH_API_URL=https://your-backend.example.com/api/coach \
   VITE_FOOD_RECOGNITION_API_URL=https://your-backend.example.com/api/food-recognition \
   npm run build
   ```

6. Rebuild/resync the Android app (`npx cap sync android`) so the new env
   vars are baked into the bundled web assets.

## How food recognition stays honest

`/api/food-recognition` sends the photo to Claude constrained to a list of
the app's own known foods (from `src/foodDatabase.js`) and asks it to
report which ones it can actually see, with a confidence score — never to
invent nutrition numbers itself. The server then drops any food ID in the
model's response that isn't actually in the list it was given, so a
hallucinated ID can never reach the client. Real nutrition math still
happens entirely client-side, scaled from the same database every other
part of the app uses.

## Security notes

- Rate limiting is on by default (20 req/min/IP per endpoint) — tune
  `index.js` to your expected traffic.
- No user data is stored server-side; each request is stateless.
- The coach prompt explicitly tells Claude not to suggest unsafe calorie
  restriction, skipped meals, overtraining, or medical advice.
- Consider adding an API key or Capacitor App Attestation check on these
  endpoints before shipping to production, so only your app can call them.

