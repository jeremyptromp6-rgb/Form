# AndroidManifest.xml changes

After running `npx cap add android`, Capacitor generates
`android/app/src/main/AndroidManifest.xml` for you. Open it and make
these three changes.

## 1. Permissions (add as direct children of `<manifest>`, above `<application>`)

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.CAMERA" />

<uses-feature android:name="android.hardware.camera" android:required="true" />
<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />
```

`INTERNET` is usually already there by default in the Capacitor template —
just make sure it is; the other three are not, and the app needs all of
them (camera for Train/Eat, network for the pose-detection model download
and the optional AI coach backend).

## 2. Network security config (on the `<application>` tag)

Add the attribute:

```xml
<application
    ...
    android:networkSecurityConfig="@xml/network_security_config"
    ...>
```

and copy `network_security_config.xml` from this folder into
`android/app/src/main/res/xml/network_security_config.xml` (create the
`xml` folder if it doesn't exist).

## 3. Keyboard behavior (on the `<activity>` tag)

Make sure the main activity has:

```xml
<activity
    android:name=".MainActivity"
    ...
    android:windowSoftInputMode="adjustResize"
    android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
    ...>
```

`adjustResize` is what makes the onboarding text inputs (age/height/weight,
allergies) stay visible above the keyboard instead of being covered by it.
