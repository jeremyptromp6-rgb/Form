# MainActivity.java changes (required for the camera to work)

`npx cap add android` generates a minimal
`android/app/src/main/java/com/formfitness/app/MainActivity.java` that
just extends `BridgeActivity` with no body. That's fine for everything
except the camera: Android's WebView will only auto-grant a page's
`getUserMedia()` camera request if your **app** already holds the OS-level
`CAMERA` runtime permission. The WebView itself cannot pop the Android
permission dialog — that has to be requested from native code first.

Replace the generated file's contents with this:

```java
package com.formfitness.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestCameraPermissionIfNeeded();
    }

    private void requestCameraPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                new String[] { Manifest.permission.CAMERA },
                CAMERA_PERMISSION_REQUEST_CODE
            );
        }
    }
}
```

Notes:
- `com.formfitness.app` must match whatever `appId` you set in
  `capacitor.config.ts` — if you change the app ID, this package
  declaration (and the folder path it lives in) must match.
- If the user denies the permission here, `getUserMedia()` will reject and
  the app already shows its existing "Camera access needed" screen
  (`CameraStatusScreen` in `src/App.jsx`) — no crash, just the same honest
  error state it already had.
- This dialog appears once, on first launch, before any UI is visible
  (during the splash screen), which is standard Android UX for
  camera-first apps.
