# res/values changes

## android/app/src/main/res/values/strings.xml

Set (or add) these entries:

```xml
<resources>
    <string name="app_name">FORM</string>
    <string name="title_activity_main">FORM</string>
    <string name="package_name">com.formfitness.app</string>
    <string name="custom_url_scheme">com.formfitness.app</string>
</resources>
```

## android/app/src/main/res/values/colors.xml

Add (or merge) these entries — they control the splash screen background
and the Android status/nav bar color so they match the app's dark theme
instead of showing default white:

```xml
<resources>
    <color name="colorPrimary">#2DD4BF</color>
    <color name="colorPrimaryDark">#134E4A</color>
    <color name="colorAccent">#A78BFA</color>
    <color name="splashBackground">#0B0F10</color>
</resources>
```

## android/app/src/main/res/drawable/splash.xml (or values/styles.xml, depending on Capacitor version)

Make sure the splash screen's background color references
`@color/splashBackground` (Capacitor's default template usually wires this
up automatically once the color exists — check
`android/app/src/main/res/drawable-*/splash.png` was overwritten by the
`assets:generate` step described in the main README).
