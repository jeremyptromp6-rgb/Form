import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.formfitness.app",
  appName: "FORM",
  webDir: "dist",
  // "https" scheme is required (not "http") for camera/getUserMedia to be
  // treated as a secure context inside the Android WebView.
  server: {
    androidScheme: "https",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1000,
      launchAutoHide: false, // we hide it manually in main.jsx once React has painted
      backgroundColor: "#0B0F10",
      androidSplashResourceName: "splash",
      androidScaleType: "CENTER_CROP",
      showSpinner: false,
      splashFullScreen: true,
      splashImmersive: true,
    },
  },
};

export default config;
