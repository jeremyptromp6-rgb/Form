import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  // Capacitor serves the built app from a local scheme (not "/"), so all
  // asset URLs must be relative. Without this, the app loads a blank white
  // screen on Android because JS/CSS paths 404.
  base: "./",
  build: {
    outDir: "dist",
    sourcemap: false,
  },
  server: {
    host: true,
    port: 5173,
  },
});
