# FORM — Android build guide

This turns the existing FORM web app into a real installable Android app
using **Capacitor** (wraps the exact same React UI in a native WebView
shell — this is what preserves your UI/features/navigation exactly,
per your requirement #1/#9, rather than a rewrite).

Read **"What I could and couldn't verify"** at the bottom before you start
— it's a short, honest list of what was checked here vs. what only a real
Android Studio + device/emulator can confirm.

---

## 0. Prerequisites (install once)

- **Node.js 18+** — https://nodejs.org
- **Android Studio** (Hedgehog or newer) — https://developer.android.com/studio
  - On first launch, let it install the Android SDK, an emulator image, and
    the SDK command-line tools via the SDK Manager.
- A **JDK 17** (Android Studio bundles one — you generally don't need a
  separate install).

---

## 1. Get the project onto your machine

Copy this whole `form-android/` folder to your computer, then:

```bash
cd form-android
npm install
```

---

## 2. Run it as a normal web app first (fast feedback loop)

```bash
npm run dev
```

Open the printed `http://localhost:5173` URL in a desktop browser. This is
the exact same app (minus native-only bits like the hardware back button
and splash screen) — use this to sanity-check the UI quickly before
touching Android at all. Camera features need HTTPS or `localhost` to
work in a browser, which Vite's dev server already satisfies.

---

## 3. Generate the app icon + splash screen

Source images are already provided in `assets/` (icon.png,
icon-foreground.png, icon-background.png, splash.png) — teal-to-purple
gradient with the app's bolt mark, matching the existing in-app branding.

```bash
npm run assets:generate
```

This runs `@capacitor/assets`, which reads those source files and
generates every Android density (mdpi → xxxhdpi) automatically, including
adaptive icon layers. If you'd rather use your own logo, just replace the
four PNGs in `assets/` with same-named, same-aspect-ratio files first
(icon/foreground/background: 1024×1024, splash: 2732×2732).

---

## 4. Build the web app and add the Android platform

```bash
npm run build          # produces dist/
npm run android:add    # runs `npx cap add android`, generates the android/ folder
npm run android:sync   # copies dist/ + plugins into the native project
```

---

## 5. Apply the Android-specific customizations

The `android/` folder Capacitor just generated needs four small, manual
edits — each is fully spelled out with exact code in `android-config/`:

| File to edit | Instructions |
|---|---|
| `android/app/src/main/AndroidManifest.xml` | `android-config/AndroidManifest-additions.md` (camera/network permissions, keyboard mode) |
| `android/app/src/main/res/xml/network_security_config.xml` (new file) | copy `android-config/network_security_config.xml` |
| `android/app/src/main/java/.../MainActivity.java` | `android-config/MainActivity-additions.md` (required — this is what makes the camera permission dialog actually appear) |
| `android/app/src/main/res/values/strings.xml` and `colors.xml` | `android-config/strings-and-colors.md` |

After making these edits:

```bash
npm run android:sync
```

---

## 6. Open in Android Studio and run on an emulator/device

```bash
npm run android:open
```

This opens `android/` in Android Studio. Let Gradle finish syncing (first
time can take a few minutes while it downloads dependencies), then:

1. Create/select a device: **Device Manager → Create Device** (pick any
   Pixel profile, API 33+) — or plug in a real phone with USB debugging on.
2. Click **Run ▶**.
3. On first launch you should see the camera-permission system dialog
   (from the MainActivity change in step 5) — accept it.

Walk through the flows in the **Testing checklist** below before moving on.

---

## 7. Build a signed release APK

### 7a. Generate a signing key (once, keep it safe forever)

```bash
keytool -genkeypair -v -keystore form-release.keystore \
  -alias form -keyalg RSA -keysize 2048 -validity 10000
```

You'll be asked for passwords and identity info — remember the passwords;
Google Play requires the **same** keystore for every future update. Store
this file and its passwords somewhere safe **outside** the git repo (it's
already in `.gitignore`).

### 7b. Point Gradle at the keystore

Add to `android/app/build.gradle`, inside `android { ... }`:

```gradle
signingConfigs {
    release {
        storeFile file("/absolute/path/to/form-release.keystore")
        storePassword System.getenv("FORM_KEYSTORE_PASSWORD")
        keyAlias "form"
        keyPassword System.getenv("FORM_KEY_PASSWORD")
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false   // safe default for the first release; see note below
    }
}
```

Set the two env vars in your shell before building:

```bash
export FORM_KEYSTORE_PASSWORD="your-keystore-password"
export FORM_KEY_PASSWORD="your-key-password"
```

(Never hardcode passwords directly in `build.gradle` if this repo is
shared or committed anywhere.)

### 7c. Build the release APK

From Android Studio: **Build → Generate Signed Bundle / APK → APK →
release**, pointing it at the keystore from 7a.

Or from the command line:

```bash
cd android
./gradlew assembleRelease
```

The signed APK lands at:

```
android/app/build/outputs/apk/release/app-release.apk
```

Install it on a device to confirm:

```bash
adb install -r android/app/build/outputs/apk/release/app-release.apk
```

> **Publishing to Google Play** instead wants an `.aab`:
> `./gradlew bundleRelease` → `android/app/build/outputs/bundle/release/app-release.aab`.

---

## 8. (Optional) Wire up the secure AI Coach backend

The app works completely without this — the AI Coach panel shows a
locally-computed summary by default. If you want it backed by a real
Claude call instead, see `server/README.md`, then rebuild with:

```bash
VITE_COACH_API_URL=https://your-backend.example.com/api/coach npm run build
npm run android:sync
```

---

## Testing checklist (walk through before you call it done)

- [ ] Onboarding: all 7 steps, Continue disabled until each step is valid,
      Back button works, final "Generate My Plan" creates a plan.
- [ ] Killing and reopening the app restores your profile (tests the
      `localStorage`-backed persistence that replaced `window.storage`).
- [ ] Home → **START TODAY'S WORKOUT** opens the camera and requests
      permission.
- [ ] Deny camera permission once → see the "Camera access needed" screen,
      not a crash.
- [ ] Grant permission → position yourself → verified reps count up.
- [ ] Rest timer, "Next Exercise", and final "Workout Complete" screen.
- [ ] Eat → Scan Food opens the rear camera; Use Scale mode math updates
      live as you adjust grams.
- [ ] Progress and Profile screens render charts correctly at phone width.
- [ ] Rotate the device / test on a small (5") and large (6.7"+) screen —
      layout should reflow, nothing clipped.
- [ ] Turn on airplane mode → offline banner appears; app doesn't crash;
      turning it back on hides the banner.
- [ ] Hardware **Back** button: closes camera/modals first, then goes to
      Home tab, then exits the app from Home with nothing open.
- [ ] Tap into the onboarding text inputs → keyboard doesn't cover them.

---

## What I could and couldn't verify

I don't have Android Studio, an Android SDK/emulator, or a phone in this
environment, and I have no network access here to install Capacitor/Vite
and actually run `npx cap add android` or `./gradlew assembleRelease`
myself. So, to be precise about what's been checked vs. not:

**Actually verified here:**
- `src/App.jsx` (and every other `.js`/`.jsx` file) passes a real
  TypeScript/JSX syntax parse — no syntax errors.
- Every `window.storage` call (artifact-only API) was found and replaced
  with a real `localStorage`-backed module — grepped the whole file
  afterward to confirm none were missed.
- All UI, screens, navigation, and game logic are byte-for-byte the same
  as your existing app except for the specific, minimal additions this
  task asked for (storage swap, offline banner, error boundary, back
  button, optional coach backend call).
- The generated app icon/splash render correctly (inspected the PNGs).

**Not verified — needs your machine:**
- That `npm install` resolves cleanly with no version conflicts.
- That `npx cap add android` scaffolds without error (standard, does for
  the vast majority of projects, but I can't run it here).
- The actual Gradle build (`./gradlew assembleRelease`) and whether it
  compiles first try — Gradle/Capacitor version drift is the most common
  real-world failure point, and I can't build against Android's SDK here.
- Real camera/pose-detection behavior on an actual device (the underlying
  TensorFlow.js/MoveNet pipeline was built and reasoned through in the
  previous stage, but has never run on physical Android hardware).
- Every item in the Testing checklist above — please actually run through
  it once you have a build.

If Gradle throws an error on first build, it's almost always a version
mismatch between the Capacitor CLI/plugins and the Android
Gradle Plugin/SDK level Android Studio installed — bumping
`@capacitor/*` and the AGP version in `android/build.gradle` to whatever
Android Studio's "Upgrade Assistant" suggests resolves the large majority
of these.
